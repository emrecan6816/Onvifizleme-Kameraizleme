# -*- coding: utf-8 -*-
"""Kayıtlar penceresinin arayüzden bağımsız mantığı: dosya adından bilgi, filtre, sıralama, gün başlıkları."""
import datetime as dt
import re

AYLAR = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"]
GUNLER = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
_AD_RE = re.compile(r"^(?P<ad>.+?)_(?P<t>\d{8}_\d{6})(?:_\d+)?$")

ARALIKLAR = [("Tüm tarihler", "hepsi"), ("Bugün", "bugun"), ("Dün", "dun"), ("Son 7 gün", "hafta")]
SIRALAR = [("En yeni", "yeni"), ("En eski", "eski"), ("En büyük", "buyuk")]


def dosya_bilgisi(yol, boyut, mtime):
    """yol: Path. Dosya adındaki kamera adı ve zamanı çözer (olmazsa dosya tarihine döner)."""
    m = _AD_RE.match(yol.stem)
    kamera, zaman = None, None
    if m:
        kamera = m.group("ad").replace("_", " ")
        try:
            zaman = dt.datetime.strptime(m.group("t"), "%Y%m%d_%H%M%S")
        except ValueError:
            zaman = None
    if zaman is None:
        zaman = dt.datetime.fromtimestamp(mtime)
    return {"yol": yol, "ad": yol.name, "kamera": kamera or "Bilinmeyen kamera", "zaman": zaman, "boyut": boyut}


def sure_metni(sn):
    if sn is None or sn <= 0:
        return "—"
    sn = int(round(sn))
    s, k = sn % 60, sn // 60
    if k >= 60:
        return "%d:%02d:%02d" % (k // 60, k % 60, s)
    return "%d:%02d" % (k, s)


def gun_etiketi(gun, bugun):
    fark = (bugun - gun).days
    tarih = "%d %s %d" % (gun.day, AYLAR[gun.month - 1], gun.year)
    if fark == 0:
        return "Bugün · " + tarih
    if fark == 1:
        return "Dün · " + tarih
    return "%s · %s" % (GUNLER[gun.weekday()], tarih)


def kamera_adlari(kayitlar):
    return sorted({k["kamera"] for k in kayitlar}, key=str.lower)


def filtrele(kayitlar, kamera="hepsi", aralik="hepsi", arama="", siralama="yeni", bugun=None):
    bugun = bugun or dt.date.today()
    arama = (arama or "").strip().lower()
    sonuc = []
    for k in kayitlar:
        gun = k["zaman"].date()
        if kamera not in ("hepsi", None) and k["kamera"] != kamera:
            continue
        if aralik == "bugun" and gun != bugun:
            continue
        if aralik == "dun" and gun != bugun - dt.timedelta(days=1):
            continue
        if aralik == "hafta" and not (bugun - dt.timedelta(days=6) <= gun <= bugun):
            continue
        if arama and arama not in k["ad"].lower() and arama not in k["kamera"].lower() \
                and arama not in k["zaman"].strftime("%d.%m.%Y %H:%M"):
            continue
        sonuc.append(k)
    if siralama == "eski":
        sonuc.sort(key=lambda k: k["zaman"])
    elif siralama == "buyuk":
        sonuc.sort(key=lambda k: k["boyut"], reverse=True)
    else:
        sonuc.sort(key=lambda k: k["zaman"], reverse=True)
    return sonuc


def gunlere_bol(kayitlar):
    """[(gun, [kayit, ...])] — girişteki sıra korunur."""
    gruplar, son = [], None
    for k in kayitlar:
        g = k["zaman"].date()
        if g != son:
            gruplar.append((g, []))
            son = g
        gruplar[-1][1].append(k)
    return gruplar
