# -*- coding: utf-8 -*-
"""
Ana sayfa kamera ızgarası: 1–6 kamera için düzenler ve kamera↔karo atama mantığı.
Arayüzden (Tk) bağımsızdır; bu yüzden ayrıca test edilebilir.

Bir düzen tanımı:
  ad      : düzenin kimliği (aynı sayıdaki farklı yerleşimleri ayırt etmek için)
  satir   : satır ağırlıkları (oransal yükseklik)
  sutun   : sütun ağırlıkları (oransal genişlik)
  karolar : her karo için (satır, sütun, satır_kapsama, sütun_kapsama)
"""

MAX_KARO = 6


def _d(ad, satir, sutun, karolar):
    return {"ad": ad, "satir": list(satir), "sutun": list(sutun), "karolar": list(karolar)}


DUZENLER = {
    1: _d("1", [1], [1], [(0, 0, 1, 1)]),
    # 2: üst üste (geniş ekranda yan yana — bkz. duzen_tanimi)
    2: _d("2-ust", [1, 1], [1], [(0, 0, 1, 1), (1, 0, 1, 1)]),
    # 3: üstte geniş bir karo, altta iki karo
    3: _d("3", [3, 2], [1, 1], [(0, 0, 1, 2), (1, 0, 1, 1), (1, 1, 1, 1)]),
    # 4: 2x2
    4: _d("4", [1, 1], [1, 1], [(0, 0, 1, 1), (0, 1, 1, 1), (1, 0, 1, 1), (1, 1, 1, 1)]),
    # 5: solda iki satır boyunca bir büyük karo, sağda ve altta dörder küçük karo
    5: _d("5", [1, 1, 1], [1, 1], [(0, 0, 2, 1), (0, 1, 1, 1), (1, 1, 1, 1), (2, 0, 1, 1), (2, 1, 1, 1)]),
    # 6: 3 satır x 2 sütun (geniş ekranda 2 satır x 3 sütun)
    6: _d("6-3x2", [1, 1, 1], [1, 1], [(r, c, 1, 1) for r in range(3) for c in range(2)]),
}

_IKI_YAN = _d("2-yan", [1], [1, 1], [(0, 0, 1, 1), (0, 1, 1, 1)])
_ALTI_2X3 = _d("6-2x3", [1, 1], [1, 1, 1], [(r, c, 1, 1) for r in range(2) for c in range(3)])

TUM_TANIMLAR = list(DUZENLER.values()) + [_IKI_YAN, _ALTI_2X3]

# 16:9 görüntüler çok geniş/çok dar karolara sığmayınca boşluk kalır; alanın en-boy oranına göre
# aynı sayıdaki karolar için daha verimli yerleşim seçilir.
ESIK_IKI_YAN = 1.7
ESIK_ALTI_2X3 = 1.75


def duzen_sinirla(n, varsayilan=1):
    try:
        n = int(n)
    except (TypeError, ValueError):
        return varsayilan
    return max(1, min(MAX_KARO, n))


def duzen_tanimi(n, oran=1.3):
    """n karolu düzenin tanımı. oran: ızgara alanının genişlik/yükseklik oranı."""
    n = duzen_sinirla(n)
    if n == 2 and oran >= ESIK_IKI_YAN:
        return _IKI_YAN
    if n == 6 and oran >= ESIK_ALTI_2X3:
        return _ALTI_2X3
    return DUZENLER[n]


def goreli_dikdortgenler(tanim):
    """Her karo için (x0, y0, x1, y1) — 0..1 aralığında, ağırlıklara göre (simge çizimi için)."""
    sat, sut = tanim["satir"], tanim["sutun"]
    ts, tc = float(sum(sat)), float(sum(sut))
    ys, xs = [0.0], [0.0]
    for w in sat:
        ys.append(ys[-1] + w / ts)
    for w in sut:
        xs.append(xs[-1] + w / tc)
    sonuc = []
    for r, c, rs, cs in tanim["karolar"]:
        sonuc.append((xs[c], ys[r], xs[c + cs], ys[r + rs]))
    return sonuc


def karo_dikdortgenleri(tanim, w, h, bosluk=0):
    """Düzeni w x h piksellik alana yerleştirir; her karo için (x0, y0, x1, y1) döndürür (karolar arasında
    `bosluk` piksel boşluk kalır, tam sayıya yuvarlanır)."""
    def izler(agirliklar, toplam):
        net = max(0.0, toplam - bosluk * (len(agirliklar) - 1))
        ts, pos, sonuc = float(sum(agirliklar)), 0.0, []
        for i, a in enumerate(agirliklar):
            bas = i * bosluk + net * pos / ts
            pos += a
            sonuc.append((int(round(bas)), int(round(i * bosluk + net * pos / ts))))
        return sonuc
    satirlar, sutunlar = izler(tanim["satir"], h), izler(tanim["sutun"], w)
    return [(sutunlar[c][0], satirlar[r][0], sutunlar[c + cs - 1][1], satirlar[r + rs - 1][1])
            for r, c, rs, cs in tanim["karolar"]]


def tanim_gecerli(tanim):
    """Karolar ızgara hücrelerini çakışmadan ve boşluk bırakmadan tam kaplıyor mu?"""
    hucre = {}
    for k, (r, c, rs, cs) in enumerate(tanim["karolar"]):
        for rr in range(r, r + rs):
            for cc in range(c, c + cs):
                if rr >= len(tanim["satir"]) or cc >= len(tanim["sutun"]) or (rr, cc) in hucre:
                    return False
                hucre[(rr, cc)] = k
    return len(hucre) == len(tanim["satir"]) * len(tanim["sutun"])


# ------------------------------------------------------------------ atama mantığı
def atama_hazirla(atama):
    """Kayıtlı atamayı MAX_KARO uzunluğunda, yalnızca str/None içeren listeye çevirir."""
    a = [x if isinstance(x, str) and x else None for x in (atama if isinstance(atama, list) else [])]
    a = a[:MAX_KARO]
    return a + [None] * (MAX_KARO - len(a))


def atama_duzenle(atama, idler, n):
    """Geçersiz kameraları siler, görünen karolardaki tekrarları kaldırır ve boş görünen karoları
    henüz gösterilmeyen kameralarla (listedeki sırayla) doldurur."""
    idler = list(idler)
    a = atama_hazirla(atama)
    a = [x if x in idler else None for x in a]
    n = duzen_sinirla(n)
    gorunen = a[:n]
    goruldu = set()
    for i, x in enumerate(gorunen):
        if x is None:
            continue
        if x in goruldu:
            gorunen[i] = None
        else:
            goruldu.add(x)
    bos = [i for i, x in enumerate(gorunen) if x is None]
    kullanilmayan = [k for k in idler if k not in goruldu]
    for i, k in zip(bos, kullanilmayan):
        gorunen[i] = k
    goruldu.update(x for x in gorunen if x)
    gizli = []
    for x in a[n:]:                       # gizli karolarda da tekrar olmasın (görünen kamera gizlide yinelenmez)
        if x is not None and x not in goruldu:
            goruldu.add(x)
            gizli.append(x)
        else:
            gizli.append(None)
    return gorunen + gizli


def atama_ata(atama, slot, kid, n):
    """slot karosuna kid kamerasını koyar (kid None ise karoyu boşaltır). Kamera başka bir görünen karodaysa
    iki karo yer değiştirir; böylece aynı kamera iki kez görünmez."""
    a = atama_hazirla(atama)
    n = duzen_sinirla(n)
    if not (0 <= slot < MAX_KARO):
        return a
    onceki = a[slot]
    if kid is not None:
        for j in range(MAX_KARO):          # gizli karolar dahil: aynı kamera iki yerde kalmasın
            if j != slot and a[j] == kid:
                a[j] = onceki
    a[slot] = kid
    return a
