# -*- coding: utf-8 -*-
"""
Saf Python (ek paket gerektirmeyen) ONVIF istemcisi.
Tapo ve diğer ONVIF kameralar için: keşif, profil, RTSP adresi, PTZ ve preset.
"""
import base64
import datetime as dt
import hashlib
import os
import re
import socket
import time
import urllib.error
import urllib.request
import uuid
import xml.etree.ElementTree as ET
from urllib.parse import quote, urlparse

NS_SOAP = "http://www.w3.org/2003/05/soap-envelope"
NS_WSSE = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd"
NS_WSU = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd"
PW_DIGEST = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-username-token-profile-1.0#PasswordDigest"
ENC_B64 = "http://docs.oasis-open.org/wss/2004/01/oasis-200401-soap-message-security-1.0#Base64Binary"

TDS = "http://www.onvif.org/ver10/device/wsdl"
TRT = "http://www.onvif.org/ver10/media/wsdl"
TPTZ = "http://www.onvif.org/ver20/ptz/wsdl"
TT = "http://www.onvif.org/ver10/schema"


class OnvifHata(Exception):
    """ONVIF çağrısı başarısız oldu (mesaj kullanıcıya gösterilebilir)."""


def _yerel(tag):
    return tag.split("}")[-1]


def bul_hepsi(kok, ad):
    return [e for e in kok.iter() if _yerel(e.tag) == ad]


def bul_ilk(kok, ad):
    for e in kok.iter():
        if _yerel(e.tag) == ad:
            return e
    return None


def _xml_kacis(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
             .replace('"', "&quot;"))


class OnvifIstemci:
    def __init__(self, host, port=2020, kullanici="", sifre="", zaman_asimi=6):
        self.host = host
        self.port = int(port)
        self.kullanici = kullanici
        self.sifre = sifre
        self.zaman_asimi = zaman_asimi
        self.cihaz_url = "http://%s:%d/onvif/device_service" % (host, self.port)
        self.medya_url = None
        self.ptz_url = None
        self.profiller = []      # [{'token':..., 'ad':..., 'ptz':bool, 'genislik':int, 'yukseklik':int}]
        self.zaman_farki = 0.0   # kamera UTC - yerel UTC (saniye)
        self.baglandi = False

    # ---------------------------------------------------------------- SOAP
    def _guvenlik_basligi(self):
        if not self.kullanici:
            return ""
        nonce = os.urandom(16)
        simdi = dt.datetime.now(dt.timezone.utc) + dt.timedelta(seconds=self.zaman_farki)
        olusturma = simdi.strftime("%Y-%m-%dT%H:%M:%S.") + "%03dZ" % (simdi.microsecond // 1000)
        ozet = hashlib.sha1(nonce + olusturma.encode() + self.sifre.encode()).digest()
        return (
            '<s:Header><wsse:Security s:mustUnderstand="1" xmlns:wsse="%s" xmlns:wsu="%s">'
            "<wsse:UsernameToken>"
            "<wsse:Username>%s</wsse:Username>"
            '<wsse:Password Type="%s">%s</wsse:Password>'
            '<wsse:Nonce EncodingType="%s">%s</wsse:Nonce>'
            "<wsu:Created>%s</wsu:Created>"
            "</wsse:UsernameToken></wsse:Security></s:Header>"
        ) % (NS_WSSE, NS_WSU, _xml_kacis(self.kullanici), PW_DIGEST,
             base64.b64encode(ozet).decode(), ENC_B64,
             base64.b64encode(nonce).decode(), olusturma)

    def _cagri(self, url, govde, kimlikli=True):
        zarf = ('<?xml version="1.0" encoding="utf-8"?>'
                '<s:Envelope xmlns:s="%s">%s<s:Body>%s</s:Body></s:Envelope>') % (
            NS_SOAP, self._guvenlik_basligi() if kimlikli else "", govde)
        istek = urllib.request.Request(
            url, data=zarf.encode("utf-8"),
            headers={"Content-Type": "application/soap+xml; charset=utf-8"})
        try:
            with urllib.request.urlopen(istek, timeout=self.zaman_asimi) as yanit:
                veri = yanit.read()
        except urllib.error.HTTPError as e:
            govde_hata = ""
            try:
                govde_hata = e.read().decode("utf-8", "ignore")
            except Exception:
                pass
            kucuk = govde_hata.lower().replace(" ", "")
            if e.code in (401, 403) or "notauthorized" in kucuk:
                raise OnvifHata("Kimlik doğrulama hatası: kullanıcı adı/şifre yanlış "
                                "(Tapo uygulamasında oluşturduğunuz 'Kamera hesabı' olmalı).")
            raise OnvifHata("Kamera HTTP %d döndürdü." % e.code)
        except (urllib.error.URLError, socket.timeout, ConnectionError, OSError) as e:
            raise OnvifHata("Kameraya ulaşılamadı (%s:%d): %s" % (self.host, self.port, e))
        try:
            kok = ET.fromstring(veri)
        except ET.ParseError:
            raise OnvifHata("Kameradan geçersiz yanıt geldi.")
        hata = bul_ilk(kok, "Fault")
        if hata is not None:
            metin = " ".join((t.text or "").strip() for t in hata.iter() if (t.text or "").strip())
            if "notauthorized" in metin.lower().replace(" ", ""):
                raise OnvifHata("Kimlik doğrulama hatası: kullanıcı adı/şifre yanlış.")
            raise OnvifHata("ONVIF hatası: " + (metin[:160] or "bilinmeyen"))
        return kok

    # ------------------------------------------------------------ bağlantı
    def _zaman_esitle(self):
        govde = '<tds:GetSystemDateAndTime xmlns:tds="%s"/>' % TDS
        kok = self._cagri(self.cihaz_url, govde, kimlikli=False)
        utc = bul_ilk(kok, "UTCDateTime")
        if utc is None:
            return
        try:
            tarih = bul_ilk(utc, "Date")
            saat = bul_ilk(utc, "Time")
            kamera = dt.datetime(
                int(bul_ilk(tarih, "Year").text), int(bul_ilk(tarih, "Month").text),
                int(bul_ilk(tarih, "Day").text), int(bul_ilk(saat, "Hour").text),
                int(bul_ilk(saat, "Minute").text), int(bul_ilk(saat, "Second").text),
                tzinfo=dt.timezone.utc)
            self.zaman_farki = (kamera - dt.datetime.now(dt.timezone.utc)).total_seconds()
        except Exception:
            self.zaman_farki = 0.0

    def baglan(self):
        """Kameraya bağlanır, servis adreslerini ve profilleri alır."""
        self._zaman_esitle()
        self.medya_url = None
        self.ptz_url = None
        try:
            govde = ('<tds:GetCapabilities xmlns:tds="%s"><tds:Category>All</tds:Category>'
                     "</tds:GetCapabilities>") % TDS
            kok = self._cagri(self.cihaz_url, govde)
            medya = bul_ilk(kok, "Media")
            ptz = bul_ilk(kok, "PTZ")
            if medya is not None and bul_ilk(medya, "XAddr") is not None:
                self.medya_url = self._ana_bilgisayari_duzelt(bul_ilk(medya, "XAddr").text.strip())
            if ptz is not None and bul_ilk(ptz, "XAddr") is not None:
                self.ptz_url = self._ana_bilgisayari_duzelt(bul_ilk(ptz, "XAddr").text.strip())
        except OnvifHata as e:
            if "Kimlik" in str(e):
                raise
        if not self.medya_url:
            self.medya_url = self.cihaz_url
        if not self.ptz_url:
            self.ptz_url = self.medya_url

        kok = self._cagri(self.medya_url, '<trt:GetProfiles xmlns:trt="%s"/>' % TRT)
        self.profiller = []
        for p in kok.iter():
            if _yerel(p.tag) != "Profiles" or not p.get("token"):
                continue
            ad = bul_ilk(p, "Name")
            genislik = yukseklik = 0
            cozunurluk = bul_ilk(p, "Resolution")
            if cozunurluk is not None:
                try:
                    genislik = int(bul_ilk(cozunurluk, "Width").text)
                    yukseklik = int(bul_ilk(cozunurluk, "Height").text)
                except Exception:
                    pass
            self.profiller.append({
                "token": p.get("token"),
                "ad": (ad.text if ad is not None else p.get("token")),
                "ptz": bul_ilk(p, "PTZConfiguration") is not None,
                "genislik": genislik, "yukseklik": yukseklik,
            })
        if not self.profiller:
            raise OnvifHata("Kamerada kullanılabilir profil bulunamadı.")
        self.baglandi = True
        return self.profiller

    def _ana_bilgisayari_duzelt(self, adres):
        """Kamera iç IP bildirirse, bağlandığımız adresi kullan."""
        try:
            u = urlparse(adres)
            if u.hostname and u.hostname != self.host:
                port = u.port or self.port
                return "http://%s:%d%s" % (self.host, port, u.path or "/onvif/service")
        except Exception:
            pass
        return adres

    # ------------------------------------------------------------- yayın
    def profil_sec(self, kalite):
        """kalite: 'yuksek' -> ilk profil, 'dusuk' -> ikinci profil (varsa)."""
        if not self.profiller:
            raise OnvifHata("Önce bağlanın.")
        if kalite == "dusuk" and len(self.profiller) > 1:
            return self.profiller[1]
        return self.profiller[0]

    def rtsp_adresi(self, kalite="yuksek"):
        profil = self.profil_sec(kalite)
        govde = (
            '<trt:GetStreamUri xmlns:trt="%s" xmlns:tt="%s"><trt:StreamSetup>'
            "<tt:Stream>RTP-Unicast</tt:Stream><tt:Transport><tt:Protocol>RTSP</tt:Protocol>"
            "</tt:Transport></trt:StreamSetup><trt:ProfileToken>%s</trt:ProfileToken>"
            "</trt:GetStreamUri>") % (TRT, TT, _xml_kacis(profil["token"]))
        kok = self._cagri(self.medya_url, govde)
        uri = bul_ilk(kok, "Uri")
        if uri is None or not (uri.text or "").strip():
            raise OnvifHata("Kamera RTSP adresi vermedi.")
        return self.kimlik_ekle(uri.text.strip())

    def kimlik_ekle(self, rtsp):
        u = urlparse(rtsp)
        host = self.host  # iç IP bildirilmişse bile bağlandığımız adresi kullan
        port = u.port or 554
        yol = u.path or ""
        if u.query:
            yol += "?" + u.query
        if self.kullanici:
            kimlik = "%s:%s@" % (quote(self.kullanici, safe=""), quote(self.sifre, safe=""))
        else:
            kimlik = ""
        return "rtsp://%s%s:%d%s" % (kimlik, host, port, yol)

    def varsayilan_rtsp(self, kalite="yuksek"):
        """ONVIF çalışmazsa Tapo'nun standart RTSP adresi."""
        n = 2 if kalite == "dusuk" else 1
        return self.kimlik_ekle("rtsp://%s:554/stream%d" % (self.host, n))

    # --------------------------------------------------------------- PTZ
    def _ptz_token(self):
        if not self.profiller:
            raise OnvifHata("Önce bağlanın.")
        for p in self.profiller:
            if p["ptz"]:
                return p["token"]
        return self.profiller[0]["token"]

    def _ptz(self, govde):
        if not self.baglandi:
            raise OnvifHata("Kamera bağlı değil.")
        return self._cagri(self.ptz_url, govde)

    def hareket(self, pan, tilt):
        govde = (
            '<tptz:ContinuousMove xmlns:tptz="%s" xmlns:tt="%s"><tptz:ProfileToken>%s</tptz:ProfileToken>'
            '<tptz:Velocity><tt:PanTilt x="%.3f" y="%.3f"/></tptz:Velocity></tptz:ContinuousMove>'
        ) % (TPTZ, TT, _xml_kacis(self._ptz_token()), pan, tilt)
        self._ptz(govde)

    def dur(self):
        govde = (
            '<tptz:Stop xmlns:tptz="%s"><tptz:ProfileToken>%s</tptz:ProfileToken>'
            "<tptz:PanTilt>true</tptz:PanTilt><tptz:Zoom>true</tptz:Zoom></tptz:Stop>"
        ) % (TPTZ, _xml_kacis(self._ptz_token()))
        self._ptz(govde)

    def ana_konuma_git(self):
        govde = ('<tptz:GotoHomePosition xmlns:tptz="%s"><tptz:ProfileToken>%s</tptz:ProfileToken>'
                 "</tptz:GotoHomePosition>") % (TPTZ, _xml_kacis(self._ptz_token()))
        self._ptz(govde)

    def presetleri_al(self):
        govde = ('<tptz:GetPresets xmlns:tptz="%s"><tptz:ProfileToken>%s</tptz:ProfileToken>'
                 "</tptz:GetPresets>") % (TPTZ, _xml_kacis(self._ptz_token()))
        kok = self._ptz(govde)
        sonuc = []
        for p in kok.iter():
            if _yerel(p.tag) == "Preset" and p.get("token"):
                ad = bul_ilk(p, "Name")
                sonuc.append((ad.text if ad is not None and ad.text else "Preset " + p.get("token"),
                              p.get("token")))
        return sonuc

    def presete_git(self, token):
        govde = ('<tptz:GotoPreset xmlns:tptz="%s"><tptz:ProfileToken>%s</tptz:ProfileToken>'
                 "<tptz:PresetToken>%s</tptz:PresetToken></tptz:GotoPreset>"
                 ) % (TPTZ, _xml_kacis(self._ptz_token()), _xml_kacis(token))
        self._ptz(govde)

    def preset_kaydet(self, ad):
        govde = ('<tptz:SetPreset xmlns:tptz="%s"><tptz:ProfileToken>%s</tptz:ProfileToken>'
                 "<tptz:PresetName>%s</tptz:PresetName></tptz:SetPreset>"
                 ) % (TPTZ, _xml_kacis(self._ptz_token()), _xml_kacis(ad))
        kok = self._ptz(govde)
        t = bul_ilk(kok, "PresetToken")
        return t.text if t is not None else None


# ---------------------------------------------------------------- Keşif
_PROBE = (
    '<?xml version="1.0" encoding="UTF-8"?>'
    '<e:Envelope xmlns:e="http://www.w3.org/2003/05/soap-envelope" '
    'xmlns:w="http://schemas.xmlsoap.org/ws/2004/08/addressing" '
    'xmlns:d="http://schemas.xmlsoap.org/ws/2005/04/discovery" '
    'xmlns:dn="http://www.onvif.org/ver10/network/wsdl">'
    "<e:Header><w:MessageID>uuid:%s</w:MessageID>"
    '<w:To e:mustUnderstand="true">urn:schemas-xmlsoap-org:ws:2005:04:discovery</w:To>'
    '<w:Action e:mustUnderstand="true">http://schemas.xmlsoap.org/ws/2005/04/discovery/Probe</w:Action>'
    "</e:Header><e:Body><d:Probe><d:Types>dn:NetworkVideoTransmitter</d:Types></d:Probe></e:Body>"
    "</e:Envelope>"
)


def yerel_ipler():
    """Bilgisayarın IPv4 adresleri (çoklu ağ kartında her birinden keşif için)."""
    ipler = set()
    try:
        for bilgi in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ip = bilgi[4][0]
            if not ip.startswith("127."):
                ipler.add(ip)
    except Exception:
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ipler.add(s.getsockname()[0])
        s.close()
    except Exception:
        pass
    return sorted(ipler) or [""]


def ayristir_yanit(veri):
    """WS-Discovery yanıtından {'ip','port','ad','donanim'} çıkarır."""
    try:
        kok = ET.fromstring(veri)
    except ET.ParseError:
        return None
    xaddrs = bul_ilk(kok, "XAddrs")
    if xaddrs is None or not xaddrs.text:
        return None
    for adres in xaddrs.text.split():
        u = urlparse(adres)
        if u.hostname and re.match(r"^\d+\.\d+\.\d+\.\d+$", u.hostname):
            scopes = bul_ilk(kok, "Scopes")
            kapsam = (scopes.text or "") if scopes is not None else ""
            ad = donanim = ""
            m = re.search(r"onvif://www\.onvif\.org/name/(\S+)", kapsam)
            if m:
                ad = m.group(1).replace("%20", " ")
            m = re.search(r"onvif://www\.onvif\.org/hardware/(\S+)", kapsam)
            if m:
                donanim = m.group(1).replace("%20", " ")
            return {"ip": u.hostname, "port": u.port or 80, "ad": ad, "donanim": donanim}
    return None


def kesfet(sure=3.0):
    """Ağdaki ONVIF kameraları bulur. [{'ip','port','ad','donanim'}] döndürür."""
    bulunan = {}
    soketler = []
    for yerel in yerel_ipler():
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 4)
            if yerel:
                s.bind((yerel, 0))
                s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_IF, socket.inet_aton(yerel))
            else:
                s.bind(("", 0))
            s.settimeout(0.3)
            s.sendto((_PROBE % uuid.uuid4()).encode(), ("239.255.255.250", 3702))
            soketler.append(s)
        except OSError:
            continue
    bitis = time.time() + sure
    while time.time() < bitis and soketler:
        for s in soketler:
            try:
                veri, _ = s.recvfrom(65535)
            except (socket.timeout, OSError):
                continue
            kayit = ayristir_yanit(veri)
            if kayit:
                bulunan[kayit["ip"]] = kayit
    for s in soketler:
        try:
            s.close()
        except Exception:
            pass
    return sorted(bulunan.values(), key=lambda k: tuple(int(x) for x in k["ip"].split(".")))
