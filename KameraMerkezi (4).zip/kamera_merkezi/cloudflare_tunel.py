# -*- coding: utf-8 -*-
"""
Cloudflare Tunnel (cloudflared) yöneticisi.
- Kendi tüneliniz: Cloudflare Zero Trust'tan alınan token ile `cloudflared tunnel run`
- Hızlı tünel: hesap gerektirmeyen geçici *.trycloudflare.com adresi
"""
import collections
import os
import platform
import re
import shutil
import struct
import subprocess
import sys
import tempfile
import threading
import urllib.request
from pathlib import Path

_WIN = sys.platform.startswith("win")
_CREATE_NO_WINDOW = 0x08000000

_TOKEN_RE = re.compile(r"eyJ[A-Za-z0-9+/=_\-]{30,}")
_HIZLI_RE = re.compile(r"https://[a-z0-9\-]+\.trycloudflare\.com")
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")


def token_ayikla(metin):
    """Kullanıcı tüm komutu (cloudflared.exe service install eyJ...) yapıştırsa bile token'ı bulur."""
    metin = (metin or "").strip()
    m = _TOKEN_RE.search(metin)
    if m:
        return m.group(0)
    return metin.split()[-1] if metin else ""


def token_gecerli_gorunuyor(token):
    return bool(_TOKEN_RE.fullmatch(token or ""))


def indirme_adresi():
    if _WIN:
        if platform.machine().lower() in ("arm64", "aarch64"):
            mimari = "arm64"
        elif struct.calcsize("P") * 8 == 32 and "64" not in platform.machine():
            mimari = "386"
        else:
            mimari = "amd64"
        ad = "cloudflared-windows-%s.exe" % mimari
    elif sys.platform == "darwin":
        ad = "cloudflared-darwin-%s.tgz" % ("arm64" if platform.machine() == "arm64" else "amd64")
    else:
        ad = "cloudflared-linux-%s" % ("arm64" if platform.machine() in ("aarch64", "arm64") else "amd64")
    return "https://github.com/cloudflare/cloudflared/releases/latest/download/" + ad


def varsayilan_konum(ayar_klasoru):
    return Path(ayar_klasoru) / ("cloudflared.exe" if _WIN else "cloudflared")


def bul(ozel_yol="", ayar_klasoru=None):
    """cloudflared çalıştırılabilir dosyasının yolunu döndürür (yoksa None)."""
    adaylar = []
    if ozel_yol:
        adaylar.append(ozel_yol)
    if ayar_klasoru:
        adaylar.append(str(varsayilan_konum(ayar_klasoru)))
    uygulama = Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve().parent
    adaylar.append(str(uygulama / ("cloudflared.exe" if _WIN else "cloudflared")))
    yol = shutil.which("cloudflared")
    if yol:
        adaylar.append(yol)
    if _WIN:
        for kok in (os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles")):
            if kok:
                adaylar.append(str(Path(kok) / "cloudflared" / "cloudflared.exe"))
    for a in adaylar:
        try:
            if a and Path(a).is_file():
                return str(a)
        except OSError:
            continue
    return None


def surum(yol):
    """`cloudflared --version` çıktısını döndürür; çalışmazsa None."""
    try:
        kw = {"creationflags": _CREATE_NO_WINDOW} if _WIN else {}
        c = subprocess.run([yol, "--version"], capture_output=True, text=True, timeout=15,
                           encoding="utf-8", errors="replace", **kw)
        metin = (c.stdout or c.stderr or "").strip().splitlines()
        return metin[0] if metin and c.returncode == 0 else None
    except (OSError, subprocess.SubprocessError):
        return None


def indir(hedef, ilerleme=None, adres=None):
    """cloudflared'i GitHub sürümlerinden indirir. hedef: tam dosya yolu."""
    adres = adres or indirme_adresi()
    if adres.endswith(".tgz"):
        raise RuntimeError("Bu işletim sisteminde otomatik indirme desteklenmiyor; elle kurun.")
    hedef = Path(hedef)
    hedef.parent.mkdir(parents=True, exist_ok=True)
    gecici = None
    try:
        with urllib.request.urlopen(adres, timeout=30) as yanit:
            toplam = int(yanit.headers.get("Content-Length") or 0)
            fd, gecici = tempfile.mkstemp(dir=str(hedef.parent), suffix=".indiriliyor")
            alinan = 0
            with os.fdopen(fd, "wb") as f:
                while True:
                    parca = yanit.read(256 * 1024)
                    if not parca:
                        break
                    f.write(parca)
                    alinan += len(parca)
                    if ilerleme and toplam:
                        ilerleme(alinan / float(toplam))
        if alinan < 1_000_000:
            raise RuntimeError("İndirilen dosya beklenenden küçük; indirme başarısız.")
        if not _WIN:
            os.chmod(gecici, 0o755)
        os.replace(gecici, str(hedef))
        gecici = None
    finally:
        if gecici and os.path.exists(gecici):
            try:
                os.remove(gecici)
            except OSError:
                pass
    return str(hedef)


class TunelYoneticisi:
    """cloudflared sürecini başlatır/durdurur, çıktısını izler, koparsa yeniden başlatır."""

    def __init__(self, gunluk=None):
        self._gunluk = gunluk or (lambda seviye, mesaj: None)
        self.durum = "durdu"          # durdu | baslatiliyor | bagli | hata
        self.adres = None             # hızlı tünelde https://xxxx.trycloudflare.com
        self.son_hata = ""
        self.satirlar = collections.deque(maxlen=60)
        self._proc = None
        self._thr = None
        self._dur = threading.Event()
        self._token = ""
        self._kilit = threading.Lock()

    def calisiyor(self):
        return self._thr is not None and self._thr.is_alive()

    def log(self, seviye, mesaj):
        try:
            self._gunluk(seviye, mesaj)
        except Exception:
            pass

    def _maskele(self, satir):
        if self._token:
            satir = satir.replace(self._token, "***")
        return _TOKEN_RE.sub("***", satir)

    def baslat(self, yol, mod, token="", port=8787):
        """mod: 'adli' (token ile) veya 'hizli' (geçici adres)."""
        with self._kilit:
            if self.calisiyor():
                raise RuntimeError("Tünel zaten çalışıyor.")
            if mod == "adli":
                token = token_ayikla(token)
                if not token_gecerli_gorunuyor(token):
                    raise ValueError("Token geçersiz görünüyor. Cloudflare Zero Trust → Networks → Tunnels → "
                                     "tünelinizi seçin → kurulum komutundaki 'eyJ...' ile başlayan değeri yapıştırın.")
                komut = [yol, "tunnel", "--no-autoupdate", "run", "--token", token]
            elif mod == "hizli":
                komut = [yol, "tunnel", "--no-autoupdate", "--url", "http://127.0.0.1:%d" % int(port)]
                token = ""
            else:
                raise ValueError("Bilinmeyen tünel modu.")
            self._token = token
            self._dur.clear()
            self.adres = None
            self.son_hata = ""
            self.satirlar.clear()
            self.durum = "baslatiliyor"
            self._thr = threading.Thread(target=self._calis, args=(komut,), daemon=True)
            self._thr.start()

    def durdur(self, bekle=4.0):
        with self._kilit:
            self._dur.set()
            proc = self._proc
            thr = self._thr
        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                try:
                    proc.wait(timeout=bekle)
                except subprocess.TimeoutExpired:
                    proc.kill()
            except OSError:
                pass
        if thr is not None and thr.is_alive() and threading.current_thread() is not thr:
            thr.join(bekle)
            if thr.is_alive():          # hâlâ kapanmadıysa (ör. süreç geç oluştu) zorla kapat
                p2 = self._proc
                if p2 is not None and p2.poll() is None:
                    try:
                        p2.kill()
                    except OSError:
                        pass
                thr.join(2.0)
        self.durum = "durdu"
        self.adres = None

    def _calis(self, komut):
        deneme = 0
        while not self._dur.is_set():
            self.durum = "baslatiliyor"
            kw = {"creationflags": _CREATE_NO_WINDOW} if _WIN else {}
            try:
                proc = subprocess.Popen(komut, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                        stdin=subprocess.DEVNULL, text=True, encoding="utf-8",
                                        errors="replace", **kw)
            except OSError as e:
                self.durum = "hata"
                self.son_hata = "cloudflared başlatılamadı: %s" % e
                self.log("HATA", self.son_hata)
                return
            self._proc = proc
            if self._dur.is_set():
                # Popen sürerken durdur() çağrıldıysa o, bu süreci göremedi: açık tünel kalmasın diye hemen kapat
                try:
                    proc.terminate()
                except OSError:
                    pass
            self.log("BİLGİ", "Cloudflare tüneli başlatılıyor")
            try:
                for ham in proc.stdout:
                    self._satir_isle(ham.rstrip("\r\n"))
            except Exception:
                pass
            try:
                proc.wait(timeout=5)
            except Exception:
                pass
            if self._dur.is_set():
                break
            self.durum = "hata"
            self.adres = None
            bekle = min(60, 5 * (deneme + 1))
            deneme += 1
            self.log("AĞ", "Cloudflare tüneli kapandı; %d sn sonra yeniden denenecek" % bekle)
            if self._dur.wait(bekle):
                break
        self.durum = "durdu"

    def _satir_isle(self, ham):
        satir = self._maskele(_ANSI_RE.sub("", ham)).strip()
        if not satir:
            return
        self.satirlar.append(satir)
        m = _HIZLI_RE.search(satir)
        if m and m.group(0) != "https://api.trycloudflare.com":
            self.adres = m.group(0)
            self.log("BİLGİ", "Hızlı tünel adresi: %s" % self.adres)
        if "Registered tunnel connection" in satir:
            if self.durum != "bagli":
                self.log("BİLGİ", "Cloudflare tüneli bağlandı")
            self.durum = "bagli"
            self.son_hata = ""
        elif re.search(r"\bERR\b", satir):
            ozet = satir.split(" ERR ", 1)[-1][:160]
            self.son_hata = ozet
            if self.durum != "bagli" or "token" in satir.lower():
                self.log("HATA", "cloudflared: %s" % ozet)
