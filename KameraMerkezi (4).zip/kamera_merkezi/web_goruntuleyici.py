# -*- coding: utf-8 -*-
"""
Uzaktan izleme ve kontrol için küçük web sunucusu.
YALNIZCA 127.0.0.1 üzerinde dinler (cloudflared tüneli buraya bağlanır), kullanıcı adı + şifre ister.

Özellikler: canlı görüntü, fotoğraf, PTZ (yön, ana konum, preset), elle kayıt başlat/durdur,
kayıtları listeleme / küçük resim / oynatma / indirme.

Güvenlik notları:
- Değiştirici işlemler (POST) özel başlık (X-Kamera) ve JSON içerik türü ister; başka sitelerden
  tarayıcı üzerinden tetiklenemez (CSRF).
- Kayıt dosyaları yalnızca kayıt klasörlerinden ve yalnızca <ad>.mp4 biçimindeki adlarla sunulur.
- Kontrol ve kayıt izleme izinleri ayrı ayrı kapatılabilir.
"""
import base64
import hmac
import json
import math
import re
import threading
import time
import datetime as dt
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

import cv2

from kamera_motoru import guvenli_ad

DOSYA_RE = re.compile(r"^[A-Za-z0-9_\-]{1,120}\.mp4$")
KAYIT_SAYISI_SINIRI = 300

SAYFA = """<!doctype html>
<html lang="tr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#0A0E16"><title>Kamera Merkezi</title>
<style>
:root{color-scheme:dark;--bg:#0A0E16;--panel:#0E131D;--kart:#121826;--kenar:#1B2333;--metin:#EEF2FA;--soluk:#6F7B91;--vurgu:#5B7CFF;--yesil:#34D399;--kirmizi:#FF4D5E;--sari:#F5B94A}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
html,body{margin:0;background:var(--bg);color:var(--metin);font:14px/1.45 "Segoe UI",system-ui,-apple-system,sans-serif}
header{display:flex;flex-wrap:wrap;gap:10px;align-items:center;justify-content:space-between;padding:14px 18px;border-bottom:1px solid var(--kenar)}
header b{font-size:19px}header small{display:block;color:var(--soluk);font-size:12px}
nav{display:flex;gap:8px}
button,select,a.dugme{font:inherit;color:var(--metin);background:var(--kart);border:1px solid var(--kenar);border-radius:12px;padding:9px 14px;cursor:pointer;text-decoration:none;display:inline-block}
button:hover,a.dugme:hover{background:#18233A}
button.aktif{background:var(--vurgu);border-color:var(--vurgu)}
button.kirmizi{background:var(--kirmizi);border-color:var(--kirmizi)}
button:disabled{opacity:.5;cursor:default}
main{max-width:1180px;margin:0 auto;padding:16px}
.sekmeler{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px}
.sekme i{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:8px;background:var(--kirmizi)}
.sekme i.on{background:var(--yesil)}
.canli{display:grid;gap:16px;grid-template-columns:minmax(0,1fr) 300px}
@media(max-width:880px){.canli{grid-template-columns:1fr}}
.video{position:relative;background:#000;border:1px solid var(--kenar);border-radius:18px;overflow:hidden;aspect-ratio:16/9}
.video img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain}
.rozet{position:absolute;top:12px;padding:5px 12px;border-radius:999px;font-size:12px;font-weight:700;background:rgba(10,14,22,.82)}
.rozet.kayit{left:12px;background:var(--kirmizi)}
.rozet.off{right:12px;color:var(--sari)}
.alt{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px;align-items:center}
.alt select{padding:9px 10px}
.panel{background:var(--panel);border:1px solid var(--kenar);border-radius:18px;padding:16px}
.panel h3{margin:0 0 10px;font-size:15px}
.etiket{color:var(--soluk);font-size:11px;font-weight:700;letter-spacing:.08em;margin:14px 0 6px}
.pad{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:240px;margin:0 auto}
.pad button{height:62px;font-size:22px;padding:0;touch-action:none;user-select:none;-webkit-user-select:none}
.pad button.ana{background:var(--vurgu);border-color:var(--vurgu)}
input[type=range]{width:100%;accent-color:var(--vurgu)}
.satir{display:flex;gap:8px}.satir select{flex:1;min-width:0}
.durum{min-height:20px;margin-top:10px;font-size:12px;color:var(--soluk)}
.durum.hata{color:var(--kirmizi)}
.liste{display:grid;gap:14px;grid-template-columns:repeat(auto-fill,minmax(230px,1fr))}
.kk{background:var(--kart);border:1px solid var(--kenar);border-radius:16px;overflow:hidden;cursor:pointer}
.kk img{display:block;width:100%;aspect-ratio:16/9;object-fit:cover;background:#0b0f17}
.ka{padding:10px 12px}.ka b{display:block}.ka span{color:var(--soluk);font-size:12px}
.ka em{display:block;color:var(--kirmizi);font-size:12px;font-style:normal}
.ust{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
.bos{padding:30px;color:var(--soluk)}
.arac{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:12px}
.arac .et{color:var(--soluk);font-size:11px;font-weight:700;letter-spacing:.08em;margin-right:4px}
.dz{padding:6px 10px;display:inline-flex;align-items:center;gap:7px}
.dz .mini{position:relative;width:24px;height:16px;display:block}
.dz .mini i{position:absolute;background:var(--soluk);border-radius:1px}
.dz.aktif .mini i{background:#fff}
.dz span{font-weight:700;font-size:13px}
.bosluk{flex:1}
.izgara{display:grid;gap:8px;height:calc(100vh - 270px);min-height:340px}
.izgara.mobil{height:auto;min-height:0}
.izgara.mobil .karo{aspect-ratio:16/9}
.karo{position:relative;background:#000;border:2px solid var(--kenar);border-radius:14px;overflow:hidden;min-width:0;min-height:0;cursor:pointer}
.karo.secili{border-color:var(--vurgu)}
.karo img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain}
.k-ust{position:absolute;left:6px;right:6px;top:6px;display:flex;gap:6px;align-items:center;padding:4px 10px;border-radius:10px;background:rgba(10,14,22,.82);font-size:12px;pointer-events:none}
.k-ust b{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.k-ust .dur{font-weight:700;font-size:11px;color:var(--kirmizi)}.k-ust .dur.on{color:var(--yesil)}
.k-ust .kay{font-weight:700;font-size:11px;color:#fff;background:var(--kirmizi);border-radius:999px;padding:1px 8px}
.k-alt{position:absolute;right:8px;bottom:8px;display:flex;gap:6px}
.k-alt button{padding:5px 9px;border-radius:999px;background:rgba(10,14,22,.82);font-size:14px;line-height:1}
.karo.bos{display:flex;align-items:center;justify-content:center;border-style:dashed;color:var(--soluk);background:transparent;font-size:15px}
.menu{position:fixed;z-index:20;background:var(--panel);border:1px solid var(--kenar);border-radius:12px;padding:6px;min-width:190px;max-width:90vw;box-shadow:0 10px 30px rgba(0,0,0,.5)}
.menu button{display:block;width:100%;text-align:left;border:0;background:transparent;border-radius:8px}
.menu button:hover{background:#18233A}
.menu hr{border:0;border-top:1px solid var(--kenar);margin:4px 0}
.izgara:fullscreen{height:100vh;padding:6px;background:#000}
.p-kam{color:var(--soluk);font-weight:400;font-size:12px}
.ort{position:fixed;inset:0;background:rgba(5,8,14,.92);z-index:10;display:flex;align-items:center;justify-content:center;padding:14px}
.ort[hidden]{display:none}
.oyn{width:100%;max-width:1000px;background:var(--panel);border:1px solid var(--kenar);border-radius:18px;padding:14px}
.oyn .video{border-radius:12px}
.oyn canvas{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;display:none}
.kontrol-satiri{display:flex;gap:8px;align-items:center;margin-top:10px;flex-wrap:wrap}
.kontrol-satiri input{flex:1;min-width:160px}
.not{color:var(--soluk);font-size:11px;margin-top:8px}
[hidden]{display:none!important}
</style></head><body>
<header><div><b>Kamera Merkezi</b><small id="alt-baslik">Uzaktan erişim</small></div>
<nav><button id="n-canli" class="aktif">Canlı</button><button id="n-kayit">Kayıtlar</button></nav></header>

<main id="s-canli">
<div class="arac"><span class="et">GÖRÜNÜM</span><span id="duzenler" style="display:flex;gap:6px;flex-wrap:wrap"></span><span class="bosluk"></span><button id="b-tam" hidden>&#9974; Tam ekran</button></div>
<div class="sekmeler" id="sekmeler"></div>
<div class="canli">
 <div>
  <div class="izgara" id="izgara"></div>
  <div class="alt">
   <button id="b-kayit" class="kontrol">Kayıt başlat</button>
   <button id="b-foto">Fotoğraf</button>
   <select id="kalite" title="En yüksek görüntü kalitesi (küçük karolarda otomatik düşürülür)"><option value="640">Düşük</option><option value="960" selected>Orta</option><option value="1280">Yüksek</option></select>
  </div>
 </div>
 <div class="panel kontrol" id="p-ptz">
  <h3>Kamera kontrolü <span class="p-kam" id="p-kamera"></span></h3>
  <div class="pad" id="pad">
   <button data-x="-1" data-y="1">&#8598;</button><button data-x="0" data-y="1">&#8593;</button><button data-x="1" data-y="1">&#8599;</button>
   <button data-x="-1" data-y="0">&#8592;</button><button class="ana" id="b-ana">&#8962;</button><button data-x="1" data-y="0">&#8594;</button>
   <button data-x="-1" data-y="-1">&#8601;</button><button data-x="0" data-y="-1">&#8595;</button><button data-x="1" data-y="-1">&#8600;</button>
  </div>
  <div class="etiket">HIZ <span id="hiz-d">0.5</span></div>
  <input type="range" id="hiz" min="0.1" max="1" step="0.1" value="0.5">
  <div class="etiket">KONUM HAFIZASI</div>
  <div class="satir"><select id="preset"></select><button id="b-preset">Git</button></div>
  <div class="durum" id="durum"></div>
 </div>
</div>
</main>

<main id="s-kayit" hidden>
 <div class="ust"><b id="kayit-bilgi">Kayıtlar</b><button id="b-yenile">Yenile</button></div>
 <div class="liste" id="liste"></div>
</main>

<div class="ort" id="oynatici" hidden>
 <div class="oyn">
  <div class="ust"><b id="o-baslik"></b><button id="o-kapat">Kapat</button></div>
  <div class="video"><img id="o-img" alt=""><canvas id="o-tuval"></canvas></div>
  <div class="kontrol-satiri">
   <button id="o-oynat">Duraklat</button>
   <input type="range" id="o-kaydir" min="0" max="1" step="1" value="0">
   <span id="o-zaman">0:00</span>
  </div>
  <div class="kontrol-satiri">
   <button data-hiz="1" class="aktif">1x</button><button data-hiz="2">2x</button><button data-hiz="4">4x</button><button data-hiz="8">8x</button>
   <a class="dugme" id="o-indir" download>İndir</a>
   <span class="durum" id="o-durum"></span>
  </div>
  <div class="not">Kayıtlar tarayıcı uyumluluğu için sunucuda çözülüp görüntü olarak akıtılır (ses yoktur). Orijinal dosyayı &ldquo;İndir&rdquo; ile alabilirsiniz.</div>
 </div>
</div>

<script>
var $=function(s){return document.querySelector(s)};
var D={kam:[],aktif:null,ayar:{kontrol:false,kayit_izle:false},tut:null,sekme:'canli'};
function api(yol,govde){
  var o=govde===undefined?{}:{method:'POST',headers:{'Content-Type':'application/json','X-Kamera':'1'},body:JSON.stringify(govde)};
  return fetch(yol,o).then(function(r){return r.json().catch(function(){return {}}).then(function(j){
    if(!r.ok)throw new Error(j.hata||('Hata '+r.status));return j})})}
function bildir(m,hata){var d=$('#durum');d.textContent=m||'';d.className='durum'+(hata?' hata':'')}
function mevcut(){for(var i=0;i<D.kam.length;i++)if(D.kam[i].id===D.aktif)return D.kam[i];return null}
function ikiHane(n){return n<10?'0'+n:''+n}
function sure(s){s=Math.max(0,Math.floor(s));return Math.floor(s/60)+':'+ikiHane(s%60)}
function boyut(b){var u=['B','KB','MB','GB'],i=0;while(b>=1024&&i<3){b/=1024;i++}return (i?b.toFixed(1):b)+' '+u[i]}

/* ---------- canlı (1-6 kameralı ızgara) ---------- */
var DZ={1:{r:[1],c:[1],t:[[0,0,1,1]]},
 2:{r:[1,1],c:[1],t:[[0,0,1,1],[1,0,1,1]]},
 3:{r:[3,2],c:[1,1],t:[[0,0,1,2],[1,0,1,1],[1,1,1,1]]},
 4:{r:[1,1],c:[1,1],t:[[0,0,1,1],[0,1,1,1],[1,0,1,1],[1,1,1,1]]},
 5:{r:[1,1,1],c:[1,1],t:[[0,0,2,1],[0,1,1,1],[1,1,1,1],[2,0,1,1],[2,1,1,1]]},
 6:{r:[1,1,1],c:[1,1],t:[[0,0,1,1],[0,1,1,1],[1,0,1,1],[1,1,1,1],[2,0,1,1],[2,1,1,1]]}};
var DZ_YAN={r:[1],c:[1,1],t:[[0,0,1,1],[0,1,1,1]]};
var DZ_6_2X3={r:[1,1],c:[1,1,1],t:[[0,0,1,1],[0,1,1,1],[0,2,1,1],[1,0,1,1],[1,1,1,1],[1,2,1,1]]};
var MZ={1:{c:[1],t:[[0,0,1,1]]},2:{c:[1],t:[[0,0,1,1],[1,0,1,1]]},
 3:{c:[1,1],t:[[0,0,1,2],[1,0,1,1],[1,1,1,1]]},4:{c:[1,1],t:[[0,0,1,1],[0,1,1,1],[1,0,1,1],[1,1,1,1]]},
 5:{c:[1,1],t:[[0,0,1,2],[1,0,1,1],[1,1,1,1],[2,0,1,1],[2,1,1,1]]},6:{c:[1,1],t:[[0,0,1,1],[0,1,1,1],[1,0,1,1],[1,1,1,1],[2,0,1,1],[2,1,1,1]]}};
function telefon(){return window.matchMedia('(max-width:720px)').matches}
function duzenTanimi(n,oran){if(telefon())return MZ[n];if(n===2&&oran>=1.7)return DZ_YAN;if(n===6&&oran>=1.75)return DZ_6_2X3;return DZ[n]}
function sinirla(n){n=parseInt(n,10);return isNaN(n)?1:Math.max(1,Math.min(6,n))}
function atamaHazirla(a){var s=[];for(var i=0;i<6;i++)s.push(Array.isArray(a)&&typeof a[i]==='string'&&a[i]?a[i]:null);return s}
function atamaDuzenle(atama,idler,n){var a=atamaHazirla(atama).map(function(x){return idler.indexOf(x)>=0?x:null});
  n=sinirla(n);var goruldu={},i,g=a.slice(0,n);
  for(i=0;i<n;i++){if(g[i]===null)continue;if(goruldu[g[i]])g[i]=null;else goruldu[g[i]]=1}
  var kul=idler.filter(function(k){return !goruldu[k]});
  for(i=0;i<n&&kul.length;i++){if(g[i]===null){g[i]=kul.shift();goruldu[g[i]]=1}}
  var gizli=a.slice(n).map(function(x){if(x!==null&&!goruldu[x]){goruldu[x]=1;return x}return null});
  return g.concat(gizli)}
function atamaAta(atama,slot,id,n){var a=atamaHazirla(atama);if(slot<0||slot>5)return a;var onceki=a[slot];
  if(id!==null){for(var j=0;j<6;j++)if(j!==slot&&a[j]===id)a[j]=onceki}a[slot]=id;return a}
var DK={adet:1,atama:atamaHazirla(null),odak:null,slot:0,idler:null,dugum:{}};
function dzKaydet(){try{localStorage.setItem('km_izgara',JSON.stringify({adet:DK.adet,atama:DK.atama}))}catch(_){}}
function dzYukle(){try{var j=JSON.parse(localStorage.getItem('km_izgara')||'null');if(j&&typeof j==='object'){DK.adet=sinirla(j.adet);DK.atama=atamaHazirla(j.atama);return true}}catch(_){}return false}
function gorunenAdet(){return DK.odak!==null?1:DK.adet}
function kameraBul(id){for(var i=0;i<D.kam.length;i++)if(D.kam[i].id===id)return D.kam[i];return null}

function miniCiz(n){var m=document.createElement('span');m.className='mini';var t=DZ[n],ts=0,tc=0,i;
  t.r.forEach(function(w){ts+=w});t.c.forEach(function(w){tc+=w});
  var ys=[0],xs=[0];t.r.forEach(function(w){ys.push(ys[ys.length-1]+w/ts)});t.c.forEach(function(w){xs.push(xs[xs.length-1]+w/tc)});
  t.t.forEach(function(k){var e=document.createElement('i');
    e.style.left=(xs[k[1]]*100+(k[1]?4:0))+'%';e.style.top=(ys[k[0]]*100+(k[0]?6:0))+'%';
    e.style.width=((xs[k[1]+k[3]]-xs[k[1]])*100-(k[1]?4:0)-(k[1]+k[3]<t.c.length?4:0))+'%';
    e.style.height=((ys[k[0]+k[2]]-ys[k[0]])*100-(k[0]?6:0)-(k[0]+k[2]<t.r.length?6:0))+'%';m.appendChild(e)});
  return m}
function duzenDugmeleri(){var k=$('#duzenler');k.textContent='';
  for(var n=1;n<=6;n++){(function(n){var b=document.createElement('button');b.className='dz'+(n===DK.adet?' aktif':'');b.title=n+' kamera';
    b.appendChild(miniCiz(n));var s=document.createElement('span');s.textContent=n;b.appendChild(s);
    b.onclick=function(){duzenSec(n)};k.appendChild(b)})(n)}}
function duzenSec(n){DK.adet=sinirla(n);DK.odak=null;DK.atama=atamaDuzenle(DK.atama,DK.idler||[],DK.adet);
  var g=DK.atama.slice(0,DK.adet);if(g.indexOf(D.aktif)<0){for(var i=0;i<g.length;i++)if(g[i]){D.aktif=g[i];DK.slot=i;break}}
  else DK.slot=g.indexOf(D.aktif);
  dzKaydet();duzenDugmeleri();izgaraCiz();chipler();durumGuncelle();presetYukle();kontrolBaslik()}

function akisKapat(){var l=document.querySelectorAll('#izgara .karo img');
  Array.prototype.forEach.call(l,function(im){im.onerror=null;im.removeAttribute('src')})}
function kovaGenislik(el){var px=(el.clientWidth||320)*(window.devicePixelRatio||1);
  var w=px<=400?320:px<=560?480:px<=800?640:px<=1100?960:1280;return Math.min(w,+$('#kalite').value||960)}
function akisBaslat(el){var id=el._id;if(!id||D.sekme!=='canli'||document.hidden)return;var im=el.querySelector('img');
  el._w=kovaGenislik(el);
  im.onerror=function(){setTimeout(function(){if(el.isConnected&&el._id===id&&D.sekme==='canli'&&!document.hidden)akisBaslat(el)},2500)};
  im.src='/akis/'+encodeURIComponent(id)+'?w='+el._w+'&t='+Date.now()}
function akislariBaslat(){Array.prototype.forEach.call(document.querySelectorAll('#izgara .karo'),akisBaslat)}
function izgaraCiz(){var g=$('#izgara');akisKapat();g.textContent='';DK.dugum={};
  var n=gorunenAdet(),mob=telefon();g.className='izgara'+(mob?' mobil':'');
  var t=duzenTanimi(n,g.clientWidth/Math.max(1,g.clientHeight));
  g.style.gridTemplateColumns=t.c.map(function(w){return w+'fr'}).join(' ');
  g.style.gridTemplateRows=mob?'none':t.r.map(function(w){return w+'fr'}).join(' ');
  for(var i=0;i<n;i++){var slot=DK.odak!==null?DK.odak:i;karoKur(g,slot,t.t[i])}
  if(D.sekme==='canli')akislariBaslat()}
function karoKur(g,slot,yer){var id=DK.atama[slot],el=document.createElement('div');el.className='karo';el._slot=slot;el._id=id;
  el.style.gridRow=(yer[0]+1)+' / span '+yer[2];el.style.gridColumn=(yer[1]+1)+' / span '+yer[3];DK.dugum[slot]=el;
  if(!id||!kameraBul(id)){el._id=null;el.className='karo bos';el.textContent='+ Kamera ata';el.onclick=function(e){menuAc(slot,e)};g.appendChild(el);return}
  var im=document.createElement('img');im.alt='';el.appendChild(im);
  var u=document.createElement('div');u.className='k-ust';var b=document.createElement('b');b.textContent=kameraBul(id).ad;u.appendChild(b);
  var d=document.createElement('span');d.className='dur';u.appendChild(d);var ky=document.createElement('span');ky.className='kay';ky.textContent='KAYIT';ky.hidden=true;u.appendChild(ky);el.appendChild(u);
  var a=document.createElement('div');a.className='k-alt';
  var bo=document.createElement('button');bo.textContent=DK.odak!==null?'⤢':'⛶';bo.title='Büyüt / küçült';bo.onclick=function(e){e.stopPropagation();odakDegistir(slot)};a.appendChild(bo);
  var bf=document.createElement('button');bf.textContent='📷';bf.title='Fotoğraf';bf.onclick=function(e){e.stopPropagation();window.open('/foto/'+encodeURIComponent(id),'_blank')};a.appendChild(bf);
  var bm=document.createElement('button');bm.textContent='⚙';bm.title='Bu karoya başka kamera ata';bm.onclick=function(e){e.stopPropagation();menuAc(slot,e)};a.appendChild(bm);
  el.appendChild(a);
  el.onclick=function(){sec(id,slot)};el.ondblclick=function(){odakDegistir(slot)};
  g.appendChild(el);rozetTek(el);el.classList.toggle('secili',id===D.aktif)}
function rozetTek(el){var c=el._id&&kameraBul(el._id);if(!c)return;var d=el.querySelector('.dur');
  d.textContent=c.durum==='cevrimici'?'● CANLI':'● YOK';d.className='dur'+(c.durum==='cevrimici'?' on':'');el.querySelector('.kay').hidden=!c.kayit}
function rozetGuncelle(){for(var s in DK.dugum)rozetTek(DK.dugum[s])}
function odakDegistir(slot){DK.odak=DK.odak!==null?null:(DK.atama[slot]?slot:null);izgaraCiz()}
function menuKapat(){var m=$('#menu');if(m)m.remove()}
function menuAc(slot,e){menuKapat();var m=document.createElement('div');m.className='menu';m.id='menu';
  D.kam.forEach(function(c){var b=document.createElement('button');var gor=DK.atama.slice(0,DK.adet).indexOf(c.id)>=0;
    b.textContent=(DK.atama[slot]===c.id?'✓ ':gor?'● ':'   ')+c.ad;b.onclick=function(){menuKapat();karoyaAta(slot,c.id)};m.appendChild(b)});
  if(DK.atama[slot]){m.appendChild(document.createElement('hr'));var b=document.createElement('button');b.textContent='Karoyu boşalt';b.onclick=function(){menuKapat();karoyaAta(slot,null)};m.appendChild(b)}
  document.body.appendChild(m);var x=Math.min(e.clientX,window.innerWidth-m.offsetWidth-8),y=Math.min(e.clientY,window.innerHeight-m.offsetHeight-8);
  m.style.left=Math.max(8,x)+'px';m.style.top=Math.max(8,y)+'px';
  setTimeout(function(){document.addEventListener('click',menuKapat,{once:true})},0)}
function karoyaAta(slot,id){DK.atama=atamaAta(DK.atama,slot,id,DK.adet);DK.slot=slot;dzKaydet();
  if(id){D.aktif=id}else if(DK.atama.slice(0,DK.adet).indexOf(D.aktif)<0){for(var i=0;i<DK.adet;i++)if(DK.atama[i]){D.aktif=DK.atama[i];break}}
  izgaraCiz();chipler();durumGuncelle();presetYukle();kontrolBaslik()}
function secimIsaretle(){for(var s in DK.dugum){var el=DK.dugum[s];el.classList.toggle('secili',!!el._id&&el._id===D.aktif)}}
function chipler(){var k=$('#sekmeler');k.textContent='';
  D.kam.forEach(function(c){var b=document.createElement('button');b.className='sekme'+(c.id===D.aktif?' aktif':'');
    var i=document.createElement('i');if(c.durum==='cevrimici')i.className='on';b.appendChild(i);
    b.appendChild(document.createTextNode(c.ad));b.onclick=function(){sec(c.id)};k.appendChild(b)})}
function kontrolBaslik(){var c=mevcut();$('#p-kamera').textContent=c?'· '+c.ad:''}
function durumGuncelle(){var c=mevcut();if(!c)return;
  var b=$('#b-kayit');b.textContent=c.manuel?'Kaydı durdur':'Kayıt başlat';b.className='kontrol'+(c.manuel?' kirmizi':'')}
function sec(id,slot){var onceki=D.aktif;D.aktif=id;
  var g=DK.atama.slice(0,gorunenAdet());
  if(DK.odak!==null&&DK.atama[DK.odak]!==id){DK.atama=atamaAta(DK.atama,DK.odak,id,DK.adet);dzKaydet();izgaraCiz()}
  else if(g.indexOf(id)<0&&DK.odak===null){var s=DK.slot<DK.adet?DK.slot:0;DK.atama=atamaAta(DK.atama,s,id,DK.adet);DK.slot=s;dzKaydet();izgaraCiz()}
  else{if(slot!==undefined)DK.slot=slot;else DK.slot=Math.max(0,g.indexOf(id));secimIsaretle()}
  chipler();durumGuncelle();kontrolBaslik();if(onceki!==id)presetYukle()}
function yokla(){return api('/api/kameralar').then(function(l){D.kam=l;var idler=l.map(function(c){return c.id}),degisti=JSON.stringify(idler)!==JSON.stringify(DK.idler);
  DK.idler=idler;
  if(degisti){if(!DK.ilk){DK.ilk=true;if(!dzYukle())DK.adet=Math.max(1,Math.min(6,l.length))}
    DK.atama=atamaDuzenle(DK.atama,idler,DK.adet);if(DK.odak!==null&&!DK.atama[DK.odak])DK.odak=null;
    if(!mevcut()||DK.atama.slice(0,gorunenAdet()).indexOf(D.aktif)<0){D.aktif=null;for(var i=0;i<gorunenAdet();i++){var s=DK.odak!==null?DK.odak:i;if(DK.atama[s]){D.aktif=DK.atama[s];break}}}
    dzKaydet();duzenDugmeleri();izgaraCiz();chipler();kontrolBaslik();durumGuncelle()}
  else{rozetGuncelle();chipler();durumGuncelle()}}).catch(function(){})}
function presetYukle(){var s=$('#preset');s.textContent='';if(!D.ayar.kontrol||!D.aktif)return;
  api('/api/preset/'+encodeURIComponent(D.aktif)).then(function(l){
    if(!l.length){var o=document.createElement('option');o.textContent='(kayıtlı konum yok)';o.value='';s.appendChild(o);return}
    l.forEach(function(p){var o=document.createElement('option');o.value=p.token;o.textContent=p.ad;s.appendChild(o)})
  }).catch(function(e){bildir(e.message,true)})}
function ptz(g){if(!D.aktif)return;api('/api/ptz/'+encodeURIComponent(D.aktif),g).then(function(){bildir('')}).catch(function(e){bildir(e.message,true)})}

function padKur(){
  var bs=document.querySelectorAll('#pad button[data-x]');
  Array.prototype.forEach.call(bs,function(b){
    var x=+b.dataset.x,y=+b.dataset.y;
    var gonder=function(){ptz({eylem:'hareket',x:x,y:y,hiz:+$('#hiz').value})};
    var birak=function(){if(D.tut){clearInterval(D.tut);D.tut=null;ptz({eylem:'dur'})}};
    b.addEventListener('pointerdown',function(e){e.preventDefault();try{b.setPointerCapture(e.pointerId)}catch(_){}
      gonder();clearInterval(D.tut);D.tut=setInterval(gonder,700)});
    b.addEventListener('pointerup',birak);b.addEventListener('pointercancel',birak);b.addEventListener('lostpointercapture',birak);
    b.addEventListener('contextmenu',function(e){e.preventDefault()});
  });
  $('#b-ana').onclick=function(){ptz({eylem:'ana'})};
  $('#b-preset').onclick=function(){var t=$('#preset').value;if(t)ptz({eylem:'preset',token:t})};
  $('#hiz').oninput=function(){$('#hiz-d').textContent=this.value};
}

/* ---------- kayıtlar ---------- */
function kayitlariYukle(){return api('/api/kayitlar').then(function(j){
  var g=$('#liste');g.textContent='';$('#kayit-bilgi').textContent=j.toplam+' kayıt';
  if(!j.kayitlar.length){var b=document.createElement('div');b.className='bos';b.textContent='Henüz kayıt yok.';g.appendChild(b);return}
  j.kayitlar.forEach(function(k){
    var kart=document.createElement('div');kart.className='kk';
    var im=document.createElement('img');im.loading='lazy';im.alt='';if(!k.aktif)im.src='/kayit-kucuk/'+encodeURIComponent(k.ad);kart.appendChild(im);
    var a=document.createElement('div');a.className='ka';var t=document.createElement('b');t.textContent=k.kamera;
    var s=document.createElement('span');s.textContent=k.tarih+' · '+boyut(k.boyut)+(k.sure?(' · '+sure(k.sure)):'');
    a.appendChild(t);a.appendChild(s);
    if(k.aktif){var r=document.createElement('em');r.textContent='● kayıt sürüyor';a.appendChild(r)}
    kart.appendChild(a);if(!k.aktif)kart.onclick=function(){oynatAc(k)};g.appendChild(kart)})
}).catch(function(e){$('#kayit-bilgi').textContent=e.message})}

var P={ad:null,sure:0,bas:0,t0:0,hiz:1,oynuyor:false,zt:null,surukle:false,gizle:null};
function oImg(){return $('#o-img')}
function konum(){var k=P.bas+(P.oynuyor?(Date.now()-P.t0)/1000*P.hiz:0);return P.sure?Math.min(P.sure,k):k}
function tuvalGizle(){$('#o-tuval').style.display='none'}
function dondur(){var im=oImg(),c=$('#o-tuval');
  try{if(im.naturalWidth){c.width=im.naturalWidth;c.height=im.naturalHeight;c.getContext('2d').drawImage(im,0,0);c.style.display='block'}}catch(_){}
  im.removeAttribute('src')}
function oyna(bas){P.bas=bas;P.t0=Date.now();P.oynuyor=true;$('#o-durum').textContent='';
  var im=oImg();im.onload=tuvalGizle;clearTimeout(P.gizle);P.gizle=setTimeout(tuvalGizle,1500);
  im.src='/kayit-akis/'+encodeURIComponent(P.ad)+'?basla='+Math.floor(bas)+'&hiz='+P.hiz+'&t='+Date.now();
  $('#o-oynat').textContent='Duraklat'}
function duraklat(){P.bas=konum();P.oynuyor=false;dondur();$('#o-oynat').textContent='Oynat'}
function tikla(){var k=konum();$('#o-zaman').textContent=sure(k)+(P.sure?' / '+sure(P.sure):'');
  if(!P.surukle)$('#o-kaydir').value=Math.floor(k);
  if(P.oynuyor&&P.sure&&k>=P.sure-0.3){P.bas=P.sure;P.oynuyor=false;$('#o-oynat').textContent='Baştan oynat';$('#o-durum').textContent='Bitti'}}
function oynatAc(k){P.ad=k.ad;P.sure=0;P.hiz=1;tuvalGizle();
  $('#o-baslik').textContent=k.kamera+' · '+k.tarih;$('#o-indir').href='/kayit-indir/'+encodeURIComponent(k.ad);
  var bs=document.querySelectorAll('[data-hiz]');Array.prototype.forEach.call(bs,function(b){b.className=b.dataset.hiz==='1'?'aktif':''});
  $('#oynatici').hidden=false;$('#o-durum').textContent='Açılıyor…';
  api('/api/kayit-bilgi/'+encodeURIComponent(k.ad)).then(function(b){
    P.sure=b.sure||0;var s=$('#o-kaydir');s.max=Math.max(1,Math.floor(P.sure));s.value=0;oyna(0);
    clearInterval(P.zt);P.zt=setInterval(tikla,300)
  }).catch(function(e){$('#o-durum').textContent=e.message})}
function oynatKapat(){clearInterval(P.zt);clearTimeout(P.gizle);P.oynuyor=false;oImg().removeAttribute('src');tuvalGizle();$('#oynatici').hidden=true}
function oynatKur(){
  $('#o-kapat').onclick=oynatKapat;
  $('#o-oynat').onclick=function(){if(P.oynuyor)duraklat();else oyna(P.sure&&P.bas>=P.sure-0.3?0:P.bas)};
  var s=$('#o-kaydir');
  s.oninput=function(){P.surukle=true;$('#o-zaman').textContent=sure(+s.value)+(P.sure?' / '+sure(P.sure):'')};
  s.onchange=function(){P.surukle=false;oyna(+s.value)};
  Array.prototype.forEach.call(document.querySelectorAll('[data-hiz]'),function(b){b.onclick=function(){
    P.hiz=+b.dataset.hiz;Array.prototype.forEach.call(document.querySelectorAll('[data-hiz]'),function(x){x.className=x===b?'aktif':''});
    if(P.oynuyor)oyna(konum())}});
  document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!$('#oynatici').hidden)oynatKapat()});
}

/* ---------- sekmeler ---------- */
function sekmeGit(ad){D.sekme=ad;
  $('#s-canli').hidden=ad!=='canli';$('#s-kayit').hidden=ad!=='kayit';
  $('#n-canli').className=ad==='canli'?'aktif':'';$('#n-kayit').className=ad==='kayit'?'aktif':'';
  if(ad==='canli'){izgaraCiz()}else{akisKapat();kayitlariYukle()}}

$('#n-canli').onclick=function(){sekmeGit('canli')};
$('#n-kayit').onclick=function(){sekmeGit('kayit')};
$('#b-yenile').onclick=kayitlariYukle;
$('#b-foto').onclick=function(){if(D.aktif)window.open('/foto/'+encodeURIComponent(D.aktif),'_blank')};
$('#kalite').onchange=akislariBaslat;
if(document.documentElement.requestFullscreen||$('#izgara').requestFullscreen){$('#b-tam').hidden=false}
$('#b-tam').onclick=function(){var g=$('#izgara');if(document.fullscreenElement)document.exitFullscreen();else if(g.requestFullscreen)g.requestFullscreen()};
document.addEventListener('fullscreenchange',function(){setTimeout(izgaraCiz,150)});
document.addEventListener('visibilitychange',function(){if(document.hidden)akisKapat();else if(D.sekme==='canli')akislariBaslat()});
document.addEventListener('keydown',function(e){if(e.key==='Escape'){menuKapat();if(DK.odak!==null&&$('#oynatici').hidden)odakDegistir(null)}});
var yBoy=null,yMob=telefon();window.addEventListener('resize',function(){clearTimeout(yBoy);yBoy=setTimeout(function(){
  if(D.sekme!=='canli')return;if(telefon()!==yMob){yMob=telefon();izgaraCiz();return}
  var g=$('#izgara'),n=gorunenAdet();if(duzenTanimi(n,g.clientWidth/Math.max(1,g.clientHeight))!==g._tanim){izgaraCiz();g._tanim=duzenTanimi(n,g.clientWidth/Math.max(1,g.clientHeight));return}
  Array.prototype.forEach.call(document.querySelectorAll('#izgara .karo'),function(el){if(el._id&&el._w!==kovaGenislik(el))akisBaslat(el)})},250)});
$('#b-kayit').onclick=function(){var c=mevcut();if(!c)return;
  api('/api/kayit/'+encodeURIComponent(c.id),{eylem:c.manuel?'durdur':'basla'}).then(yokla).catch(function(e){bildir(e.message,true)})};
padKur();oynatKur();
api('/api/ayar').then(function(a){D.ayar=a;
  Array.prototype.forEach.call(document.querySelectorAll('.kontrol'),function(e){e.hidden=!a.kontrol});
  $('#n-kayit').hidden=!a.kayit_izle;
  return yokla()}).then(function(){if(D.aktif)sec(D.aktif)});
setInterval(yokla,3000);
</script></body></html>"""
SAYFA_BAYT = SAYFA.encode("utf-8")


class _Hata(Exception):
    def __init__(self, kod, mesaj):
        super().__init__(mesaj)
        self.kod = kod
        self.mesaj = mesaj


def _sinirla(deger, alt, ust):
    try:
        v = float(deger)
    except (TypeError, ValueError):
        raise _Hata(400, "Geçersiz sayı")
    if not math.isfinite(v):
        raise _Hata(400, "Geçersiz sayı")
    return max(alt, min(ust, v))


def _jpeg(kare, genislik, kalite):
    h, w = kare.shape[:2]
    if w > genislik:
        kare = cv2.resize(kare, (genislik, max(1, int(genislik * h / w))), interpolation=cv2.INTER_AREA)
    ok, tampon = cv2.imencode(".jpg", kare, [cv2.IMWRITE_JPEG_QUALITY, kalite])
    return tampon.tobytes() if ok else None


class WebSunucu:
    def __init__(self, kameralar_fn, kullanici, sifre, port=8787, gunluk=None,
                 kayit_klasorleri_fn=None, kontrol=True, kayit_izle=True):
        """kameralar_fn() -> {id: KameraIsci}; kayit_klasorleri_fn() -> [klasör yolları]"""
        if not kullanici or len(sifre or "") < 8:
            raise ValueError("Web görüntüleyici için kullanıcı adı ve en az 8 karakterlik şifre gerekli.")
        self._kameralar = kameralar_fn
        self._klasorler = kayit_klasorleri_fn or (lambda: [])
        self.kontrol = bool(kontrol)
        self.kayit_izle = bool(kayit_izle)
        self._kul = kullanici.encode("utf-8")
        self._sif = sifre.encode("utf-8")
        self.port = int(port)
        self._gunluk = gunluk or (lambda seviye, mesaj: None)
        self._httpd = None
        self._thr = None
        self._dur = threading.Event()
        self._akis_siniri = threading.BoundedSemaphore(14)
        self._kucuk_siniri = threading.BoundedSemaphore(2)
        self._basarisiz = {}      # ip -> (sayac, kilit_bitisi)
        self._kilit = threading.Lock()
        self._ptz_zamanlayici = {}      # id(isci) -> (Timer, ptz istemcisi)
        self.ptz_otomatik_durdur_sn = 1.5
        self._bilgi_onbellek = {}
        self._kucuk_onbellek = {}

    # ------------------------------------------------------------- kimlik
    def _kontrol(self, baslik, ip):
        """True: kimlik doğru. Çok sayıda yanlış denemede IP geçici kilitlenir."""
        simdi = time.time()
        with self._kilit:
            sayac, bitis = self._basarisiz.get(ip, (0, 0))
            if bitis > simdi:
                return False
        ok = False
        if baslik and baslik.lower().startswith("basic "):
            try:
                kul, _, sif = base64.b64decode(baslik[6:].strip()).partition(b":")
                ok = hmac.compare_digest(kul, self._kul) & hmac.compare_digest(sif, self._sif)
            except Exception:
                ok = False
        with self._kilit:
            if ok:
                self._basarisiz.pop(ip, None)
            elif baslik:  # kimlik sunuldu ama yanlış
                sayac, _ = self._basarisiz.get(ip, (0, 0))
                sayac += 1
                self._basarisiz[ip] = (sayac, simdi + 300 if sayac >= 10 else 0)
                if len(self._basarisiz) > 2000:
                    self._basarisiz = {k: v for k, v in self._basarisiz.items() if v[1] > simdi}
                if sayac == 10:
                    self._gunluk("HATA", "Web görüntüleyici: %s adresi çok fazla yanlış denedi, 5 dk engellendi" % ip)
        return ok

    # ------------------------------------------------------------- kayıt dosyaları
    def _kayit_dosyalari(self):
        """[(Path, stat)] — en yeni önce."""
        bulunan = {}
        for k in self._klasorler():
            try:
                for p in Path(k).glob("*.mp4"):
                    if DOSYA_RE.match(p.name) and p.is_file():
                        bulunan.setdefault(p.name, p)
            except OSError:
                continue
        liste = []
        for p in bulunan.values():
            try:
                liste.append((p, p.stat()))
            except OSError:
                continue
        liste.sort(key=lambda x: x[1].st_mtime, reverse=True)
        return liste[:KAYIT_SAYISI_SINIRI]

    def _dosya_bul(self, ad):
        if not DOSYA_RE.match(ad or ""):
            return None
        for k in self._klasorler():
            try:
                kok = Path(k).resolve()
                p = (Path(k) / ad)
                if p.is_file() and p.resolve().parent == kok:
                    return p
            except OSError:
                continue
        return None

    def _aktif_kayitlar(self):
        return {getattr(i, "kayit_dosyasi", None) for i in self._kameralar().values()} - {None}

    def _kamera_adi(self, dosya):
        en_iyi = None
        for i in self._kameralar().values():
            on = guvenli_ad(i.ad) + "_"
            if dosya.startswith(on) and (en_iyi is None or len(on) > len(en_iyi[0])):
                en_iyi = (on, i.ad)
        if en_iyi:
            return en_iyi[1]
        m = re.match(r"^(.*?)_\d{8}_\d{6}", dosya)
        return (m.group(1) if m else dosya[:-4]).replace("_", " ")

    def _bilgi(self, p, st):
        anahtar = (p.name, st.st_size, int(st.st_mtime))
        with self._kilit:
            b = self._bilgi_onbellek.get(anahtar)
        if b is not None:
            return b
        b = {"sure": 0, "fps": 0, "genislik": 0, "yukseklik": 0}
        cap = cv2.VideoCapture(str(p))
        try:
            if cap.isOpened():
                fps = cap.get(cv2.CAP_PROP_FPS) or 0
                n = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
                b = {"sure": round(n / fps, 1) if fps > 0 and n > 0 else 0, "fps": round(fps, 1),
                     "genislik": int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0),
                     "yukseklik": int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)}
        finally:
            cap.release()
        with self._kilit:
            if len(self._bilgi_onbellek) > 600:
                self._bilgi_onbellek.clear()
            self._bilgi_onbellek[anahtar] = b
        return b

    def _kucuk(self, p, st):
        anahtar = (p.name, st.st_size, int(st.st_mtime))
        with self._kilit:
            v = self._kucuk_onbellek.get(anahtar)
        if v is not None:
            return v or None
        veri = b""
        with self._kucuk_siniri:
            cap = cv2.VideoCapture(str(p))
            try:
                if cap.isOpened():
                    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
                    fps = cap.get(cv2.CAP_PROP_FPS) or 15
                    if n > 1:
                        cap.set(cv2.CAP_PROP_POS_FRAMES, min(n - 1, int(fps)))
                    ok, kare = cap.read()
                    if not ok:
                        cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                        ok, kare = cap.read()
                    if ok and kare is not None:
                        veri = _jpeg(kare, 320, 70) or b""
            finally:
                cap.release()
        with self._kilit:
            if len(self._kucuk_onbellek) > 200:
                self._kucuk_onbellek.clear()
            self._kucuk_onbellek[anahtar] = veri
        return veri or None

    # ------------------------------------------------------------- kontrol
    def _ptz_zamanla(self, isci, ist):
        """Bırakma/ağ kopması durumunda kamera dönmeye devam etmesin diye otomatik durdurma."""
        kid = id(isci)
        t = threading.Timer(self.ptz_otomatik_durdur_sn, self._ptz_otomatik_dur, (kid,))
        t.daemon = True
        with self._kilit:
            eski = self._ptz_zamanlayici.pop(kid, None)
            if eski:
                eski[0].cancel()
            self._ptz_zamanlayici[kid] = (t, ist)
        t.start()

    def _ptz_otomatik_dur(self, kid):
        with self._kilit:
            kayit = self._ptz_zamanlayici.pop(kid, None)
        if kayit:
            try:
                kayit[1].dur()
            except Exception:
                pass

    def _ptz_zamanlayici_iptal(self, isci):
        with self._kilit:
            kayit = self._ptz_zamanlayici.pop(id(isci), None)
        if kayit:
            kayit[0].cancel()

    def ptz_komutu(self, isci, veri):
        eylem = veri.get("eylem")
        try:
            if eylem == "hareket":
                x = _sinirla(veri.get("x", 0), -1, 1)
                y = _sinirla(veri.get("y", 0), -1, 1)
                hiz = _sinirla(veri.get("hiz", 0.5), 0.1, 1.0)
                ist = isci.ptz_istemci()
                isci.ptz_hareketi_bildir()
                ist.hareket(round(x * hiz, 3), round(y * hiz, 3))
                self._ptz_zamanla(isci, ist)
            elif eylem == "dur":
                self._ptz_zamanlayici_iptal(isci)
                isci.ptz_istemci().dur()
            elif eylem == "ana":
                isci.ptz_hareketi_bildir()
                isci.ptz_istemci().ana_konuma_git()
            elif eylem == "preset":
                token = str(veri.get("token", ""))[:64]
                if not token:
                    raise _Hata(400, "Konum seçilmedi")
                isci.ptz_hareketi_bildir()
                isci.ptz_istemci().presete_git(token)
            else:
                raise _Hata(400, "Bilinmeyen PTZ eylemi")
        except _Hata:
            raise
        except Exception as e:
            raise _Hata(502, "PTZ: %s" % str(e)[:120])

    # --------------------------------------------------------------- sunucu
    def baslat(self):
        sunucu = self

        class Isleyici(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"
            server_version = "KameraMerkezi"
            sys_version = ""
            timeout = 60

            def log_message(self, *a):
                pass

            def _ip(self):
                return self.headers.get("CF-Connecting-IP") or self.client_address[0]

            # ---- yanıt yardımcıları
            def _baslik_yaz(self, kod, tur, uzunluk=None, ek=()):
                self.send_response(kod)
                self.send_header("Content-Type", tur)
                if uzunluk is not None:
                    self.send_header("Content-Length", str(uzunluk))
                else:
                    self.close_connection = True
                if self.close_connection:
                    self.send_header("Connection", "close")
                self.send_header("Cache-Control", "no-store")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("Content-Security-Policy",
                                 "default-src 'none'; img-src 'self'; media-src 'self'; style-src 'unsafe-inline'; "
                                 "script-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; "
                                 "form-action 'none'; frame-ancestors 'none'")
                for k, v in ek:
                    self.send_header(k, v)
                self.end_headers()

            def _yanit(self, kod, tur, veri, ek=()):
                self._baslik_yaz(kod, tur, len(veri), ek)
                if self.command != "HEAD":
                    self.wfile.write(veri)

            def _json(self, kod, nesne):
                self._yanit(kod, "application/json; charset=utf-8",
                            json.dumps(nesne, ensure_ascii=False).encode("utf-8"))

            # ---- yetki ve yönlendirme
            def _yetkili(self):
                if sunucu._kontrol(self.headers.get("Authorization"), self._ip()):
                    return True
                self.close_connection = True
                self._yanit(401, "text/plain; charset=utf-8", "Kimlik doğrulama gerekli".encode("utf-8"),
                            [("WWW-Authenticate", 'Basic realm="Kamera Merkezi", charset="UTF-8"')])
                return False

            def _calistir(self, fn):
                try:
                    if not self._yetkili():
                        return
                    fn()
                except _Hata as e:
                    if self.command == "POST":
                        self.close_connection = True
                    self._json(e.kod, {"hata": e.mesaj})
                except (BrokenPipeError, ConnectionError, OSError):
                    self.close_connection = True
                except Exception as e:
                    sunucu._gunluk("HATA", "Web isteği başarısız: %s" % e)
                    self.close_connection = True
                    try:
                        self._json(500, {"hata": "Sunucu hatası"})
                    except Exception:
                        pass

            def do_GET(self):
                self._calistir(self._get)

            def do_HEAD(self):
                self._calistir(self._get)

            def do_POST(self):
                self._calistir(self._post)

            # ---- izinler / arama
            def _isci(self, kid):
                isci = sunucu._kameralar().get(unquote(kid))
                if isci is None:
                    raise _Hata(404, "Kamera bulunamadı")
                return isci

            def _kontrol_izni(self):
                if not sunucu.kontrol:
                    raise _Hata(403, "Uzaktan kontrol kapalı")

            def _kayit_izni(self):
                if not sunucu.kayit_izle:
                    raise _Hata(403, "Kayıt izleme kapalı")

            def _kayit_dosyasi(self, ad, aktif_olamaz=True):
                p = sunucu._dosya_bul(unquote(ad))
                if p is None:
                    raise _Hata(404, "Kayıt bulunamadı")
                if aktif_olamaz and p.name in sunucu._aktif_kayitlar():
                    raise _Hata(409, "Bu kayıt hâlâ sürüyor; bitince izleyebilirsiniz")
                return p

            # ---- GET
            def _get(self):
                yol = urlsplit(self.path)
                p = yol.path
                q = parse_qs(yol.query)
                kameralar = sunucu._kameralar()
                if p in ("/", "/index.html"):
                    self._yanit(200, "text/html; charset=utf-8", SAYFA_BAYT)
                elif p == "/durum":
                    self._json(200, {kid: {"ad": i.ad, "durum": i.durum, "kayit": i.kayit_var}
                                     for kid, i in kameralar.items()})
                elif p == "/api/ayar":
                    self._json(200, {"kontrol": sunucu.kontrol, "kayit_izle": sunucu.kayit_izle})
                elif p == "/api/kameralar":
                    self._json(200, [{"id": kid, "ad": i.ad, "durum": i.durum, "kayit": bool(i.kayit_var),
                                      "manuel": bool(getattr(i, "manuel_kayit", False))}
                                     for kid, i in kameralar.items()])
                elif p.startswith("/foto/"):
                    kare = self._isci(p[6:]).son_kare
                    jpg = _jpeg(kare, 1920, 88) if kare is not None else None
                    if jpg is None:
                        raise _Hata(503, "Görüntü yok")
                    self._yanit(200, "image/jpeg", jpg, [("Content-Disposition", 'inline; filename="foto.jpg"')])
                elif p.startswith("/akis/"):
                    self._canli_akis(self._isci(p[6:]), q)
                elif p.startswith("/api/preset/"):
                    self._kontrol_izni()
                    isci = self._isci(p[12:])
                    try:
                        liste = isci.ptz_istemci().presetleri_al()
                    except Exception as e:
                        raise _Hata(502, "PTZ: %s" % str(e)[:120])
                    self._json(200, [{"ad": ad, "token": token} for ad, token in liste])
                elif p == "/api/kayitlar":
                    self._kayit_izni()
                    self._kayit_listesi()
                elif p.startswith("/api/kayit-bilgi/"):
                    self._kayit_izni()
                    dosya = self._kayit_dosyasi(p[17:])
                    b = dict(sunucu._bilgi(dosya, dosya.stat()))
                    b["boyut"] = dosya.stat().st_size
                    self._json(200, b)
                elif p.startswith("/kayit-kucuk/"):
                    self._kayit_izni()
                    dosya = self._kayit_dosyasi(p[13:])
                    jpg = sunucu._kucuk(dosya, dosya.stat())
                    if not jpg:
                        raise _Hata(404, "Küçük resim yok")
                    self._yanit(200, "image/jpeg", jpg, [("Cache-Control", "private, max-age=3600")])
                elif p.startswith("/kayit-akis/"):
                    self._kayit_izni()
                    dosya = self._kayit_dosyasi(p[12:])
                    try:
                        basla = max(0.0, float(q.get("basla", ["0"])[0]))
                        hiz = float(q.get("hiz", ["1"])[0])
                    except ValueError:
                        raise _Hata(400, "Geçersiz parametre")
                    if hiz not in (1.0, 2.0, 4.0, 8.0):
                        hiz = 1.0
                    self._kayit_akis(dosya, basla, hiz)
                elif p.startswith("/kayit-indir/"):
                    self._kayit_izni()
                    self._indir(self._kayit_dosyasi(p[13:]))
                else:
                    raise _Hata(404, "Bulunamadı")

            def _kayit_listesi(self):
                aktif = sunucu._aktif_kayitlar()
                dosyalar = sunucu._kayit_dosyalari()
                sonuc = []
                for sira, (p, st) in enumerate(dosyalar):
                    sure = 0
                    if sira < 60 and p.name not in aktif:
                        sure = sunucu._bilgi(p, st)["sure"]
                    sonuc.append({"ad": p.name, "kamera": sunucu._kamera_adi(p.name),
                                  "tarih": dt.datetime.fromtimestamp(st.st_mtime).strftime("%d.%m.%Y %H:%M"),
                                  "boyut": st.st_size, "sure": sure, "aktif": p.name in aktif})
                self._json(200, {"kayitlar": sonuc, "toplam": len(sonuc)})

            def _canli_akis(self, isci, q):
                genislik = 960
                try:
                    w = int(q.get("w", ["960"])[0])
                    if w in (320, 480, 640, 960, 1280):
                        genislik = w
                except ValueError:
                    pass
                if not sunucu._akis_siniri.acquire(blocking=False):
                    raise _Hata(503, "Çok fazla eşzamanlı yayın")
                try:
                    self._baslik_yaz(200, "multipart/x-mixed-replace; boundary=kare")
                    if self.command == "HEAD":
                        return
                    son_no, son_zaman = -1, 0.0
                    while not sunucu._dur.is_set():
                        kare = isci.son_kare
                        no = isci.kare_no
                        simdi = time.time()
                        # Cloudflare uzun süre veri gelmeyen bağlantıyı kapatabilir: 8 sn'de bir son kareyi yinele
                        if kare is not None and (no != son_no or simdi - son_zaman > 8):
                            veri = _jpeg(kare, genislik, 68)
                            if veri:
                                self.wfile.write(b"--kare\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n"
                                                 % len(veri))
                                self.wfile.write(veri)
                                self.wfile.write(b"\r\n")
                                self.wfile.flush()
                            son_no, son_zaman = no, simdi
                        time.sleep(0.1)
                except (BrokenPipeError, ConnectionError, OSError):
                    pass
                finally:
                    sunucu._akis_siniri.release()
                    self.close_connection = True

            def _kayit_akis(self, dosya, basla, hiz):
                """Kaydı sunucuda çözüp MJPEG olarak akıtır (mp4v kodeği tarayıcılarda doğrudan oynamaz)."""
                if not sunucu._akis_siniri.acquire(blocking=False):
                    raise _Hata(503, "Çok fazla eşzamanlı yayın")
                cap = cv2.VideoCapture(str(dosya))
                try:
                    if not cap.isOpened():
                        raise _Hata(500, "Kayıt dosyası açılamadı")
                    fps = cap.get(cv2.CAP_PROP_FPS)
                    if not (1 <= fps <= 120):
                        fps = 15.0
                    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
                    if basla > 0:
                        hedef = int(basla * fps)
                        if n:
                            hedef = min(hedef, max(0, n - 1))
                        cap.set(cv2.CAP_PROP_POS_FRAMES, hedef)
                    adim = max(1, int(round(fps * hiz / 15.0)))       # en çok ~15 kare/sn gönder
                    aralik = adim / (fps * hiz)
                    self._baslik_yaz(200, "multipart/x-mixed-replace; boundary=kare")
                    if self.command == "HEAD":
                        return
                    sonraki = time.time()
                    while not sunucu._dur.is_set():
                        bitti = False
                        for _ in range(adim - 1):
                            if not cap.grab():
                                bitti = True
                                break
                        if bitti:
                            break
                        ok, kare = cap.read()
                        if not ok or kare is None:
                            break
                        veri = _jpeg(kare, 960, 70)
                        if veri:
                            self.wfile.write(b"--kare\r\nContent-Type: image/jpeg\r\nContent-Length: %d\r\n\r\n"
                                             % len(veri))
                            self.wfile.write(veri)
                            self.wfile.write(b"\r\n")
                            self.wfile.flush()
                        sonraki += aralik
                        bekle = sonraki - time.time()
                        if bekle > 0:
                            time.sleep(min(bekle, 1.0))
                        elif bekle < -1.0:
                            sonraki = time.time()
                except (BrokenPipeError, ConnectionError, OSError):
                    pass
                finally:
                    cap.release()
                    sunucu._akis_siniri.release()
                    self.close_connection = True

            def _indir(self, dosya):
                try:
                    boyut = dosya.stat().st_size
                    f = open(str(dosya), "rb")
                except OSError:
                    raise _Hata(404, "Kayıt açılamadı")
                with f:
                    self._baslik_yaz(200, "video/mp4", boyut,
                                     [("Content-Disposition", 'attachment; filename="%s"' % dosya.name)])
                    if self.command == "HEAD":
                        return
                    while not sunucu._dur.is_set():
                        parca = f.read(256 * 1024)
                        if not parca:
                            break
                        self.wfile.write(parca)

            # ---- POST
            def _csrf_ve_govde(self):
                if self.headers.get("X-Kamera") != "1":
                    raise _Hata(403, "Geçersiz istek")
                tur = (self.headers.get("Content-Type") or "").split(";")[0].strip().lower()
                if tur != "application/json":
                    raise _Hata(415, "JSON bekleniyor")
                try:
                    n = int(self.headers.get("Content-Length") or 0)
                except ValueError:
                    raise _Hata(400, "Geçersiz istek")
                if n < 0 or n > 2048:
                    raise _Hata(413, "İstek çok büyük")
                ham = self.rfile.read(n) if n else b"{}"
                try:
                    veri = json.loads(ham.decode("utf-8"))
                except ValueError:
                    raise _Hata(400, "Geçersiz JSON")
                if not isinstance(veri, dict):
                    raise _Hata(400, "Geçersiz JSON")
                return veri

            def _post(self):
                p = urlsplit(self.path).path
                veri = self._csrf_ve_govde()
                if p.startswith("/api/ptz/"):
                    self._kontrol_izni()
                    sunucu.ptz_komutu(self._isci(p[9:]), veri)
                    self._json(200, {"tamam": True})
                elif p.startswith("/api/kayit/"):
                    self._kontrol_izni()
                    isci = self._isci(p[11:])
                    eylem = veri.get("eylem")
                    if eylem == "basla":
                        isci.manuel_kayit = True
                    elif eylem == "durdur":
                        isci.manuel_kayit = False
                    else:
                        raise _Hata(400, "Bilinmeyen kayıt eylemi")
                    sunucu._gunluk("BİLGİ", "Web: elle kayıt %s (%s) · %s" % (
                        "başlatıldı" if eylem == "basla" else "durduruldu", isci.ad, self._ip()))
                    self._json(200, {"manuel": bool(isci.manuel_kayit), "kayit": bool(isci.kayit_var)})
                else:
                    raise _Hata(404, "Bulunamadı")

        self._dur.clear()
        ThreadingHTTPServer.daemon_threads = True
        self._httpd = ThreadingHTTPServer(("127.0.0.1", self.port), Isleyici)
        if self.port == 0:
            self.port = self._httpd.server_address[1]
        self._thr = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thr.start()
        self._gunluk("BİLGİ", "Web görüntüleyici açıldı: http://127.0.0.1:%d (yalnızca bu bilgisayardan erişilir)"
                     % self.port)

    def calisiyor(self):
        return self._httpd is not None

    def durdur(self):
        self._dur.set()
        with self._kilit:
            bekleyenler = list(self._ptz_zamanlayici.values())
            self._ptz_zamanlayici.clear()
        for zamanlayici, ist in bekleyenler:      # hareket halindeki kamerayı durdur
            zamanlayici.cancel()
            try:
                ist.dur()
            except Exception:
                pass
        if self._httpd is not None:
            try:
                self._httpd.shutdown()
                self._httpd.server_close()
            except Exception:
                pass
            self._httpd = None
            self._gunluk("BİLGİ", "Web görüntüleyici kapatıldı")
