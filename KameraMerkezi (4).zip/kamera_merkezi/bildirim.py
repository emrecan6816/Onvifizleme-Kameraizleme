# -*- coding: utf-8 -*-
"""
Hareket / kişi algılandığında bildirim: masaüstü bildirimi (Windows toast), ses ve WhatsApp (CallMeBot).
Arayüzden bağımsızdır; kamera iş parçacıklarından çağrılır, ağ işleri arka planda yapılır.
"""
import base64
import datetime as dt
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

_WIN = sys.platform.startswith("win")
_CREATE_NO_WINDOW = 0x08000000

VARSAYILAN = {"masaustu": True, "ses": True, "whatsapp": False, "telefon": "", "anahtar": "", "bekleme_sn": 60}
MIN_WHATSAPP_ARALIK = 30          # WhatsApp için en sık bu kadar saniyede bir (kamera başına)
CALLMEBOT = "https://api.callmebot.com/whatsapp.php"
KURULUM_ADRESI = "https://www.callmebot.com/blog/free-api-whatsapp-messages/"
_TEL_RE = re.compile(r"^\+\d{8,15}$")


def telefon_duzelt(metin):
    """'+90 532 123 45 67' / '0090 532…' / '90532…' -> '+905321234567'. Geçersizse ''."""
    t = re.sub(r"[\s\-().]", "", metin or "")
    if t.startswith("00"):
        t = "+" + t[2:]
    elif t and not t.startswith("+"):
        t = "+" + t
    return t if _TEL_RE.match(t) else ""


def mesaj_metni(kamera, tur, zaman=None, adres=None):
    zaman = zaman or dt.datetime.now()
    baslik = "Kişi algılandı" if tur == "kisi" else "Hareket algılandı"
    satirlar = ["🚨 *%s*" % baslik, "Kamera: %s" % kamera, "Zaman: %s" % zaman.strftime("%d.%m.%Y %H:%M:%S")]
    if adres:
        satirlar.append("Canlı izle: %s" % adres)
    return "\n".join(satirlar)


def whatsapp_adresi(telefon, anahtar, metin):
    return "%s?%s" % (CALLMEBOT, urllib.parse.urlencode(
        {"phone": telefon, "text": metin, "apikey": anahtar}, quote_via=urllib.parse.quote))


def whatsapp_gonder(telefon, anahtar, metin, zaman_asimi=20, acici=None):
    """(basarili, aciklama) döndürür. Hata ayrıntıları kullanıcıya gösterilebilecek kadar sadedir."""
    tel = telefon_duzelt(telefon)
    if not tel:
        return False, "Telefon numarası geçersiz (örn. +905321234567)."
    if not (anahtar or "").strip():
        return False, "API anahtarı boş."
    try:
        istek = urllib.request.Request(whatsapp_adresi(tel, anahtar.strip(), metin),
                                       headers={"User-Agent": "KameraMerkezi/1.0"})
        acici = acici or urllib.request.urlopen
        with acici(istek, timeout=zaman_asimi) as y:
            govde = y.read(4000).decode("utf-8", "replace")
            kod = getattr(y, "status", 200)
    except urllib.error.HTTPError as e:
        try:
            govde = e.read(4000).decode("utf-8", "replace")
        except Exception:
            govde = ""
        return False, "Sunucu hata verdi (%s). %s" % (e.code, _sade(govde))
    except (urllib.error.URLError, OSError) as e:
        return False, "Bağlanılamadı: %s" % getattr(e, "reason", e)
    kucuk = govde.lower()
    if kod == 200 and not any(k in kucuk for k in ("error", "invalid", "apikey is", "not authorized", "wrong")):
        return True, "Gönderildi."
    return False, _sade(govde) or "Gönderilemedi (kod %s)." % kod


def _sade(html):
    t = re.sub(r"<[^>]+>", " ", html or "")
    return re.sub(r"\s+", " ", t).strip()[:200]


def _xml_kacis(s):
    return (s or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def windows_bildirimi(baslik, mesaj, zaman_asimi=15):
    """Windows 10/11 yerel bildirimi (PowerShell, ek paket gerekmez). Başarılıysa True."""
    if not _WIN:
        return False
    ps = (
        "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] | Out-Null;"
        "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] | Out-Null;"
        "$x = New-Object Windows.Data.Xml.Dom.XmlDocument;"
        "$x.LoadXml('<toast><visual><binding template=\"ToastGeneric\"><text>%s</text><text>%s</text></binding></visual></toast>');"
        "$t = New-Object Windows.UI.Notifications.ToastNotification $x;"
        "[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier("
        "'{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\\WindowsPowerShell\\v1.0\\powershell.exe').Show($t)"
    ) % (_xml_kacis(baslik).replace("'", "''"), _xml_kacis(mesaj).replace("'", "''"))
    kod = base64.b64encode(ps.encode("utf-16-le")).decode("ascii")
    try:
        c = subprocess.run(["powershell", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
                            "-EncodedCommand", kod], capture_output=True, timeout=zaman_asimi,
                           creationflags=_CREATE_NO_WINDOW)
        return c.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def ses_cal():
    try:
        if _WIN:
            import winsound
            winsound.MessageBeep(winsound.MB_ICONEXCLAMATION)
    except Exception:
        pass


class Bildirimci:
    """olay(...) hızlı döner; bekleme süresi kamera başına uygulanır, gönderimler arka planda yapılır."""

    def __init__(self, ayar_fn, gunluk, acilir_fn=None, adres_fn=None):
        self._ayar = ayar_fn            # -> dict (VARSAYILAN anahtarları)
        self._gunluk = gunluk           # (kamera, seviye, mesaj)
        self._acilir = acilir_fn        # (baslik, mesaj, kamera_id) arayüzde uygulama içi bildirim
        self._adres = adres_fn or (lambda: None)
        self._son = {}                  # (kamera_id, kanal) -> zaman
        self._kilit = threading.Lock()
        self.gonderilen = 0             # test/ölçüm için

    def _log(self, kamera, seviye, mesaj):
        try:
            self._gunluk(kamera, seviye, mesaj)
        except Exception:
            pass

    def _sirasi_geldi(self, kimlik, kanal, aralik):
        simdi = time.monotonic()
        with self._kilit:
            son = self._son.get((kimlik, kanal))
            if son is not None and simdi - son < aralik:
                return False
            self._son[(kimlik, kanal)] = simdi
            return True

    def olay(self, isci, tur):
        """KameraIsci.olay_geri olarak kullanılır."""
        try:
            a = dict(VARSAYILAN, **(self._ayar() or {}))
        except Exception:
            return
        if not (a["masaustu"] or a["whatsapp"] or a["ses"]):
            return
        ad = isci.ad
        kimlik = isci.cfg.get("id", ad)
        aralik = max(0, int(a.get("bekleme_sn", 60)))
        zaman = dt.datetime.now()
        if (a["masaustu"] or a["ses"]) and self._sirasi_geldi(kimlik, "masaustu", aralik):
            threading.Thread(target=self._masaustu, args=(a, ad, kimlik, tur, zaman), daemon=True).start()
        if a["whatsapp"] and self._sirasi_geldi(kimlik, "whatsapp", max(aralik, MIN_WHATSAPP_ARALIK)):
            threading.Thread(target=self._whatsapp, args=(a, ad, tur, zaman), daemon=True).start()

    def _masaustu(self, a, ad, kimlik, tur, zaman):
        baslik = "Kişi algılandı" if tur == "kisi" else "Hareket algılandı"
        mesaj = "%s · %s" % (ad, zaman.strftime("%H:%M:%S"))
        if a["ses"]:
            ses_cal()
        if a["masaustu"]:
            if not windows_bildirimi(baslik, mesaj) and self._acilir:
                self._acilir(baslik, mesaj, kimlik)
            self.gonderilen += 1

    def _whatsapp(self, a, ad, tur, zaman):
        ok, acik = whatsapp_gonder(a["telefon"], a["anahtar"], mesaj_metni(ad, tur, zaman, self._adres()))
        self.gonderilen += 1
        self._log(ad, "BİLGİ" if ok else "HATA", "WhatsApp bildirimi: %s" % acik)

    # arayüzdeki "test" düğmeleri
    def test_masaustu(self, acilir=True):
        if windows_bildirimi("Kamera Merkezi", "Test bildirimi — masaüstü bildirimleri çalışıyor."):
            return True
        if acilir and self._acilir:
            self._acilir("Kamera Merkezi", "Test bildirimi — masaüstü bildirimleri çalışıyor.", None)
            return True
        return False

    def test_whatsapp(self, telefon, anahtar):
        return whatsapp_gonder(telefon, anahtar, "✅ Kamera Merkezi test mesajı: WhatsApp bildirimleri çalışıyor.")
