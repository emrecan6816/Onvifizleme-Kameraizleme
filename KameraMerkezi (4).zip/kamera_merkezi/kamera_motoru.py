# -*- coding: utf-8 -*-
"""
Kamera motoru: RTSP yayını okur, hareket/kişi algılar, olay kaydı yapar,
bağlantı koparsa kendiliğinden yeniden bağlanır. Arayüzden bağımsızdır.
"""
import os

# TCP üzerinden RTSP (Tapo için paket kaybını önler). cv2 içe aktarılmadan önce ayarlanmalı.
os.environ.setdefault("OPENCV_FFMPEG_CAPTURE_OPTIONS", "rtsp_transport;tcp")

import collections
import datetime as dt
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import cv2
import numpy as np

import ses as ses_modulu
from onvif_istemci import OnvifHata, OnvifIstemci

_MUX = ThreadPoolExecutor(max_workers=1)      # kayıtlara ses ekleme işleri (görüntü akışını bekletmez)

_TR = str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosuCGIOSU")


def guvenli_ad(ad):
    s = ad.translate(_TR)
    s = re.sub(r"[^A-Za-z0-9_-]+", "_", s).strip("_")
    return s or "Kamera"


def ascii_klasor(klasor):
    """OpenCV, Windows'ta ASCII olmayan yollara yazamayabilir; gerekirse güvenli klasöre geçer."""
    klasor = Path(klasor)
    try:
        str(klasor).encode("ascii")
        return klasor, False
    except UnicodeEncodeError:
        genel = Path(os.environ.get("PUBLIC", "C:/Users/Public"))
        return genel / "KameraKayitlari", True


def kare_boyutlandir(kare, cw, ch, zoom=1.0):
    """BGR kareyi (isteğe bağlı dijital zoom ile) cw x ch alanına sığdırır; RGB döndürür."""
    h, w = kare.shape[:2]
    if zoom > 1.0:
        zw, zh = max(1, int(w / zoom)), max(1, int(h / zoom))
        x0, y0 = (w - zw) // 2, (h - zh) // 2
        kare = kare[y0:y0 + zh, x0:x0 + zw]
        h, w = kare.shape[:2]
    oran = min(max(cw, 1) / w, max(ch, 1) / h)
    nw, nh = max(1, int(w * oran)), max(1, int(h * oran))
    kucuk = cv2.resize(kare, (nw, nh), interpolation=cv2.INTER_AREA if oran < 1 else cv2.INTER_LINEAR)
    return cv2.cvtColor(kucuk, cv2.COLOR_BGR2RGB)


class KayitAyarlari:
    """Tüm kameralar tarafından paylaşılır; değişiklikler anında geçerli olur."""

    def __init__(self, **kw):
        self.kayit_klasoru = str(Path.home() / "Videos" / "KameraKayitlari")
        self.mod = "hareket"        # kapali | surekli | hareket | kisi
        self.olay_sonrasi_sn = 10
        self.hassasiyet = 60        # 1-100
        self.onbellek_sn = 3
        self.parca_dk = 10
        self.ses_kaydi = True       # kamera mikrofonunu kayıtlara ekle (ffmpeg varsa)
        for k, v in kw.items():
            if hasattr(self, k):
                setattr(self, k, v)

    def sozluk(self):
        return {k: getattr(self, k) for k in
                ("kayit_klasoru", "mod", "olay_sonrasi_sn", "hassasiyet", "onbellek_sn", "parca_dk", "ses_kaydi")}


class KameraIsci(threading.Thread):
    def __init__(self, cfg, ayarlar, gunluk):
        """cfg: dict(id, ad, ip, port, kullanici, sifre, kalite, rtsp_url)
        gunluk(kamera_ad, seviye, mesaj)"""
        super().__init__(daemon=True)
        self.cfg = cfg
        self.ayarlar = ayarlar
        self._gunluk = gunluk
        self._dur = threading.Event()
        self._kilit = threading.Lock()
        # arayüzün okuduğu durum
        self.son_kare = None
        self.kare_no = 0
        self.durum = "baglaniyor"          # baglaniyor | cevrimici | cevrimdisi
        self.fps = 0.0
        self.cozunurluk = (0, 0)
        self.olay_zamani = 0.0
        self.manuel_kayit = False
        self._url = None                   # çözülmüş RTSP adresi (ses akışı için)
        self._ses = None                   # SesKaynagi (gerektiğinde oluşturulur)
        self._ses_kayit = None             # SesKaydedici (kayıt sürerken)
        self._kayit_yolu = None
        self._kayit_t0 = 0.0               # kayıt dosyasının ilk karesinin tahmini gerçek zamanı
        self.ses_ek_girdi = None           # yalnızca testler için (ffmpeg giriş seçenekleri)
        self.olay_geri = None              # (isci, 'hareket'|'kisi') — yeni bir olay başladığında çağrılır
        self.onvif = None
        # kayıt
        self.yazici = None
        self.kayit_dosyasi = None
        self._kayit_nedeni = None
        self._parca_basi = 0.0
        self._onbellek = collections.deque()
        self._son_olay = 0.0
        # algılama
        self._arka = None
        self._son_hareket = False
        self._son_kisi = 0.0
        self._analiz_duraklat = 0.0
        self._hog = None
        self._son_kare_zamani = 0.0
        self._son_olay_log = 0.0

    # ------------------------------------------------------------ yardımcılar
    @property
    def ad(self):
        return self.cfg.get("ad", "Kamera")

    @property
    def kayit_var(self):
        return self.yazici is not None

    def ses_kaynagi(self):
        """Kameranın ses akışı (ffmpeg yoksa None). Dinleme ve kayıt aynı akışı paylaşır."""
        ff = ses_modulu.ffmpeg_onbellekli()
        if not ff:
            return None
        with self._kilit:
            if self._ses is None:
                self._ses = ses_modulu.SesKaynagi(lambda: self._url, ff, self.log, ek_girdi=self.ses_ek_girdi,
                                                  bos_bekleme=5.0 if not self.ses_ek_girdi else 0.0)
            return self._ses

    def olay_var(self, sn=2.0):
        return (time.time() - self.olay_zamani) < sn

    def log(self, seviye, mesaj):
        try:
            self._gunluk(self.ad, seviye, mesaj)
        except Exception:
            pass

    def durdur(self):
        self._dur.set()

    def kapat(self, bekle=2.0):
        """Durdurur, iş parçacığını bekler; takılırsa açık kaydı yine de düzgün kapatır."""
        self._dur.set()
        if self.is_alive() and threading.current_thread() is not self:
            self.join(bekle)
        if self.yazici is not None:
            self._kaydi_bitir("uygulama kapandı")
        if self._ses is not None:
            self._ses.kapat()

    def ptz_hareketi_bildir(self):
        """Kamera döndüğünde tüm görüntü değişir; bir süre algılamayı beklet."""
        self._arka = None
        self._analiz_duraklat = time.time() + 3.0

    def ptz_istemci(self):
        """PTZ için hazır ONVIF istemcisi döndürür (gerekirse bağlanır)."""
        with self._kilit:
            if self.onvif is None:
                self.onvif = OnvifIstemci(self.cfg["ip"], self.cfg.get("port", 2020),
                                          self.cfg.get("kullanici", ""), self.cfg.get("sifre", ""))
            if not self.onvif.baglandi:
                self.onvif.baglan()
            return self.onvif

    def fotograf_cek(self, klasor):
        kare = self.son_kare
        if kare is None:
            return None
        klasor, _ = ascii_klasor(Path(klasor) / "Fotograflar")
        klasor.mkdir(parents=True, exist_ok=True)
        yol = klasor / ("%s_%s.jpg" % (guvenli_ad(self.ad), dt.datetime.now().strftime("%Y%m%d_%H%M%S")))
        ok, tampon = cv2.imencode(".jpg", kare, [cv2.IMWRITE_JPEG_QUALITY, 92])
        if not ok:
            return None
        tampon.tofile(str(yol))
        return yol

    # --------------------------------------------------------------- bağlantı
    def _adres_coz(self):
        ozel = (self.cfg.get("rtsp_url") or "").strip()
        if ozel:
            return ozel
        self.onvif = OnvifIstemci(self.cfg["ip"], self.cfg.get("port", 2020),
                                  self.cfg.get("kullanici", ""), self.cfg.get("sifre", ""))
        kalite = self.cfg.get("kalite", "yuksek")
        try:
            self.onvif.baglan()
            return self.onvif.rtsp_adresi(kalite)
        except OnvifHata as e:
            if "Kimlik" in str(e):
                raise
            self.log("AĞ", "ONVIF yanıt vermedi (%s); varsayılan RTSP adresi deneniyor" % e)
            return self.onvif.varsayilan_rtsp(kalite)

    @staticmethod
    def _yayin_ac(url):
        try:
            cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG,
                                   [cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, 8000,
                                    cv2.CAP_PROP_READ_TIMEOUT_MSEC, 8000])
        except Exception:
            cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
        if not cap.isOpened():
            cap.release()
            return None
        try:
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
        except Exception:
            pass
        return cap

    def run(self):
        ilk = True
        while not self._dur.is_set():
            self.durum = "baglaniyor"
            try:
                url = self._adres_coz()
            except OnvifHata as e:
                self.durum = "cevrimdisi"
                self.log("HATA", str(e))
                self._dur.wait(15)
                continue
            except Exception as e:  # beklenmeyen
                self.durum = "cevrimdisi"
                self.log("HATA", "Bağlantı hazırlanamadı: %s" % e)
                self._dur.wait(10)
                continue
            self._url = url
            cap = self._yayin_ac(url)
            if cap is None:
                self.durum = "cevrimdisi"
                self.log("AĞ", "Yayın açılamadı, 5 sn sonra yeniden denenecek")
                self._dur.wait(5)
                continue
            self.log("BİLGİ", "Bağlandı" if ilk else "Yeniden bağlandı")
            ilk = False
            try:
                self._dongu(cap)
            finally:
                cap.release()
            if self._dur.is_set():
                break
            self.durum = "cevrimdisi"
            self._kaydi_bitir("bağlantı koptu")
            self.log("AĞ", "Yeniden bağlanılıyor")
            self._dur.wait(3)
        self._kaydi_bitir("uygulama kapandı")
        self.durum = "cevrimdisi"

    def _dongu(self, cap):
        fps = cap.get(cv2.CAP_PROP_FPS)
        if not (1 <= fps <= 60):
            fps = 15.0
        hatali = 0
        while not self._dur.is_set():
            ok, kare = cap.read()
            if not ok or kare is None:
                hatali += 1
                if hatali >= 3:
                    return
                time.sleep(0.2)
                continue
            hatali = 0
            try:
                self._kare_isle(kare, fps)
            except Exception as e:
                self.log("HATA", "Kare işlenemedi: %s" % e)
                time.sleep(0.05)

    # ------------------------------------------------------------ kare işleme
    def _kare_isle(self, kare, fps):
        simdi = time.time()
        if self._son_kare_zamani:
            dt_ = simdi - self._son_kare_zamani
            if dt_ > 0:
                anlik = 1.0 / dt_
                self.fps = anlik if self.fps == 0 else self.fps * 0.9 + anlik * 0.1
        self._son_kare_zamani = simdi
        self.son_kare = kare
        self.kare_no += 1
        self.cozunurluk = (kare.shape[1], kare.shape[0])
        self.durum = "cevrimici"

        a = self.ayarlar
        mod = a.mod
        olay_modu = mod in ("hareket", "kisi")
        olay = False
        if olay_modu:
            olay = self._analiz(kare, mod, simdi)
        if olay:
            yeni_olay = (simdi - self.olay_zamani) > 3.0       # önceki algılamadan ≥3 sn sonra: yeni olay
            self.olay_zamani = simdi
            self._son_olay = simdi
            if yeni_olay and self.olay_geri is not None:
                try:
                    self.olay_geri(self, mod)
                except Exception:
                    pass
            if simdi - self._son_olay_log > 15:
                self._son_olay_log = simdi
                self.log("OLAY", "Kişi algılandı" if mod == "kisi" else "Hareket algılandı")

        if self.manuel_kayit or mod == "surekli":
            kayit_istegi = True
        elif olay_modu:
            kayit_istegi = (simdi - self._son_olay) < a.olay_sonrasi_sn
        else:
            kayit_istegi = False

        if kayit_istegi and self.yazici is None:
            self._kaydi_baslat(kare, fps, simdi, manuel=self.manuel_kayit)
        elif not kayit_istegi and self.yazici is not None:
            if self._kayit_nedeni == "manuel":
                self._kaydi_bitir("manuel durduruldu")
            elif olay_modu:
                self._kaydi_bitir("olay sona erdi")
            elif mod == "kapali":
                self._kaydi_bitir("kayıt kapatıldı")
            else:
                self._kaydi_bitir("durduruldu")
        elif self.yazici is not None:
            self.yazici.write(kare)
            if mod == "surekli" and (simdi - self._parca_basi) > a.parca_dk * 60:
                self._kaydi_bitir("parça tamamlandı")
                self._kaydi_baslat(kare, fps, simdi, manuel=False)

        # kayıt yokken ön bellek (olay öncesi görüntü)
        if self.yazici is None and olay_modu and a.onbellek_sn > 0:
            ok, tampon = cv2.imencode(".jpg", kare, [cv2.IMWRITE_JPEG_QUALITY, 75])
            if ok:
                self._onbellek.append(tampon)
            azami = max(1, int(fps * a.onbellek_sn))
            while len(self._onbellek) > azami:
                self._onbellek.popleft()
        elif not olay_modu:
            self._onbellek.clear()

    # ---------------------------------------------------------------- algılama
    def _hog_hazirla(self):
        if self._hog is None:
            hog = cv2.HOGDescriptor()
            hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
            self._hog = hog
        return self._hog

    def _analiz(self, kare, mod, simdi):
        if simdi < self._analiz_duraklat:
            return False
        if self.kare_no % 2:                      # her iki karede bir analiz
            return self._son_hareket or (mod == "kisi" and simdi - self._son_kisi < 3.0)
        h, w = kare.shape[:2]
        kucuk = cv2.resize(kare, (320, max(1, int(320 * h / w))), interpolation=cv2.INTER_AREA)
        gri = cv2.GaussianBlur(cv2.cvtColor(kucuk, cv2.COLOR_BGR2GRAY), (21, 21), 0)
        if self._arka is None or self._arka.shape != gri.shape:
            self._arka = gri.astype("float32")
            self._son_hareket = False
            return False
        fark = cv2.absdiff(gri, cv2.convertScaleAbs(self._arka))
        cv2.accumulateWeighted(gri, self._arka, 0.05)
        _, esik = cv2.threshold(fark, 25, 255, cv2.THRESH_BINARY)
        esik = cv2.dilate(esik, None, iterations=2)
        konturlar = cv2.findContours(esik, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
        min_alan = float(np.interp(self.ayarlar.hassasiyet, [1, 100], [2500, 120]))
        hareket = any(cv2.contourArea(c) >= min_alan for c in konturlar)
        self._son_hareket = hareket
        if mod == "hareket":
            return hareket
        # kişi modu: hareket varken ara ara HOG ile kişi ara
        if hareket and (self.kare_no % 6 == 0):
            try:
                orta = cv2.resize(kare, (480, max(1, int(480 * h / w))))
                kutular, agirliklar = self._hog_hazirla().detectMultiScale(
                    orta, winStride=(8, 8), padding=(8, 8), scale=1.07)
                if len(kutular) and float(np.max(agirliklar)) > 0.4:
                    self._son_kisi = simdi
            except Exception as e:
                self.log("HATA", "Kişi algılama kapatıldı, hareket moduna geçildi: %s" % e)
                self.ayarlar.mod = "hareket"
        return (simdi - self._son_kisi) < 3.0

    # ------------------------------------------------------------------- kayıt
    def _kaydi_baslat(self, kare, fps, simdi, manuel):
        klasor, degisti = ascii_klasor(self.ayarlar.kayit_klasoru)
        try:
            klasor.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            self.log("HATA", "Kayıt klasörü oluşturulamadı: %s" % e)
            self._son_olay = 0.0
            self.manuel_kayit = False
            self._dur.wait(2)
            return
        if degisti and not getattr(self, "_uyari_verildi", False):
            self._uyari_verildi = True
            self.log("BİLGİ", "Klasör yolu özel karakter içeriyor; kayıtlar %s klasörüne yazılacak" % klasor)
        dosya = "%s_%s.mp4" % (guvenli_ad(self.ad), dt.datetime.now().strftime("%Y%m%d_%H%M%S"))
        yol = klasor / dosya
        sayac = 2
        while yol.exists():
            dosya = "%s_%s_%d.mp4" % (guvenli_ad(self.ad), dt.datetime.now().strftime("%Y%m%d_%H%M%S"), sayac)
            yol = klasor / dosya
            sayac += 1
        h, w = kare.shape[:2]
        yazici = cv2.VideoWriter(str(yol), cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
        if not yazici.isOpened():
            self.log("HATA", "Kayıt dosyası açılamadı: %s" % dosya)
            self._son_olay = 0.0
            self.manuel_kayit = False
            return
        self.yazici = yazici
        self.kayit_dosyasi = dosya
        self._kayit_nedeni = "manuel" if manuel else "otomatik"
        self._parca_basi = simdi
        # ön bellekteki olay öncesi kareler
        onceki = 0
        for tampon in self._onbellek:
            eski = cv2.imdecode(tampon, cv2.IMREAD_COLOR)
            if eski is not None and eski.shape[:2] == (h, w):
                yazici.write(eski)
                onceki += 1
        self._onbellek.clear()
        yazici.write(kare)
        self.log("KAYIT", "Kayıt başladı: %s" % dosya)
        self._kayit_yolu = yol
        self._kayit_t0 = time.time() - onceki / float(fps or 15.0)
        self._ses_kaydi_baslat(yol)

    def _kaydi_bitir(self, neden):
        if self.yazici is None:
            return
        try:
            self.yazici.release()
        except Exception:
            pass
        dosya = self.kayit_dosyasi
        self.yazici = None
        self.kayit_dosyasi = None
        self._kayit_nedeni = None
        self.log("DURDU", "Kayıt bitti (%s): %s" % (neden, dosya))
        self._ses_kaydi_bitir()

    # ------------------------------------------------------------- kayda ses ekleme
    def _ses_kaydi_baslat(self, yol):
        self._ses_kayit = None
        if not getattr(self.ayarlar, "ses_kaydi", False):
            return
        kaynak = self.ses_kaynagi()
        if kaynak is None or kaynak.ses_yok:
            return
        try:
            self._ses_kayit = ses_modulu.SesKaydedici(kaynak, Path(yol).with_suffix(".wav"))
        except Exception as e:
            self.log("HATA", "Ses kaydı başlatılamadı: %s" % e)
            self._ses_kayit = None

    def _ses_kaydi_bitir(self):
        rec, self._ses_kayit = self._ses_kayit, None
        if rec is None:
            return
        video, t0, bitis = self._kayit_yolu, self._kayit_t0, time.time()
        rec.durdur()
        _MUX.submit(self._ses_ekle, video, rec, t0, bitis)

    def _ses_ekle(self, video, rec, t0, bitis):
        """Kayıt bitince WAV'ı videoya birleştirir (arka planda). Hata olursa görüntü dosyası olduğu gibi kalır."""
        wav = rec.yol
        try:
            if rec.sure() < 0.5 or rec.t_ilk is None or not Path(video).is_file():
                return
            kap = cv2.VideoCapture(str(video))
            try:
                fps = kap.get(cv2.CAP_PROP_FPS) or 0
                n = kap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
            finally:
                kap.release()
            ofset, tempo = max(0.0, rec.t_ilk - t0), 1.0
            gecen = bitis - t0
            if fps > 0 and n > 0 and gecen > 1.0:
                oran = (n / fps) / gecen          # video süresi / gerçek geçen süre: kare hızı beyan edilenden farklıysa
                if abs(oran - 1.0) > 0.01 and 0.5 <= oran <= 2.0:
                    ofset *= oran                 # sesi video zaman çizgisine uydur (ritim bozulmadan, ses perdesi korunur)
                    tempo = 1.0 / oran
            if ses_modulu.birlestir(ses_modulu.ffmpeg_onbellekli(), video, wav, ofset, tempo):
                self.log("BİLGİ", "Kayda ses eklendi: %s" % Path(video).name)
            else:
                self.log("HATA", "Ses eklenemedi; kayıt sessiz bırakıldı: %s" % Path(video).name)
        except Exception as e:
            self.log("HATA", "Ses eklenemedi: %s" % e)
        finally:
            try:
                Path(wav).unlink()
            except OSError:
                pass
