@echo off
chcp 65001 >nul
rem Kullanim:  derle.bat       -> kurulu varsayilan Python ile derler
rem            derle.bat 32    -> 32 bit (x86) Python ile derler (py -3-32)
rem            derle.bat 64    -> 64 bit Python ile derler (py -3-64)
set "PY=python"
if "%1"=="32" set "PY=py -3-32"
if "%1"=="64" set "PY=py -3-64"

%PY% -c "import struct,sys;print(struct.calcsize('P')*8)" > "%TEMP%\km_bit.txt" 2>nul
if errorlevel 1 goto pyyok
set /p BIT=<"%TEMP%\km_bit.txt"
del "%TEMP%\km_bit.txt" >nul 2>&1
echo Kullanilacak Python: %PY% (%BIT% bit)
set "REQ=requirements.txt"
if "%BIT%"=="32" set "REQ=requirements-32bit.txt"
set "AD=KameraMerkezi_%BIT%bit"

echo Gerekli paketler kuruluyor (%REQ%)...
%PY% -m pip install --prefer-binary -r %REQ% pyinstaller
if errorlevel 1 goto hata
echo.
echo EXE olusturuluyor (birkac dakika surebilir)...
%PY% -m PyInstaller --noconsole --onefile --name %AD% --collect-all customtkinter --collect-all sounddevice --collect-all _sounddevice_data --collect-all imageio_ffmpeg kamera_merkezi.py
if errorlevel 1 goto hata
echo.
echo Tamam! Program: dist\%AD%.exe
echo (%BIT% bit Python ile derlendigi icin exe %BIT% bit Windows icin uretildi; 64 bit exe 32 bit Windows'ta acilmaz.)
pause
exit /b 0

:pyyok
echo.
echo Istenen Python bulunamadi. 32 bit icin python.org'dan "Windows installer (32-bit)" kurun,
echo kurulumda "py launcher" secili olsun; sonra tekrar: derle.bat 32
pause
exit /b 1

:hata
echo.
echo Bir hata olustu. Yukaridaki mesaji kontrol edin.
echo 32 bit'te paket kurulamadiysa hangi paketin hata verdigini not edin.
pause
exit /b 1
