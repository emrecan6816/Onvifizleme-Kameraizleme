# -*- coding: utf-8 -*-
"""
Kamera Merkezi — Tapo / ONVIF kameralar için modern masaüstü uygulaması.
Canlı izleme, hareket/kişi algılama, olay kaydı, PTZ joystick, preset, günlük.
"""
import datetime as dt
import json
import math
import os
import queue
import shutil
import subprocess
import sys
import threading
import time
import traceback
import uuid
import webbrowser
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import customtkinter as ctk
from PIL import Image, ImageTk

from kamera_motoru import KameraIsci, KayitAyarlari, ascii_klasor, kare_boyutlandir
from onvif_istemci import OnvifHata, OnvifIstemci, kesfet
import cloudflare_tunel as cft
import ekran_duzeni as ed
import bildirim as bd
import ses as sesm
import kayit_listesi as kl
from web_goruntuleyici import WebSunucu

UYGULAMA_ADI = "Kamera Merkezi"

R = dict(
    bg="#0A0E16", yan="#0C111B", panel="#0E131D", kart="#121826", kenar="#1B2333",
    kenar2="#273049", vurgu="#5B7CFF", vurgu_h="#4A68E6", metin="#EEF2FA", metin2="#CBD3E3",
    soluk="#6F7B91", yesil="#34D399", kirmizi="#FF4D5E", sari="#F5B94A", mavi="#7FAAFF",
    hover="#18233A", video="#0B0F17",
)

MODLAR = [("Kapalı (kayıt yok)", "kapali"), ("Sürekli kayıt", "surekli"),
          ("Hareket algılanınca", "hareket"), ("Kişi algılanınca", "kisi")]
SEVIYE_RENK = {"KAYIT": R["yesil"], "DURDU": "#FF6B7A", "AĞ": R["sari"], "OLAY": R["mavi"],
               "BİLGİ": "#9DB4E0", "HATA": "#FF6B7A"}


# ---------------------------------------------------------------- yardımcılar
def ayar_klasoru():
    taban = os.environ.get("APPDATA") or str(Path.home())
    k = Path(taban) / "KameraMerkezi"
    k.mkdir(parents=True, exist_ok=True)
    return k


def ayarlari_yukle():
    try:
        with open(ayar_klasoru() / "ayarlar.json", "r", encoding="utf-8") as f:
            veri = json.load(f)
            if isinstance(veri, dict):
                return veri
    except Exception:
        pass
    return {}


def ayarlari_kaydet(veri):
    try:
        gecici = ayar_klasoru() / "ayarlar.json.tmp"
        with open(gecici, "w", encoding="utf-8") as f:
            json.dump(veri, f, ensure_ascii=False, indent=2)
        os.replace(gecici, ayar_klasoru() / "ayarlar.json")
    except Exception as e:
        print("Ayarlar kaydedilemedi:", e, file=sys.stderr)


def yolu_ac(yol):
    yol = str(yol)
    try:
        if sys.platform.startswith("win"):
            os.startfile(yol)  # noqa
        elif sys.platform == "darwin":
            subprocess.Popen(["open", yol])
        else:
            subprocess.Popen(["xdg-open", yol])
    except Exception as e:
        messagebox.showerror(UYGULAMA_ADI, "Açılamadı: %s" % e)


def disk_bilgi(yol):
    p = Path(yol)
    while not p.exists() and p.parent != p:
        p = p.parent
    u = shutil.disk_usage(str(p))
    return u.free, u.total


def boyut_metni(b):
    for birim in ("B", "KB", "MB", "GB", "TB"):
        if b < 1024 or birim == "TB":
            return ("%d %s" % (b, birim)) if birim == "B" else ("%.1f %s" % (b, birim))
        b /= 1024.0


def yuvarlak_dikdortgen(c, x1, y1, x2, y2, r=12, **kw):
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    n = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
         x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
    return c.create_polygon(n, smooth=True, **kw)


# ------------------------------------------------------------------- joystick
class Joystik(tk.Canvas):
    """8 yönlü dairesel PTZ kontrolü. Basılı tutunca hareket, bırakınca durur; ortadaki düğme ana konuma gider."""

    def __init__(self, master, boyut, hareket_cb, dur_cb, ana_cb):
        super().__init__(master, width=boyut, height=boyut, bg=R["panel"], highlightthickness=0)
        self.b = boyut
        self.hareket_cb, self.dur_cb, self.ana_cb = hareket_cb, dur_cb, ana_cb
        self.yon = None
        self._merkez = False
        self.bind("<ButtonPress-1>", self._bas)
        self.bind("<B1-Motion>", self._surukle)
        self.bind("<ButtonRelease-1>", self._birak)
        self._ciz()

    def _ciz(self):
        self.delete("all")
        b = self.b
        m = b / 2.0
        r = b * 0.46
        ic = b * 0.17
        self.create_oval(m - r, m - r, m + r, m + r, fill=R["kart"], outline="#2B3A5C", width=2)
        self.create_oval(m - ic, m - ic, m + ic, m + ic, fill=R["vurgu"], outline="")
        self.create_text(m, m, text="⌂", fill="white", font=("Segoe UI Symbol", max(10, int(b * 0.12))))
        for k in range(8):
            aci = math.radians(k * 45)
            ux, uy = math.cos(aci), -math.sin(aci)
            d = r * 0.74
            cx, cy = m + ux * d, m + uy * d
            boy = b * (0.055 if k % 2 == 0 else 0.036)
            px, py = -uy, ux
            nokta = [cx + ux * boy * 1.3, cy + uy * boy * 1.3,
                     cx - ux * boy * 0.7 + px * boy, cy - uy * boy * 0.7 + py * boy,
                     cx - ux * boy * 0.7 - px * boy, cy - uy * boy * 0.7 - py * boy]
            if k == self.yon:
                renk = R["vurgu"]
            else:
                renk = "#9DB4E0" if k % 2 == 0 else "#4B5A78"
            self.create_polygon(nokta, fill=renk, outline="")

    def _bolge(self, x, y):
        m = self.b / 2.0
        dx, dy = x - m, y - m
        if math.hypot(dx, dy) < self.b * 0.19:
            return "merkez"
        aci = math.degrees(math.atan2(-dy, dx))
        return int(round(aci / 45.0)) % 8

    def _vektor(self, k):
        a = math.radians(k * 45)
        vx, vy = round(math.cos(a), 3), round(math.sin(a), 3)
        return vx, vy

    def _ayarla(self, k):
        self.yon = k
        self._ciz()
        if k is None:
            self.dur_cb()
        else:
            vx, vy = self._vektor(k)
            self.hareket_cb(vx, vy)

    def _bas(self, e):
        k = self._bolge(e.x, e.y)
        if k == "merkez":
            self._merkez = True
            return
        self._merkez = False
        self._ayarla(k)

    def _surukle(self, e):
        if self._merkez:
            return
        k = self._bolge(e.x, e.y)
        if k == "merkez":
            k = None
        if k != self.yon:
            self._ayarla(k)

    def _birak(self, e):
        if self._merkez:
            self._merkez = False
            if self._bolge(e.x, e.y) == "merkez":
                self.ana_cb()
            return
        if self.yon is not None:
            self.yon = None
            self._ciz()
            self.dur_cb()


# ------------------------------------------------------------------ kamera kartı
class KameraKarti(ctk.CTkFrame):
    def __init__(self, master, app, cfg):
        super().__init__(master, fg_color=R["kart"], corner_radius=16, border_width=2,
                         border_color=R["kenar"])
        self.app = app
        self.cfg = cfg
        self.tw, self.th = app.sc(208), app.sc(84)
        self.canvas = tk.Canvas(self, width=self.tw, height=self.th, bg=R["panel"], highlightthickness=0)
        self.canvas.pack(padx=10, pady=(10, 6))
        self._foto = None
        self._img_id = None
        self._son_no = -1
        satir = ctk.CTkFrame(self, fg_color="transparent")
        satir.pack(fill="x", padx=12)
        self.ad_lbl = ctk.CTkLabel(satir, text=cfg["ad"], font=app.F(14, True),
                                   text_color=R["metin"], anchor="w")
        self.ad_lbl.pack(side="left")
        self.durum_lbl = ctk.CTkLabel(self, text="Bağlanıyor…", font=app.F(12),
                                      text_color=R["sari"], anchor="w")
        self.durum_lbl.pack(fill="x", padx=12, pady=(0, 10))
        for w in (self, self.canvas, satir, self.ad_lbl, self.durum_lbl):
            w.bind("<Button-1>", lambda e: self.app.sec(self.cfg["id"]))
        ctk.CTkButton(satir, text="✕", width=26, height=26, corner_radius=8, fg_color="transparent",
                      hover_color=R["hover"], text_color=R["soluk"], font=app.F(12),
                      command=lambda: self.app.kamera_sil(self.cfg["id"])).pack(side="right")
        ctk.CTkButton(satir, text="✎", width=26, height=26, corner_radius=8, fg_color="transparent",
                      hover_color=R["hover"], text_color=R["soluk"], font=app.F(13),
                      command=lambda: self.app.kamera_duzenle(self.cfg["id"])).pack(side="right")

    def secili_yap(self, evet):
        self.configure(border_color=R["vurgu"] if evet else R["kenar"])

    def ad_guncelle(self):
        self.ad_lbl.configure(text=self.cfg["ad"])

    def guncelle(self, isci):
        if isci.durum == "cevrimici":
            w, h = isci.cozunurluk
            self.durum_lbl.configure(text="● Çevrimiçi · %d×%d" % (w, h) if w else "● Çevrimiçi",
                                     text_color=R["yesil"])
        elif isci.durum == "baglaniyor":
            self.durum_lbl.configure(text="● Bağlanıyor…", text_color=R["sari"])
        else:
            self.durum_lbl.configure(text="● Çevrimdışı", text_color="#FF6B7A")
        kare = isci.son_kare
        if kare is not None and isci.durum == "cevrimici" and isci.kare_no != self._son_no:
            self._son_no = isci.kare_no
            rgb = kare_boyutlandir(kare, self.tw, self.th)
            self._foto = ImageTk.PhotoImage(Image.fromarray(rgb))
            if self._img_id is None:
                self._img_id = self.canvas.create_image(self.tw // 2, self.th // 2, image=self._foto)
            else:
                self.canvas.itemconfigure(self._img_id, image=self._foto)
            self.canvas.tag_lower(self._img_id)
        self.canvas.delete("chip")
        if isci.kayit_var:
            yuvarlak_dikdortgen(self.canvas, 8, 8, 78, 28, 10, fill="#2A0F16", outline="", tags="chip")
            self.canvas.create_oval(17, 14, 25, 22, fill=R["kirmizi"], outline="", tags="chip")
            self.canvas.create_text(31, 18, text="KAYIT", fill="#FF8591", anchor="w",
                                    font=("Segoe UI", 8, "bold"), tags="chip")


# --------------------------------------------------------------- düzen düğmesi
class DuzenDugmesi(tk.Canvas):
    """Araç çubuğundaki 1–6 kamera düzeni düğmesi: düzenin küçük çizimini ve sayıyı gösterir."""

    def __init__(self, master, app, n):
        self.w, self.h = app.sc(66), app.sc(38)
        super().__init__(master, width=self.w, height=self.h, bg=R["bg"], highlightthickness=0, cursor="hand2")
        self.app, self.n, self.aktif = app, n, False
        self.bind("<Button-1>", lambda e: self.app.duzen_sec(self.n))
        self.ciz()

    def aktif_yap(self, evet):
        if evet != self.aktif:
            self.aktif = evet
            self.ciz()

    def ciz(self):
        self.delete("all")
        a = self.aktif
        yuvarlak_dikdortgen(self, 1, 1, self.w - 1, self.h - 1, 11, fill=R["vurgu"] if a else R["kart"],
                            outline=R["vurgu"] if a else R["kenar"])
        iw, ih = int(self.w * 0.42), int(self.h * 0.48)
        ox, oy = int(self.w * 0.14), (self.h - ih) // 2
        for x0, y0, x1, y1 in ed.goreli_dikdortgenler(ed.DUZENLER[self.n]):
            self.create_rectangle(ox + x0 * iw + 1, oy + y0 * ih + 1, ox + x1 * iw - 1, oy + y1 * ih - 1,
                                  fill="white" if a else R["soluk"], outline="")
        self.create_text(int(self.w * 0.78), self.h // 2, text=str(self.n), fill="white" if a else R["metin2"],
                         font=("Segoe UI", 12, "bold"))


# --------------------------------------------------------------------- diyaloglar
class Diyalog(ctk.CTkToplevel):
    def __init__(self, app, baslik, genislik, yukseklik):
        super().__init__(app)
        self.app = app
        self.title(baslik)
        self.configure(fg_color=R["panel"])
        self.resizable(False, False)
        x = app.winfo_rootx() + max(0, (app.winfo_width() - genislik) // 2)
        y = app.winfo_rooty() + max(0, (app.winfo_height() - yukseklik) // 3)
        self.geometry("%dx%d+%d+%d" % (genislik, yukseklik, x, y))
        self.transient(app)
        self.after(200, self._modal)

    def _modal(self):
        try:
            self.grab_set()
            self.focus_force()
        except tk.TclError:
            pass

    def etiket(self, ust, metin):
        return ctk.CTkLabel(ust, text=metin, font=self.app.F(12, True), text_color=R["soluk"], anchor="w")

    def giris(self, ust, **kw):
        return ctk.CTkEntry(ust, height=36, corner_radius=10, fg_color=R["kart"],
                            border_color=R["kenar2"], text_color=R["metin"], font=self.app.F(13), **kw)

    def dugme(self, ust, metin, komut, vurgulu=False, genislik=120):
        if vurgulu:
            return ctk.CTkButton(ust, text=metin, command=komut, width=genislik, height=38, corner_radius=12,
                                 fg_color=R["vurgu"], hover_color=R["vurgu_h"], text_color="white",
                                 font=self.app.F(13, True))
        return ctk.CTkButton(ust, text=metin, command=komut, width=genislik, height=38, corner_radius=12,
                             fg_color=R["kart"], hover_color=R["hover"], border_width=1,
                             border_color=R["kenar2"], text_color=R["metin2"], font=self.app.F(13))


class KameraDialog(Diyalog):
    def __init__(self, app, cfg=None, hazir=None):
        baslik = "Kamera Ekle" if cfg is None else "Kamerayı Düzenle"
        super().__init__(app, baslik, 480, 700)
        self.cfg = cfg
        hazir = hazir or {}
        k = cfg or {}
        cerceve = ctk.CTkFrame(self, fg_color="transparent")
        cerceve.pack(fill="both", expand=True, padx=24, pady=20)
        ctk.CTkLabel(cerceve, text=baslik, font=app.F(20, True), text_color=R["metin"],
                     anchor="w").pack(fill="x", pady=(0, 12))

        def satir(etiket, deger="", gizli=False):
            self.etiket(cerceve, etiket).pack(fill="x", pady=(6, 1))
            e = self.giris(cerceve, show="•" if gizli else "")
            e.pack(fill="x")
            if deger != "":
                e.insert(0, str(deger))
            return e

        self.e_ad = satir("KAMERA ADI", k.get("ad", hazir.get("ad", "Tapo C200")))
        self.e_ip = satir("IP ADRESİ", k.get("ip", hazir.get("ip", "")))
        self.e_port = satir("ONVIF PORTU (Tapo için 2020)", k.get("port", hazir.get("port", 2020)))
        self.e_kul = satir("KULLANICI ADI (kamera hesabı)", k.get("kullanici", ""))
        self.e_sif = satir("ŞİFRE", k.get("sifre", ""), gizli=True)
        self.etiket(cerceve, "AKIŞ KALİTESİ").pack(fill="x", pady=(10, 2))
        self.kalite = ctk.CTkSegmentedButton(cerceve, values=["Yüksek (1080p)", "Düşük (akıcı)"],
                                             selected_color=R["vurgu"], selected_hover_color=R["vurgu_h"],
                                             unselected_color=R["kart"], font=app.F(13))
        self.kalite.pack(fill="x")
        self.kalite.set("Düşük (akıcı)" if k.get("kalite") == "dusuk" else "Yüksek (1080p)")
        self.e_rtsp = satir("ÖZEL RTSP ADRESİ (isteğe bağlı)", k.get("rtsp_url", ""))
        ctk.CTkLabel(cerceve, text="Kullanıcı adı ve şifre: Tapo uygulaması → Kamera Ayarları → Gelişmiş Ayarlar → "
                                   "Kamera Hesabı. Bilgiler yalnızca bu bilgisayarda saklanır.",
                     font=app.F(11), text_color=R["soluk"], wraplength=420, justify="left",
                     anchor="w").pack(fill="x", pady=(10, 0))
        self.sonuc = ctk.CTkLabel(cerceve, text="", font=app.F(12), text_color=R["soluk"],
                                  wraplength=420, justify="left", anchor="w")
        self.sonuc.pack(fill="x", pady=(8, 0))
        alt = ctk.CTkFrame(cerceve, fg_color="transparent")
        alt.pack(fill="x", side="bottom", pady=(14, 0))
        self.dugme(alt, "Bağlantıyı Test Et", self._test_et, genislik=150).pack(side="left")
        self.dugme(alt, "Kaydet", self._kaydet, vurgulu=True, genislik=100).pack(side="right")
        self.dugme(alt, "İptal", self.destroy, genislik=90).pack(side="right", padx=8)

    def _oku(self):
        ad = self.e_ad.get().strip()
        ip = self.e_ip.get().strip()
        if not ip:
            raise ValueError("IP adresini girin.")
        try:
            port = int(self.e_port.get().strip() or 2020)
        except ValueError:
            raise ValueError("Port bir sayı olmalı.")
        return {
            "id": (self.cfg or {}).get("id") or uuid.uuid4().hex[:8],
            "ad": ad or ip, "ip": ip, "port": port,
            "kullanici": self.e_kul.get().strip(), "sifre": self.e_sif.get(),
            "kalite": "dusuk" if self.kalite.get().startswith("Düşük") else "yuksek",
            "rtsp_url": self.e_rtsp.get().strip(),
        }

    def _sonuc(self, metin, iyi):
        if self.winfo_exists():
            self.sonuc.configure(text=metin, text_color=R["yesil"] if iyi else "#FF6B7A")

    def _test_et(self):
        try:
            c = self._oku()
        except ValueError as e:
            self._sonuc(str(e), False)
            return
        self._sonuc("Bağlanılıyor…", True)
        self.sonuc.configure(text_color=R["sari"])

        def is_():
            try:
                ist = OnvifIstemci(c["ip"], c["port"], c["kullanici"], c["sifre"])
                ptz_var = False
                onvif_notu = ""
                try:
                    profiller = ist.baglan()
                    ptz_var = any(p["ptz"] for p in profiller)
                    url = c["rtsp_url"] or ist.rtsp_adresi(c["kalite"])
                except OnvifHata as e:
                    if "Kimlik" in str(e) or c["rtsp_url"] == "" and "ulaşılamadı" in str(e):
                        raise
                    onvif_notu = " (ONVIF yanıt vermedi, PTZ çalışmayabilir)"
                    url = c["rtsp_url"] or ist.varsayilan_rtsp(c["kalite"])
                cap = KameraIsci._yayin_ac(url)
                if cap is None:
                    raise OnvifHata("ONVIF çalıştı ama video akışı açılamadı (RTSP). "
                                    "Kamera hesabı bilgilerini ve RTSP'nin açık olduğunu kontrol edin.")
                ok, kare = cap.read()
                cap.release()
                boyut = "%d×%d" % (kare.shape[1], kare.shape[0]) if ok else "görüntü alınamadı"
                mesaj = "✓ Bağlantı başarılı · %s · PTZ %s%s" % (boyut, "var" if ptz_var else "bilinmiyor", onvif_notu)
                self.app.ui(lambda: self._sonuc(mesaj, True))
            except Exception as e:
                hata = str(e)
                self.app.ui(lambda: self._sonuc("✗ " + hata, False))

        threading.Thread(target=is_, daemon=True).start()

    def _kaydet(self):
        try:
            c = self._oku()
        except ValueError as e:
            self._sonuc(str(e), False)
            return
        self.app.kamera_kaydet(c, yeni=self.cfg is None)
        self.destroy()


class TaraDialog(Diyalog):
    def __init__(self, app):
        super().__init__(app, "Kameraları Tara", 480, 460)
        cerceve = ctk.CTkFrame(self, fg_color="transparent")
        cerceve.pack(fill="both", expand=True, padx=24, pady=20)
        ctk.CTkLabel(cerceve, text="Ağdaki Kameralar", font=app.F(20, True), text_color=R["metin"],
                     anchor="w").pack(fill="x")
        self.durum = ctk.CTkLabel(cerceve, text="Aranıyor… (birkaç saniye sürer)", font=app.F(12),
                                  text_color=R["sari"], anchor="w")
        self.durum.pack(fill="x", pady=(2, 8))
        self.liste = ctk.CTkScrollableFrame(cerceve, fg_color=R["kart"], corner_radius=12)
        self.liste.pack(fill="both", expand=True)
        alt = ctk.CTkFrame(cerceve, fg_color="transparent")
        alt.pack(fill="x", pady=(12, 0))
        self.dugme(alt, "Elle Ekle", self._elle, genislik=110).pack(side="left")
        self.dugme(alt, "Tekrar Tara", self._tara, genislik=110).pack(side="left", padx=8)
        self.dugme(alt, "Kapat", self.destroy, genislik=90).pack(side="right")
        self._tara()

    def _elle(self):
        self.destroy()
        self.app.kamera_ekle_ac()

    def _tara(self):
        for w in self.liste.winfo_children():
            w.destroy()
        self.durum.configure(text="Aranıyor… (birkaç saniye sürer)", text_color=R["sari"])

        def is_():
            try:
                bulunan = kesfet(3.5)
            except Exception:
                bulunan = []
            self.app.ui(lambda: self._goster(bulunan))

        threading.Thread(target=is_, daemon=True).start()

    def _goster(self, bulunan):
        if not self.winfo_exists():
            return
        if not bulunan:
            self.durum.configure(text="Kamera bulunamadı. Aynı ağda olduğunuzdan emin olun veya elle ekleyin.",
                                 text_color="#FF6B7A")
            return
        self.durum.configure(text="%d cihaz bulundu" % len(bulunan), text_color=R["yesil"])
        for k in bulunan:
            sat = ctk.CTkFrame(self.liste, fg_color=R["panel"], corner_radius=12)
            sat.pack(fill="x", pady=4, padx=4)
            ad = k["ad"] or k["donanim"] or "ONVIF kamera"
            ctk.CTkLabel(sat, text=ad, font=self.app.F(14, True), text_color=R["metin"],
                         anchor="w").pack(anchor="w", padx=12, pady=(8, 0))
            ctk.CTkLabel(sat, text="%s:%s" % (k["ip"], k["port"]), font=self.app.F(12),
                         text_color=R["soluk"], anchor="w").pack(anchor="w", padx=12, pady=(0, 8))
            ctk.CTkButton(sat, text="Seç", width=70, height=32, corner_radius=10, fg_color=R["vurgu"],
                          hover_color=R["vurgu_h"], font=self.app.F(13, True),
                          command=lambda kk=k: self._sec(kk)).place(relx=1.0, rely=0.5, anchor="e", x=-12)

    def _sec(self, k):
        self.destroy()
        port = 2020 if k["port"] in (80, 443) else k["port"]
        self.app.kamera_ekle_ac({"ad": k["ad"] or k["donanim"] or "Tapo Kamera", "ip": k["ip"], "port": port})


class AyarDialog(Diyalog):
    def __init__(self, app):
        super().__init__(app, "Kayıt Ayarları", 520, 720)
        a = app.ayarlar
        cerceve = ctk.CTkFrame(self, fg_color="transparent")
        cerceve.pack(fill="both", expand=True, padx=24, pady=20)
        ctk.CTkLabel(cerceve, text="Kayıt Ayarları", font=app.F(20, True), text_color=R["metin"],
                     anchor="w").pack(fill="x", pady=(0, 8))

        self.etiket(cerceve, "KAYIT KLASÖRÜ").pack(fill="x", pady=(8, 2))
        k = ctk.CTkFrame(cerceve, fg_color="transparent")
        k.pack(fill="x")
        self.e_klasor = self.giris(k)
        self.e_klasor.pack(side="left", fill="x", expand=True)
        self.e_klasor.insert(0, a.kayit_klasoru)
        self.dugme(k, "Gözat", self._gozat, genislik=80).pack(side="left", padx=(8, 0))

        self.etiket(cerceve, "KAYIT MODU").pack(fill="x", pady=(14, 2))
        self.mod = ctk.CTkOptionMenu(cerceve, values=[m[0] for m in MODLAR], fg_color=R["kart"],
                                     button_color=R["kenar2"], button_hover_color=R["hover"],
                                     dropdown_fg_color=R["kart"], height=38, corner_radius=10, font=app.F(13),
                                     dynamic_resizing=False)
        self.mod.pack(fill="x")
        self.mod.set([m[0] for m in MODLAR if m[1] == a.mod][0] if a.mod in [m[1] for m in MODLAR] else MODLAR[2][0])

        self.s_sonra = self._kaydirici(cerceve, "OLAY SONRASI KAYIT SÜRESİ", 3, 60, 57, a.olay_sonrasi_sn, " sn")
        self.s_once = self._kaydirici(cerceve, "OLAY ÖNCESİ KAYIT (ön bellek)", 0, 10, 10, a.onbellek_sn, " sn")
        self.s_hass = self._kaydirici(cerceve, "ALGILAMA HASSASİYETİ", 1, 100, 99, a.hassasiyet, "")
        self.s_parca = self._kaydirici(cerceve, "SÜREKLİ KAYITTA DOSYA UZUNLUĞU", 1, 60, 59, a.parca_dk, " dk")

        self.c_ses = ctk.CTkCheckBox(cerceve, text="Kayıtlara kamera sesini ekle", font=app.F(13), text_color=R["metin2"],
                                     fg_color=R["vurgu"], hover_color=R["vurgu_h"], border_color=R["kenar2"])
        self.c_ses.pack(anchor="w", pady=(16, 0))
        (self.c_ses.select if getattr(a, "ses_kaydi", True) else self.c_ses.deselect)()
        ctk.CTkLabel(cerceve, text="Kamera mikrofonu açıksa kayıtlar sesli olur (ffmpeg gerekir: pip install imageio-ffmpeg). "
                                   "Ses, kayıt bitince arka planda eklenir.", font=app.F(11), text_color=R["soluk"],
                     wraplength=470, justify="left", anchor="w").pack(fill="x", pady=(4, 0))
        self.dugme(cerceve, "🔔  Bildirim ayarları…", lambda: (self.destroy(), app.bildirim_ac()), genislik=210).pack(anchor="w", pady=(14, 0))
        ctk.CTkLabel(cerceve, text="Kişi algılama bilgisayarın işlemcisini kullanır; yavaş bilgisayarda "
                                   "‘Hareket algılanınca’ modu daha akıcıdır.",
                     font=app.F(11), text_color=R["soluk"], wraplength=470, justify="left",
                     anchor="w").pack(fill="x", pady=(12, 0))
        alt = ctk.CTkFrame(cerceve, fg_color="transparent")
        alt.pack(fill="x", side="bottom")
        self.dugme(alt, "Kaydet", self._kaydet, vurgulu=True, genislik=100).pack(side="right")
        self.dugme(alt, "İptal", self.destroy, genislik=90).pack(side="right", padx=8)

    def _kaydirici(self, ust, etiket, alt, ust_sinir, adim, deger, ek):
        sat = ctk.CTkFrame(ust, fg_color="transparent")
        sat.pack(fill="x", pady=(14, 0))
        self.etiket(sat, etiket).pack(side="left")
        lbl = ctk.CTkLabel(sat, text="%d%s" % (deger, ek), font=self.app.F(12, True), text_color=R["mavi"])
        lbl.pack(side="right")
        s = ctk.CTkSlider(ust, from_=alt, to=ust_sinir, number_of_steps=adim, progress_color=R["vurgu"],
                          button_color="white", button_hover_color="#DDE6FF", fg_color=R["kenar"],
                          command=lambda v, l=lbl, e=ek: l.configure(text="%d%s" % (round(v), e)))
        s.pack(fill="x", pady=(6, 0))
        s.set(deger)
        return s

    def _gozat(self):
        d = filedialog.askdirectory(parent=self, initialdir=self.e_klasor.get() or str(Path.home()))
        if d:
            self.e_klasor.delete(0, "end")
            self.e_klasor.insert(0, d)

    def _kaydet(self):
        a = self.app.ayarlar
        klasor = self.e_klasor.get().strip()
        if klasor:
            a.kayit_klasoru = klasor
        secim = self.mod.get()
        for ad, anahtar in MODLAR:
            if ad == secim:
                a.mod = anahtar
        a.olay_sonrasi_sn = int(round(self.s_sonra.get()))
        a.onbellek_sn = int(round(self.s_once.get()))
        a.hassasiyet = int(round(self.s_hass.get()))
        a.parca_dk = int(round(self.s_parca.get()))
        a.ses_kaydi = bool(self.c_ses.get())
        self.app.kaydet()
        self.app.disk_goster()
        self.app.mod_etiketi_guncelle()
        self.destroy()


# --------------------------------------------------------- uygulama içi açılır bildirim
class AcilirBildirim(tk.Toplevel):
    """Windows bildirimi gösterilemezse ekranın sağ altında beliren küçük, kendiliğinden kapanan pencere."""

    def __init__(self, app, baslik, mesaj, kamera_id=None, sure_ms=8000):
        super().__init__(app)
        self.app, self.kamera_id = app, kamera_id
        self.overrideredirect(True)
        try:
            self.attributes("-topmost", True)
        except tk.TclError:
            pass
        self.configure(bg=R["kenar2"])
        w, h = app.sc(360), app.sc(84)
        x = self.winfo_screenwidth() - w - 24
        y = self.winfo_screenheight() - h - 70
        self.geometry("%dx%d+%d+%d" % (w, h, x, y))
        ic = tk.Frame(self, bg=R["kart"])
        ic.pack(fill="both", expand=True, padx=1, pady=1)
        tk.Label(ic, text="●", fg=R["kirmizi"], bg=R["kart"], font=("Segoe UI", 14)).pack(side="left", padx=(14, 8))
        metin = tk.Frame(ic, bg=R["kart"])
        metin.pack(side="left", fill="both", expand=True, pady=10)
        tk.Label(metin, text=baslik, fg=R["metin"], bg=R["kart"], font=("Segoe UI", 12, "bold"), anchor="w").pack(fill="x")
        tk.Label(metin, text=mesaj, fg=R["metin2"], bg=R["kart"], font=("Segoe UI", 10), anchor="w").pack(fill="x")
        for wdg in (self, ic, metin):
            wdg.bind("<Button-1>", lambda e: self._ac())
        self.after(sure_ms, self.kapat)

    def _ac(self):
        try:
            if self.kamera_id and self.kamera_id in self.app.isciler:
                self.app.sec(self.kamera_id)
            self.app.deiconify()
            self.app.lift()
        finally:
            self.kapat()

    def kapat(self):
        try:
            self.destroy()
        except Exception:
            pass


# ------------------------------------------------------------------ bildirim ayarları
class BildirimDialog(Diyalog):
    def __init__(self, app):
        super().__init__(app, "Bildirimler", 560, 700)
        b = app.bildirim_ayar
        c = ctk.CTkFrame(self, fg_color="transparent")
        c.pack(fill="both", expand=True, padx=26, pady=20)
        ctk.CTkLabel(c, text="Bildirimler", font=app.F(22, True), text_color=R["metin"], anchor="w").pack(fill="x")
        ctk.CTkLabel(c, text="Hareket ya da kişi algılandığında haber verir. Algılama, Kayıt Ayarları’nda mod "
                             "‘Hareket algılanınca’ veya ‘Kişi algılanınca’ iken çalışır.",
                     font=app.F(12), text_color=R["soluk"], wraplength=500, justify="left", anchor="w").pack(fill="x", pady=(2, 10))

        kutu = dict(font=app.F(13), text_color=R["metin2"], fg_color=R["vurgu"], hover_color=R["vurgu_h"],
                    border_color=R["kenar2"])
        self.c_masa = ctk.CTkCheckBox(c, text="Masaüstü bildirimi göster", **kutu)
        self.c_masa.pack(anchor="w", pady=(8, 0))
        self.c_ses = ctk.CTkCheckBox(c, text="Bildirim sesi çal", **kutu)
        self.c_ses.pack(anchor="w", pady=(10, 0))
        self.dugme(c, "Masaüstü bildirimini dene", self._masa_test, genislik=230).pack(anchor="w", pady=(10, 0))

        ctk.CTkFrame(c, height=1, fg_color=R["kenar"]).pack(fill="x", pady=16)
        self.c_wa = ctk.CTkCheckBox(c, text="WhatsApp mesajı gönder", **kutu)
        self.c_wa.pack(anchor="w")
        self.etiket(c, "TELEFON NUMARASI (ülke kodlu)").pack(fill="x", pady=(10, 2))
        self.e_tel = self.giris(c, placeholder_text="+905321234567")
        self.e_tel.pack(fill="x")
        self.etiket(c, "CALLMEBOT API ANAHTARI").pack(fill="x", pady=(10, 2))
        self.e_anahtar = self.giris(c, show="•")
        self.e_anahtar.pack(fill="x")
        satir = ctk.CTkFrame(c, fg_color="transparent")
        satir.pack(fill="x", pady=(10, 0))
        self.dugme(satir, "WhatsApp’ı dene", self._wa_test, genislik=150).pack(side="left")
        self.dugme(satir, "Kurulum adımları", lambda: webbrowser.open(bd.KURULUM_ADRESI), genislik=150).pack(side="left", padx=8)
        self.sonuc = ctk.CTkLabel(c, text="", font=app.F(12), text_color=R["soluk"], wraplength=500,
                                  justify="left", anchor="w")
        self.sonuc.pack(fill="x", pady=(8, 0))
        ctk.CTkLabel(c, text="WhatsApp, ücretsiz ve kişisel kullanıma yönelik CallMeBot servisiyle gönderilir: botun "
                             "numarasına WhatsApp’tan “I allow callmebot to send me messages” yazınca API anahtarınız "
                             "gelir (bot dolu olabilir; kurulum sayfasına bakın). Mesaj metni (kamera adı, saat) bu "
                             "üçüncü taraf servis üzerinden geçer; görüntü gönderilmez. Anahtar bu bilgisayarda "
                             "düz metin saklanır.",
                     font=app.F(11), text_color=R["soluk"], wraplength=500, justify="left", anchor="w").pack(fill="x", pady=(8, 0))

        self.etiket(c, "AYNI KAMERADAN EN SIK").pack(fill="x", pady=(14, 0))
        sat = ctk.CTkFrame(c, fg_color="transparent")
        sat.pack(fill="x")
        self.bek_lbl = ctk.CTkLabel(sat, text="", font=app.F(12, True), text_color=R["mavi"])
        self.bek_lbl.pack(side="right")
        self.s_bek = ctk.CTkSlider(c, from_=10, to=600, number_of_steps=59, progress_color=R["vurgu"],
                                   button_color="white", button_hover_color="#DDE6FF", fg_color=R["kenar"],
                                   command=self._bek_goster)
        self.s_bek.pack(fill="x", pady=(2, 0))
        alt = ctk.CTkFrame(c, fg_color="transparent")
        alt.pack(fill="x", side="bottom")
        self.dugme(alt, "Kaydet", self._kaydet, vurgulu=True, genislik=100).pack(side="right")
        self.dugme(alt, "İptal", self.destroy, genislik=90).pack(side="right", padx=8)

        (self.c_masa.select if b["masaustu"] else self.c_masa.deselect)()
        (self.c_ses.select if b["ses"] else self.c_ses.deselect)()
        (self.c_wa.select if b["whatsapp"] else self.c_wa.deselect)()
        self.e_tel.insert(0, b["telefon"])
        self.e_anahtar.insert(0, b["anahtar"])
        self.s_bek.set(b["bekleme_sn"])
        self._bek_goster(b["bekleme_sn"])

    def _bek_goster(self, v):
        v = int(round(float(v) / 10.0) * 10)
        self.bek_lbl.configure(text=("%d sn" % v) if v < 120 else ("%.0f dk" % (v / 60.0)))

    def _durum(self, metin, iyi):
        self.sonuc.configure(text=metin, text_color=R["yesil"] if iyi else "#FF6B7A")

    def _masa_test(self):
        def is_():
            ok = self.app.bildirimci.test_masaustu()
            self.app.ui(lambda: self._durum("Masaüstü bildirimi gönderildi." if ok else "Bildirim gösterilemedi.", ok))
        threading.Thread(target=is_, daemon=True).start()

    def _wa_test(self):
        tel, anahtar = self.e_tel.get(), self.e_anahtar.get()
        self._durum("Gönderiliyor…", True)

        def is_():
            ok, acik = self.app.bildirimci.test_whatsapp(tel, anahtar)
            self.app.ui(lambda: self._durum(acik if not ok else "Test mesajı gönderildi — WhatsApp’ınızı kontrol edin.", ok))
        threading.Thread(target=is_, daemon=True).start()

    def _kaydet(self):
        tel = self.e_tel.get().strip()
        duz = bd.telefon_duzelt(tel) if tel else ""
        if self.c_wa.get() and (not duz or not self.e_anahtar.get().strip()):
            self._durum("WhatsApp için geçerli bir telefon (örn. +905321234567) ve API anahtarı girin.", False)
            return
        self.app.bildirim_ayar.update({
            "masaustu": bool(self.c_masa.get()), "ses": bool(self.c_ses.get()), "whatsapp": bool(self.c_wa.get()),
            "telefon": duz or tel, "anahtar": self.e_anahtar.get().strip(),
            "bekleme_sn": int(round(float(self.s_bek.get()) / 10.0) * 10)})
        self.app.kaydet()
        self.destroy()


# ----------------------------------------------------------- gömülü video oynatıcı
class Oynatici(ctk.CTkToplevel):
    """Kayıtları uygulamanın içinde oynatır: oynat/duraklat, ilerleme çubuğu, ±10 sn, hız, önceki/sonraki."""
    HIZLAR = ["0.5×", "1×", "2×", "4×"]

    def __init__(self, app, yollar, indeks=0, ust=None):
        super().__init__(ust or app)
        self.app = app
        self.ust_pencere = ust          # Kayıtlar penceresi: modal olduğundan oynatıcı onun önünde açılmalı
        self.yollar = list(yollar)
        self.indeks = max(0, min(indeks, len(self.yollar) - 1))
        self.fps, self.n = 15.0, 0
        self.hiz = 1.0
        self._kilit = threading.Lock()
        self._kare, self._kare_idx, self._kare_no, self._cizilen = None, 0, 0, -1
        self._git = None
        self._oynuyor = threading.Event()
        self._dur = threading.Event()
        self._bitti = False
        self._hata = ""
        self._thr = None
        self._foto = None
        self._img = None
        self._tam = False
        self._surukle = False
        self._ctk_kapali = False
        # ses
        self._ff = sesm.ffmpeg_onbellekli()
        self.ses_cikis = sesm.SesCikisi(app.ses_cikis._sd or None)
        self.ses_cikis.seviye = app.ses_cikis.seviye
        self.dosya_sesi = None
        self.sesli = False                 # açık kayıtta ses akışı var mı
        self.ses_acik = True
        self._ses_bekle = None
        self.title("Kayıt Oynatıcı")
        self.configure(fg_color=R["bg"])
        self.geometry("1100x700+%d+%d" % (app.winfo_rootx() + 60, app.winfo_rooty() + 40))
        self.minsize(720, 480)
        self.transient(ust or app)

        self.ust = ctk.CTkFrame(self, fg_color="transparent")
        self.ust.pack(fill="x", padx=20, pady=(14, 8))
        bas = ctk.CTkFrame(self.ust, fg_color="transparent")
        bas.pack(side="left")
        self.baslik = ctk.CTkLabel(bas, text="", font=app.F(17, True), text_color=R["metin"], anchor="w")
        self.baslik.pack(anchor="w")
        self.alt = ctk.CTkLabel(bas, text="", font=app.F(12), text_color=R["soluk"], anchor="w")
        self.alt.pack(anchor="w")
        ctk.CTkButton(self.ust, text="Harici oynatıcıda aç", width=150, height=34, corner_radius=10,
                      fg_color=R["kart"], hover_color=R["hover"], border_width=1, border_color=R["kenar2"],
                      text_color=R["metin2"], font=app.F(12), command=self._harici).pack(side="right")

        self.cerceve = ctk.CTkFrame(self, fg_color=R["video"], corner_radius=16, border_width=1, border_color=R["kenar"])
        self.cerceve.pack(fill="both", expand=True, padx=20)
        self.video = tk.Canvas(self.cerceve, bg=R["video"], highlightthickness=0)
        self.video.pack(fill="both", expand=True, padx=4, pady=4)
        self.video.bind("<Button-1>", lambda e: self.oynat_duraklat())
        self.video.bind("<Double-Button-1>", lambda e: self.tam_ekran())

        self.alt_bar = ctk.CTkFrame(self, fg_color=R["panel"], corner_radius=16, border_width=1, border_color=R["kenar"])
        self.alt_bar.pack(fill="x", padx=20, pady=(10, 16))
        ust_s = ctk.CTkFrame(self.alt_bar, fg_color="transparent")
        ust_s.pack(fill="x", padx=16, pady=(12, 0))
        self.zaman_lbl = ctk.CTkLabel(ust_s, text="0:00", font=app.F(12, True), text_color=R["mavi"], width=48)
        self.zaman_lbl.pack(side="left")
        self.sure_lbl = ctk.CTkLabel(ust_s, text="0:00", font=app.F(12), text_color=R["soluk"], width=48)
        self.sure_lbl.pack(side="right")
        self.cubuk = ctk.CTkSlider(ust_s, from_=0, to=1, progress_color=R["vurgu"], button_color="white",
                                   button_hover_color="#DDE6FF", fg_color=R["kenar"], command=self._kaydir)
        self.cubuk.pack(side="left", fill="x", expand=True, padx=10)
        self.cubuk.set(0)
        self.cubuk.bind("<ButtonPress-1>", lambda e: setattr(self, "_surukle", True), add="+")
        self.cubuk.bind("<ButtonRelease-1>", lambda e: setattr(self, "_surukle", False), add="+")

        dugmeler = ctk.CTkFrame(self.alt_bar, fg_color="transparent")
        dugmeler.pack(fill="x", padx=16, pady=(8, 12))
        stil = dict(height=38, corner_radius=12, fg_color=R["kart"], hover_color=R["hover"], border_width=1,
                    border_color=R["kenar"], text_color=R["metin2"], font=app.F(13))
        orta = ctk.CTkFrame(dugmeler, fg_color="transparent")
        orta.pack()
        self.onceki_btn = ctk.CTkButton(orta, text="⏮", width=46, command=lambda: self.kayda_git(-1), **stil)
        self.onceki_btn.pack(side="left", padx=3)
        ctk.CTkButton(orta, text="↺ 10", width=60, command=lambda: self.atla(-10), **stil).pack(side="left", padx=3)
        self.oynat_btn = ctk.CTkButton(orta, text="▶", width=70, height=42, corner_radius=14, fg_color=R["vurgu"],
                                       hover_color=R["vurgu_h"], text_color="white", font=app.F(16, True),
                                       command=self.oynat_duraklat)
        self.oynat_btn.pack(side="left", padx=6)
        ctk.CTkButton(orta, text="10 ↻", width=60, command=lambda: self.atla(10), **stil).pack(side="left", padx=3)
        self.sonraki_btn = ctk.CTkButton(orta, text="⏭", width=46, command=lambda: self.kayda_git(1), **stil)
        self.sonraki_btn.pack(side="left", padx=3)
        sag = ctk.CTkFrame(dugmeler, fg_color="transparent")
        sag.place(relx=1.0, rely=0.5, anchor="e")
        self.hiz_menu = ctk.CTkOptionMenu(sag, values=self.HIZLAR, width=80, height=36, corner_radius=10,
                                          fg_color=R["kart"], button_color=R["kenar2"], button_hover_color=R["hover"],
                                          dropdown_fg_color=R["kart"], font=app.F(12), dynamic_resizing=False,
                                          command=self._hiz_sec)
        self.hiz_menu.pack(side="left", padx=3)
        self.hiz_menu.set("1×")
        self.ses_btn = ctk.CTkButton(sag, text="🔊", width=46, command=self.ses_degistir, **stil)
        self.ses_btn.pack(side="left", padx=3)
        self.ses_slider = ctk.CTkSlider(sag, from_=0, to=1, width=80, number_of_steps=20, progress_color=R["vurgu"],
                                        button_color="white", button_hover_color="#DDE6FF", fg_color=R["kenar"],
                                        command=self._ses_seviye)
        self.ses_slider.pack(side="left", padx=(0, 6))
        self.ses_slider.set(self.ses_cikis.seviye)
        ctk.CTkButton(sag, text="📷", width=46, command=self.kare_kaydet, **stil).pack(side="left", padx=3)
        ctk.CTkButton(sag, text="⛶", width=46, command=self.tam_ekran, **stil).pack(side="left", padx=3)
        self.sayac_lbl = ctk.CTkLabel(dugmeler, text="", font=app.F(12), text_color=R["soluk"])
        self.sayac_lbl.place(relx=0.0, rely=0.5, anchor="w")

        for tus, fn in (("<space>", lambda e: self.oynat_duraklat()), ("<Left>", lambda e: self.atla(-5)),
                        ("<Right>", lambda e: self.atla(5)), ("<Up>", lambda e: self.kayda_git(-1)),
                        ("<Down>", lambda e: self.kayda_git(1)), ("<f>", lambda e: self.tam_ekran()),
                        ("<Escape>", lambda e: self._escape())):
            self.bind(tus, fn)
        self.protocol("WM_DELETE_WINDOW", self.kapat)
        self._one_getir()
        self.after(150, self._one_getir)
        self._ac()
        self.after(30, self._ciz)

    def _one_getir(self):
        """Pencereyi her şeyin önüne alır ve (Kayıtlar penceresinin tuttuğu) modal odağı devralır."""
        if self._ctk_kapali:
            return
        try:
            self.lift()
            self.attributes("-topmost", True)
            self.after(300, lambda: self._topmost_kapat())
            self.grab_set()
            self.focus_force()
        except tk.TclError:
            pass

    def _topmost_kapat(self):
        try:
            if not self._ctk_kapali:
                self.attributes("-topmost", False)
        except tk.TclError:
            pass

    # ------------------------------------------------------------- kaynak
    def _ac(self):
        """Seçili kaydı arka plan iş parçacığında açar ve oynatmaya başlar."""
        self._durdur_is()
        yol = self.yollar[self.indeks]
        self._dur = threading.Event()
        self._oynuyor = threading.Event()
        self._bitti, self._hata, self._git = False, "", None
        self._kare, self._kare_idx, self._kare_no, self._cizilen = None, 0, 0, -1
        self.n = 0
        self.zaman_lbl.configure(text="0:00")
        self.sure_lbl.configure(text="—")
        self.cubuk.set(0)
        info = kl.dosya_bilgisi(yol, 0, 0)
        self.baslik.configure(text=info["kamera"])
        self.alt.configure(text="%s · %s" % (info["zaman"].strftime("%d.%m.%Y %H:%M:%S"), yol.name))
        self.title("Kayıt Oynatıcı — %s" % info["kamera"])
        self.sayac_lbl.configure(text="%d / %d" % (self.indeks + 1, len(self.yollar)))
        self.onceki_btn.configure(state="normal" if self.indeks > 0 else "disabled")
        self.sonraki_btn.configure(state="normal" if self.indeks < len(self.yollar) - 1 else "disabled")
        self._oynuyor.set()
        self._buton_guncelle()
        self._thr = threading.Thread(target=self._isci, args=(yol, self._dur, self._oynuyor), daemon=True)
        self._thr.start()
        self.sesli = False
        self._ses_kapat_is()
        self.ses_btn.configure(text="🔈", state="disabled")
        threading.Thread(target=self._ses_ara, args=(yol,), daemon=True).start()

    # ------------------------------------------------------------------- ses
    def _ses_ara(self, yol):
        var = sesm.ses_var(self._ff, yol) if self._ff else None
        def sonuc():
            if self._ctk_kapali or self.yollar[self.indeks] != yol:
                return
            self.sesli = bool(var)
            self._ses_buton()
            self._ses_esitle()
        self.app.ui(sonuc)

    def _ses_buton(self):
        if not self._ff:
            self.ses_btn.configure(text="🔈", state="disabled")
            self.alt.configure(text=self.alt.cget("text").split("  ·  ")[0] + "  ·  Ses için ffmpeg gerekli")
        elif not self.sesli:
            self.ses_btn.configure(text="🔇", state="disabled")
        else:
            self.ses_btn.configure(text="🔊" if self.ses_acik else "🔇", state="normal")

    def ses_degistir(self):
        self.ses_acik = not self.ses_acik
        self._ses_buton()
        self._ses_esitle()

    def _ses_seviye(self, v):
        self.ses_cikis.seviye = float(v)
        self.app.ses_cikis.seviye = float(v)

    def _ses_kapat_is(self):
        if self.dosya_sesi is not None:
            self.dosya_sesi.durdur()
        self.ses_cikis.temizle()

    def _ses_gecikmeli(self):
        """Kaydırma sırasında sesi sustur; bırakılınca (kısa gecikmeyle) yeni konumdan başlat."""
        self._ses_kapat_is()
        if self._ses_bekle is not None:
            try:
                self.after_cancel(self._ses_bekle)
            except Exception:
                pass
        self._ses_bekle = self.after(280, self._ses_esitle)

    def _ses_esitle(self):
        """Ses durumunu görüntüye eşler: oynuyorsa videonun bulunduğu saniyeden çal, değilse sustur."""
        self._ses_bekle = None
        if self._ctk_kapali:
            return
        calmali = (self._ff and self.sesli and self.ses_acik and self._oynuyor.is_set() and not self._bitti
                   and not self._hata and self.hiz <= 2.0 and not self._surukle)
        if not calmali:
            self._ses_kapat_is()
            return
        if not self.ses_cikis.ac():
            self._ses_kapat_is()
            self.alt.configure(text="Ses çıkışı kullanılamıyor (sounddevice kurulu değil)")
            self.sesli = False
            self._ses_buton()
            return
        if self.dosya_sesi is None or self.dosya_sesi.yol != str(self.yollar[self.indeks]):
            self.dosya_sesi = sesm.DosyaSesi(self._ff, self.yollar[self.indeks], self.ses_cikis)
        self.dosya_sesi.baslat(self._kare_idx / float(self.fps or 15.0) + 0.2, self.hiz)

    def _durdur_is(self):
        self._dur.set()
        self._oynuyor.set()           # bekleyen iş parçacığı uyanıp çıksın
        t = self._thr
        if t is not None and t.is_alive() and t is not threading.current_thread():
            t.join(1.5)
        self._thr = None

    def _isci(self, yol, dur, oynuyor):
        import cv2
        cap = None
        try:
            cap = cv2.VideoCapture(str(yol))
            if not cap.isOpened():
                self._hata = "Kayıt açılamadı (dosya bozuk olabilir)."
                return
            fps = cap.get(cv2.CAP_PROP_FPS) or 0
            n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
            self.fps = fps if 1 <= fps <= 120 else 15.0
            self.n = max(0, n)
            idx = 0
            while not dur.is_set():
                hedef, self._git = self._git, None
                if hedef is not None:
                    hedef = max(0, min(int(hedef), max(self.n - 1, 0)))
                    cap.set(cv2.CAP_PROP_POS_FRAMES, hedef)
                    idx = hedef
                    self._bitti = False
                    ok, kare = cap.read()
                    if ok:
                        with self._kilit:
                            self._kare, self._kare_idx = kare, idx
                            self._kare_no += 1
                        idx += 1
                    continue
                if not oynuyor.is_set() or self._bitti:
                    time.sleep(0.02)
                    continue
                t0 = time.monotonic()
                ok, kare = cap.read()
                if not ok:
                    self._bitti = True
                    continue
                with self._kilit:
                    self._kare, self._kare_idx = kare, idx
                    self._kare_no += 1
                idx += 1
                bekle = (1.0 / self.fps) / self.hiz - (time.monotonic() - t0)
                if bekle > 0:
                    dur.wait(bekle)
            return
        except Exception as e:
            self._hata = "Oynatma hatası: %s" % e
        finally:
            if cap is not None:
                cap.release()

    # ------------------------------------------------------------ denetimler
    def oynat_duraklat(self):
        if self._hata:
            return
        if self._bitti:                       # bitti: baştan oynat
            self._git = 0
            self._oynuyor.set()
        elif self._oynuyor.is_set():
            self._oynuyor.clear()
        else:
            self._oynuyor.set()
        self._buton_guncelle()
        self._ses_esitle()

    def _buton_guncelle(self):
        self.oynat_btn.configure(text="↻" if self._bitti else ("⏸" if self._oynuyor.is_set() else "▶"))

    def atla(self, sn):
        if self._hata or not self.n:
            return
        self._git = max(0, min(self.n - 1, self._kare_idx + int(sn * self.fps)))
        self._bitti = False
        self._buton_guncelle()
        self._ses_kapat_is()
        self._ses_bekle = self.after(350, self._ses_esitle)

    def _kaydir(self, v):
        if self.n:
            self._git = int(float(v) * max(self.n - 1, 0))
            self._bitti = False
            self._ses_gecikmeli()

    def _hiz_sec(self, v):
        try:
            self.hiz = float(v.replace("×", ""))
        except ValueError:
            self.hiz = 1.0
        self._ses_esitle()

    def kayda_git(self, yon):
        yeni = self.indeks + yon
        if 0 <= yeni < len(self.yollar):
            self.indeks = yeni
            self._ac()

    def kare_kaydet(self):
        with self._kilit:
            kare = None if self._kare is None else self._kare.copy()
            idx = self._kare_idx
        if kare is None:
            return
        try:
            import cv2
            yol = self.yollar[self.indeks]
            ok, tampon = cv2.imencode(".jpg", kare, [cv2.IMWRITE_JPEG_QUALITY, 92])
            hedef = yol.with_name("%s_kare%d.jpg" % (yol.stem, idx))
            hedef.write_bytes(tampon.tobytes())
            self.app.gunluk_ekle("-", "BİLGİ", "Kare kaydedildi: %s" % hedef.name)
            self.alt.configure(text="Kare kaydedildi: %s" % hedef.name)
        except Exception as e:
            self.app.gunluk_ekle("-", "HATA", "Kare kaydedilemedi: %s" % e)

    def tam_ekran(self):
        self._tam = not self._tam
        self.attributes("-fullscreen", self._tam)
        for w in (self.ust, self.alt_bar):
            if self._tam:
                w.pack_forget()
            else:
                pass
        if not self._tam:
            self.ust.pack(fill="x", padx=20, pady=(14, 8), before=self.cerceve)
            self.alt_bar.pack(fill="x", padx=20, pady=(10, 16))

    def _escape(self):
        if self._tam:
            self.tam_ekran()
        else:
            self.kapat()

    def _harici(self):
        self._oynuyor.clear()
        self._buton_guncelle()
        yolu_ac(self.yollar[self.indeks])

    # ----------------------------------------------------------------- çizim
    def _ciz(self):
        if self._ctk_kapali:
            return
        try:
            self._ciz_ic()
        except Exception:
            traceback.print_exc()
        self.after(30, self._ciz)

    def _ciz_ic(self):
        c = self.video
        cw, ch = c.winfo_width(), c.winfo_height()
        if cw < 40 or ch < 40:
            return
        with self._kilit:
            kare, idx, no = self._kare, self._kare_idx, self._kare_no
        anahtar = (no, cw, ch)
        if kare is not None and anahtar != self._cizilen:
            self._cizilen = anahtar
            self._foto = ImageTk.PhotoImage(Image.fromarray(kare_boyutlandir(kare, cw - 4, ch - 4)))
            if self._img is None:
                self._img = c.create_image(cw // 2, ch // 2, image=self._foto)
            else:
                c.itemconfigure(self._img, image=self._foto)
                c.coords(self._img, cw // 2, ch // 2)
            c.tag_lower(self._img)
        c.delete("ov")
        if self._hata:
            c.create_text(cw // 2, ch // 2, text=self._hata, fill=R["kirmizi"], font=("Segoe UI", 13, "bold"), tags="ov")
        elif kare is None:
            c.create_text(cw // 2, ch // 2, text="Yükleniyor…", fill=R["soluk"], font=("Segoe UI", 13), tags="ov")
        elif not self._oynuyor.is_set() or self._bitti:
            c.create_oval(cw // 2 - 36, ch // 2 - 36, cw // 2 + 36, ch // 2 + 36, fill="#0A0E16", outline="", tags="ov")
            c.create_text(cw // 2 + 3, ch // 2, text="↻" if self._bitti else "▶", fill="white",
                          font=("Segoe UI", 26), tags="ov")
        if self._bitti:
            self._buton_guncelle()
            if self.dosya_sesi is not None and self.dosya_sesi._thr is not None:
                self._ses_kapat_is()
        if self.n:
            sn = idx / self.fps
            self.zaman_lbl.configure(text=kl.sure_metni(sn) if sn >= 1 else "0:00")
            self.sure_lbl.configure(text=kl.sure_metni(self.n / self.fps))
            if not self._surukle:
                self.cubuk.set(min(1.0, idx / float(max(self.n - 1, 1))))

    def kapat(self):
        if self._ctk_kapali:
            return
        self._ctk_kapali = True
        self._durdur_is()
        try:
            self._ses_kapat_is()
            self.ses_cikis.kapat()
        except Exception:
            pass
        try:
            self.grab_release()
        except Exception:
            pass
        try:
            self.destroy()
        except Exception:
            pass
        u = self.ust_pencere
        if u is not None:                      # modal odağı Kayıtlar penceresine geri ver
            try:
                if u.winfo_exists():
                    u.after(50, u._modal)
            except Exception:
                pass


class KayitlarDialog(Diyalog):
    SAYFA = 40

    def __init__(self, app):
        super().__init__(app, "Kayıtlar", 1120, 720)
        self.yollar = {}
        self.tum = []
        self.secim = []                 # seçili kayıtlar (yol listesi); sonuncusu önizlenir
        self.kartlar = {}               # yol -> kart çerçevesi
        self.limit = self.SAYFA
        self.meta = {}                  # yol -> {"sure","w","h","kucuk"}  (arka planda doldurulur)
        self._canli = True
        self._ex = ThreadPoolExecutor(max_workers=1)
        self._gorunen = []
        self.oynatici = None
        self.protocol("WM_DELETE_WINDOW", self._kapat)

        kok = ctk.CTkFrame(self, fg_color="transparent")
        kok.pack(fill="both", expand=True, padx=22, pady=18)
        kok.grid_columnconfigure(0, weight=1)
        kok.grid_rowconfigure(2, weight=1)

        # üst: başlık + eylemler
        ust = ctk.CTkFrame(kok, fg_color="transparent")
        ust.grid(row=0, column=0, columnspan=2, sticky="ew")
        bas = ctk.CTkFrame(ust, fg_color="transparent")
        bas.pack(side="left")
        ctk.CTkLabel(bas, text="Kayıtlar", font=app.F(24, True), text_color=R["metin"], anchor="w").pack(anchor="w")
        self.ozet = ctk.CTkLabel(bas, text="", font=app.F(12), text_color=R["soluk"], anchor="w")
        self.ozet.pack(anchor="w")
        self.dugme(ust, "↻  Yenile", self._yukle, genislik=100).pack(side="right")
        self.dugme(ust, "📁  Klasörü Aç", app.klasoru_ac, genislik=130).pack(side="right", padx=(0, 8))

        # süzgeçler
        suz = ctk.CTkFrame(kok, fg_color="transparent")
        suz.grid(row=1, column=0, columnspan=2, sticky="ew", pady=(14, 12))
        menu = dict(height=36, corner_radius=10, fg_color=R["kart"], button_color=R["kenar2"],
                    button_hover_color=R["hover"], dropdown_fg_color=R["kart"], font=app.F(12),
                    dynamic_resizing=False)
        self.kamera_suz = ctk.CTkOptionMenu(suz, values=["Tüm kameralar"], width=190, command=lambda v: self._suz(), **menu)
        self.kamera_suz.pack(side="left")
        self.aralik_suz = ctk.CTkOptionMenu(suz, values=[a for a, _ in kl.ARALIKLAR], width=140,
                                            command=lambda v: self._suz(), **menu)
        self.aralik_suz.pack(side="left", padx=8)
        self.sira_suz = ctk.CTkOptionMenu(suz, values=[a for a, _ in kl.SIRALAR], width=120,
                                          command=lambda v: self._suz(), **menu)
        self.sira_suz.pack(side="left")
        self.ara = ctk.CTkEntry(suz, placeholder_text="🔍  Ara (kamera, tarih…)", width=260, height=36,
                                corner_radius=10, fg_color=R["kart"], border_color=R["kenar2"],
                                text_color=R["metin"], font=app.F(12))
        self.ara.pack(side="right")
        self.ara.bind("<KeyRelease>", lambda e: self._suz())

        # sol: kart listesi
        self.liste = ctk.CTkScrollableFrame(kok, fg_color="transparent")
        self.liste.grid(row=2, column=0, sticky="nsew", padx=(0, 16))

        # sağ: önizleme paneli
        self.panel = ctk.CTkFrame(kok, width=360, fg_color=R["kart"], corner_radius=18, border_width=1,
                                  border_color=R["kenar"])
        self.panel.grid(row=2, column=1, sticky="ns")
        self.panel.pack_propagate(False)
        self.onizleme = tk.Canvas(self.panel, width=328, height=185, bg=R["video"], highlightthickness=0)
        self.onizleme.pack(padx=16, pady=(16, 10))
        self._on_foto = None
        self.p_ad = ctk.CTkLabel(self.panel, text="", font=app.F(16, True), text_color=R["metin"], anchor="w",
                                 wraplength=320, justify="left")
        self.p_ad.pack(fill="x", padx=18)
        self.p_alt = ctk.CTkLabel(self.panel, text="", font=app.F(12), text_color=R["soluk"], anchor="w",
                                  wraplength=320, justify="left")
        self.p_alt.pack(fill="x", padx=18, pady=(2, 8))
        self.p_detay = ctk.CTkFrame(self.panel, fg_color="transparent")
        self.p_detay.pack(fill="x", padx=18)
        self.p_detay.grid_columnconfigure(1, weight=1)
        self.p_deger = {}
        for i, ad in enumerate(("Tarih", "Saat", "Süre", "Çözünürlük", "Ses", "Boyut")):
            ctk.CTkLabel(self.p_detay, text=ad, font=app.F(12), text_color=R["soluk"], anchor="w").grid(
                row=i, column=0, sticky="w", pady=3)
            self.p_deger[ad] = ctk.CTkLabel(self.p_detay, text="—", font=app.F(12, True), text_color=R["metin2"], anchor="e")
            self.p_deger[ad].grid(row=i, column=1, sticky="e")
        self.oynat_btn = ctk.CTkButton(self.panel, text="▶  Oynat", command=self._oynat, height=46, corner_radius=14,
                                       fg_color=R["vurgu"], hover_color=R["vurgu_h"], text_color="white",
                                       font=app.F(15, True))
        self.oynat_btn.pack(fill="x", padx=18, pady=(18, 8), side="bottom")
        ikinci = ctk.CTkFrame(self.panel, fg_color="transparent")
        ikinci.pack(fill="x", padx=18, side="bottom")
        ikinci.grid_columnconfigure((0, 1), weight=1)
        self.goster_btn = ctk.CTkButton(ikinci, text="📂  Klasörde Göster", command=self._klasorde_goster, height=38,
                                        corner_radius=12, fg_color=R["panel"], hover_color=R["hover"], border_width=1,
                                        border_color=R["kenar2"], text_color=R["metin2"], font=app.F(12))
        self.goster_btn.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.sil_btn = ctk.CTkButton(ikinci, text="🗑  Sil", command=self._sil, height=38, corner_radius=12,
                                     fg_color=R["panel"], hover_color="#3A1820", border_width=1,
                                     border_color="#5A2530", text_color="#FF8591", font=app.F(12, True))
        self.sil_btn.grid(row=0, column=1, sticky="ew", padx=(4, 0))
        ctk.CTkLabel(self.panel, text="İpucu: Ctrl ile birden fazla kayıt seçilir; çift tıklayınca uygulama içinde oynatılır.",
                     font=app.F(11), text_color=R["soluk"], wraplength=320, justify="left", anchor="w").pack(
            fill="x", padx=18, side="bottom", pady=(0, 8))

        self._yukle()

    # ------------------------------------------------------------------ veri
    def _klasorler(self):
        k, _ = ascii_klasor(self.app.ayarlar.kayit_klasoru)
        liste = [Path(self.app.ayarlar.kayit_klasoru)]
        if k not in liste:
            liste.append(k)
        return liste

    def _yukle(self):
        gorulen, kayitlar = set(), []
        for k in self._klasorler():
            try:
                for p in k.glob("*.mp4"):
                    try:
                        if p.is_symlink() or not p.is_file() or p in gorulen:
                            continue
                        st = p.stat()
                    except OSError:
                        continue
                    gorulen.add(p)
                    kayitlar.append(kl.dosya_bilgisi(p, st.st_size, st.st_mtime))
            except OSError:
                pass
        self.tum = kayitlar
        adlar = ["Tüm kameralar"] + kl.kamera_adlari(kayitlar)
        simdiki = self.kamera_suz.get()
        self.kamera_suz.configure(values=adlar)
        self.kamera_suz.set(simdiki if simdiki in adlar else adlar[0])
        self.secim = [p for p in self.secim if any(k["yol"] == p for k in kayitlar)]
        self.limit = self.SAYFA
        self._suz()

    def _suz(self, sifirla=True):
        if sifirla:
            self.limit = self.SAYFA
        kam = self.kamera_suz.get()
        aralik = dict(kl.ARALIKLAR).get(self.aralik_suz.get(), "hepsi")
        sira = dict(kl.SIRALAR).get(self.sira_suz.get(), "yeni")
        self._gorunen = kl.filtrele(self.tum, "hepsi" if kam == "Tüm kameralar" else kam, aralik,
                                    self.ara.get(), sira)
        toplam = sum(k["boyut"] for k in self.tum)
        self.ozet.configure(text="%d kayıt · toplam %s" % (len(self.tum), boyut_metni(toplam)) +
                            ("   ·   %d sonuç gösteriliyor" % len(self._gorunen) if len(self._gorunen) != len(self.tum) else ""))
        self._ciz_liste()

    # ----------------------------------------------------------------- liste
    def _ciz_liste(self):
        for w in self.liste.winfo_children():
            w.destroy()
        self.kartlar = {}
        if not self._gorunen:
            bos = ctk.CTkFrame(self.liste, fg_color="transparent")
            bos.pack(fill="x", pady=80)
            ctk.CTkLabel(bos, text="🎞", font=self.app.F(40, aile="Segoe UI Emoji"), text_color=R["soluk"]).pack()
            if self.tum:
                ctk.CTkLabel(bos, text="Bu süzgece uyan kayıt yok", font=self.app.F(15, True), text_color=R["metin2"]).pack(pady=(6, 2))
                ctk.CTkLabel(bos, text="Kamera, tarih ya da arama kutusunu değiştirin.", font=self.app.F(12), text_color=R["soluk"]).pack()
            else:
                ctk.CTkLabel(bos, text="Henüz kayıt yok", font=self.app.F(15, True), text_color=R["metin2"]).pack(pady=(6, 2))
                ctk.CTkLabel(bos, text="Kayıt Ayarları’ndan hareket/kişi algılama ya da sürekli kaydı açın;\nkayıtlar burada görünür.",
                             font=self.app.F(12), text_color=R["soluk"], justify="center").pack()
            self._panel_guncelle()
            return
        gosterilen = self._gorunen[:self.limit]
        bugun = dt.date.today()
        for gun, grup in kl.gunlere_bol(gosterilen):
            ctk.CTkLabel(self.liste, text=kl.gun_etiketi(gun, bugun).upper(), font=self.app.F(11, True),
                         text_color=R["soluk"], anchor="w").pack(fill="x", padx=4, pady=(10, 6))
            for k in grup:
                self._kart(k)
        if len(self._gorunen) > self.limit:
            kalan = len(self._gorunen) - self.limit
            ctk.CTkButton(self.liste, text="Daha fazla göster (%d kayıt daha)" % kalan, height=40, corner_radius=12,
                          fg_color=R["kart"], hover_color=R["hover"], text_color=R["metin2"], font=self.app.F(12),
                          command=self._daha).pack(fill="x", pady=12)
        self._panel_guncelle()

    def _daha(self):
        self.limit += self.SAYFA
        self._ciz_liste()

    def _kart(self, k):
        yol = k["yol"]
        kart = ctk.CTkFrame(self.liste, fg_color=R["kart"], corner_radius=14, border_width=2, border_color=R["kenar"])
        kart.pack(fill="x", pady=(0, 8), padx=2)
        tw, th = 150, 84
        cv = tk.Canvas(kart, width=tw, height=th, bg=R["video"], highlightthickness=0)
        cv.pack(side="left", padx=10, pady=10)
        cv.create_text(tw // 2, th // 2, text="🎞", fill=R["kenar2"], font=("Segoe UI Emoji", 22), tags="yer")
        orta = ctk.CTkFrame(kart, fg_color="transparent")
        orta.pack(side="left", fill="both", expand=True, pady=10)
        ad = ctk.CTkLabel(orta, text=k["kamera"], font=self.app.F(14, True), text_color=R["metin"], anchor="w")
        ad.pack(fill="x")
        saat = ctk.CTkLabel(orta, text=k["zaman"].strftime("%H:%M:%S"), font=self.app.F(13), text_color=R["mavi"], anchor="w")
        saat.pack(fill="x", pady=(2, 0))
        sure = ctk.CTkLabel(orta, text="Süre: …   ·   %s" % boyut_metni(k["boyut"]), font=self.app.F(12),
                            text_color=R["soluk"], anchor="w")
        sure.pack(fill="x", pady=(2, 0))
        kart._kayit = {"cv": cv, "sure": sure, "k": k, "tw": tw, "th": th, "foto": None}
        self.kartlar[yol] = kart
        for w in (kart, cv, orta, ad, saat, sure):
            w.bind("<Button-1>", lambda e, y=yol: self._tikla(y, False))
            w.bind("<Control-Button-1>", lambda e, y=yol: self._tikla(y, True))
            w.bind("<Double-Button-1>", lambda e, y=yol: self._cift(y))
        if yol in self.secim:
            kart.configure(border_color=R["vurgu"])
        self._meta_iste(yol)

    # ------------------------------------------------------ arka plan: süre + küçük resim
    def _meta_iste(self, yol):
        m = self.meta.get(yol)
        if m:
            self._meta_uygula(yol)
            return
        try:
            self._ex.submit(self._meta_oku, yol)
        except RuntimeError:
            pass

    def _meta_oku(self, yol):
        if not self._canli:
            return
        m = {"sure": None, "w": 0, "h": 0, "kucuk": None, "ses": None}
        try:
            import cv2
            cap = cv2.VideoCapture(str(yol))
            try:
                fps = cap.get(cv2.CAP_PROP_FPS) or 0
                n = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
                m["w"] = max(0, int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0))
                m["h"] = max(0, int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0))
                if fps > 0 and n > 0:
                    m["sure"] = n / fps
                if n > 2 and fps > 0:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, min(int(n) - 1, int(fps)))
                ok, kare = cap.read()
                if not ok:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                    ok, kare = cap.read()
                if ok and kare is not None:
                    m["kucuk"] = kare_boyutlandir(kare, 328, 185)
            finally:
                cap.release()
        except Exception:
            pass
        try:
            m["ses"] = sesm.ses_var(sesm.ffmpeg_onbellekli(), yol)
        except Exception:
            pass
        self.meta[yol] = m
        if self._canli:
            self.app.ui(lambda: self._meta_uygula(yol))

    def _meta_uygula(self, yol):
        if not self._canli:
            return
        kart = self.kartlar.get(yol)
        m = self.meta.get(yol)
        if kart is not None and m is not None:
            d = kart._kayit
            d["sure"].configure(text="Süre: %s   ·   %s%s" % (kl.sure_metni(m["sure"]), "🔊  ·   " if m.get("ses") else "",
                                                               boyut_metni(d["k"]["boyut"])))
            if m["kucuk"] is not None:
                img = Image.fromarray(m["kucuk"])
                img.thumbnail((d["tw"], d["th"]))
                d["foto"] = ImageTk.PhotoImage(img)
                d["cv"].delete("all")
                d["cv"].create_image(d["tw"] // 2, d["th"] // 2, image=d["foto"])
        if self.secim and self.secim[-1] == yol:
            self._panel_guncelle()

    # ---------------------------------------------------------------- seçim
    def _tikla(self, yol, ctrl):
        if ctrl:
            if yol in self.secim:
                self.secim.remove(yol)
            else:
                self.secim.append(yol)
        else:
            self.secim = [yol]
        for y, kart in self.kartlar.items():
            kart.configure(border_color=R["vurgu"] if y in self.secim else R["kenar"])
        self._panel_guncelle()

    def _cift(self, yol):
        self.secim = [yol]
        for y, kart in self.kartlar.items():
            kart.configure(border_color=R["vurgu"] if y == yol else R["kenar"])
        self._panel_guncelle()
        self._oynat()

    def _secili(self):
        return list(self.secim)

    def _panel_guncelle(self):
        sec = self.secim
        self.onizleme.delete("all")
        self._on_foto = None
        for d in self.p_deger.values():
            d.configure(text="—")
        if not sec:
            self.p_ad.configure(text="Kayıt seçin")
            self.p_alt.configure(text="Soldaki listeden bir kayda tıklayın; burada önizlemesi ve bilgileri görünür.")
            self.onizleme.create_text(164, 92, text="🎞", fill=R["kenar2"], font=("Segoe UI Emoji", 36))
            for b in (self.oynat_btn, self.goster_btn, self.sil_btn):
                b.configure(state="disabled")
            return
        for b in (self.oynat_btn, self.goster_btn, self.sil_btn):
            b.configure(state="normal")
        if len(sec) > 1:
            toplam = 0
            for y in sec:
                kay = next((k for k in self.tum if k["yol"] == y), None)
                toplam += kay["boyut"] if kay else 0
            self.p_ad.configure(text="%d kayıt seçili" % len(sec))
            self.p_alt.configure(text="Toplam %s. Birlikte silebilirsiniz; oynatma ilk seçili kayıttan başlar." % boyut_metni(toplam))
            self.onizleme.create_text(164, 92, text="%d" % len(sec), fill=R["mavi"], font=("Segoe UI", 44, "bold"))
            self.oynat_btn.configure(text="▶  İlkini Oynat")
            self.sil_btn.configure(text="🗑  Seçilenleri Sil")
            return
        self.oynat_btn.configure(text="▶  Oynat")
        self.sil_btn.configure(text="🗑  Sil")
        yol = sec[0]
        k = next((x for x in self.tum if x["yol"] == yol), None)
        if k is None:
            return
        m = self.meta.get(yol) or {}
        self.p_ad.configure(text=k["kamera"])
        self.p_alt.configure(text=k["ad"])
        self.p_deger["Tarih"].configure(text="%d %s %d" % (k["zaman"].day, kl.AYLAR[k["zaman"].month - 1], k["zaman"].year))
        self.p_deger["Saat"].configure(text=k["zaman"].strftime("%H:%M:%S"))
        self.p_deger["Süre"].configure(text=kl.sure_metni(m.get("sure")) if m else "…")
        self.p_deger["Çözünürlük"].configure(text="%d×%d" % (m["w"], m["h"]) if m.get("w") else "—")
        self.p_deger["Ses"].configure(text="Var" if m.get("ses") else ("Yok" if m.get("ses") is False else "—"))
        self.p_deger["Boyut"].configure(text=boyut_metni(k["boyut"]))
        if m.get("kucuk") is not None:
            img = Image.fromarray(m["kucuk"])
            img.thumbnail((328, 185))
            self._on_foto = ImageTk.PhotoImage(img)
            self.onizleme.create_image(164, 92, image=self._on_foto)
            self.onizleme.create_oval(144, 72, 184, 112, fill="#0A0E16", outline="")
            self.onizleme.create_text(165, 92, text="▶", fill="white", font=("Segoe UI", 14))
        else:
            self.onizleme.create_text(164, 92, text="Önizleme hazırlanıyor…" if not m else "Önizleme yok",
                                      fill=R["soluk"], font=("Segoe UI", 12))

    # --------------------------------------------------------------- eylemler
    def _oynat(self):
        s = self._secili()
        if not s:
            return
        yollar = [k["yol"] for k in self._gorunen] or [s[0]]
        indeks = yollar.index(s[0]) if s[0] in yollar else 0
        if s[0] not in yollar:
            yollar, indeks = [s[0]], 0
        self._oynaticiyi_kapat()
        self.oynatici = Oynatici(self.app, yollar, indeks, ust=self)

    def _oynaticiyi_kapat(self):
        o = getattr(self, "oynatici", None)
        if o is not None:
            try:
                o.kapat()
            except Exception:
                pass
        self.oynatici = None

    def _klasorde_goster(self):
        s = self._secili()
        if not s:
            return
        try:
            if sys.platform.startswith("win"):
                subprocess.Popen(["explorer", "/select,", str(s[0])])
            else:
                yolu_ac(s[0].parent)
        except Exception:
            yolu_ac(s[0].parent)

    def _sil(self):
        s = self._secili()
        if not s:
            return
        metin = ("“%s” kaydı silinsin mi?" % s[0].name) if len(s) == 1 else "%d kayıt silinsin mi?" % len(s)
        if not messagebox.askyesno(UYGULAMA_ADI, metin + "\n\nBu işlem geri alınamaz.", parent=self):
            return
        self._oynaticiyi_kapat()          # açık dosya Windows'ta silinmeyi engeller
        for p in s:
            try:
                p.unlink()
                self.meta.pop(p, None)
            except OSError as e:
                messagebox.showerror(UYGULAMA_ADI, "%s silinemedi: %s" % (p.name, e), parent=self)
        self.secim = []
        self._yukle()

    def _kapat(self):
        self._oynaticiyi_kapat()
        self._canli = False
        try:
            self._ex.shutdown(wait=False, cancel_futures=True)
        except Exception:
            pass
        self.destroy()


VARSAYILAN_UZAK = {"mod": "hizli", "kullanici": "kamera", "sifre": "", "port": 8787,
                   "token": "", "adres": "", "cloudflared_yol": "", "otomatik": False,
                   "kontrol": True, "kayit_izle": True}
UZAK_MODLAR = [("Tünelsiz (yerel)", "kapali"), ("Hızlı tünel", "hizli"), ("Kendi tünelim", "adli")]
CF_TURUNCU = "#F38020"


class UzakDialog(Diyalog):
    """Cloudflare Tünel ile uzaktan izleme: web görüntüleyici + cloudflared yönetimi."""

    ACIKLAMA = {
        "kapali": "Web görüntüleyici yalnızca bu bilgisayarda (127.0.0.1) açılır; internetten erişilemez.",
        "hizli": "Hesap gerekmez. Başlatınca cloudflared geçici bir https://….trycloudflare.com adresi verir; "
                 "adres her başlatmada değişir.",
        "adli": "Cloudflare Zero Trust → Networks → Tunnels'ta oluşturduğunuz tünelin token'ı gerekir. "
                "Tünelin ‘Public Hostname’ ayarında Service olarak HTTP ve http://127.0.0.1:%s girin.",
    }

    def __init__(self, app):
        super().__init__(app, "Uzaktan Erişim", 570, 800)
        u = app.uzak
        alt = ctk.CTkFrame(self, fg_color="transparent")
        alt.pack(fill="x", side="bottom", padx=24, pady=(6, 18))
        gv = ctk.CTkScrollableFrame(self, fg_color="transparent")
        gv.pack(fill="both", expand=True, padx=12, pady=(12, 0))
        self.gv = gv

        def etiket(metin, ust=12):
            self.etiket(gv, metin).pack(fill="x", padx=12, pady=(ust, 2))

        def alan(**kw):
            e = self.giris(gv, **kw)
            e.pack(fill="x", padx=12)
            return e

        ctk.CTkLabel(gv, text="Uzaktan Erişim", font=app.F(20, True), text_color=R["metin"],
                     anchor="w").pack(fill="x", padx=12, pady=(0, 4))
        ctk.CTkLabel(gv, text="Kameralarınızı telefondan veya başka bir yerden, Cloudflare Tüneli üzerinden "
                              "şifreli bir web sayfasıyla izleyin. Yalnızca izleme yapılır; PTZ ve kayıt "
                              "kontrolü yoktur.", font=app.F(12), text_color=R["soluk"], wraplength=490,
                     justify="left", anchor="w").pack(fill="x", padx=12)
        ctk.CTkLabel(gv, text="⚠  Tünel açıkken adresi bilen herkes giriş sayfasını görür. Uzun ve benzersiz bir "
                              "şifre seçin; kalıcı tünelde Cloudflare Access ile e-posta doğrulaması eklemeniz "
                              "önerilir.", font=app.F(12), text_color=R["sari"], wraplength=490,
                     justify="left", anchor="w").pack(fill="x", padx=12, pady=(8, 0))

        etiket("KULLANICI ADI (web sayfası girişi)", 16)
        self.e_kul = alan()
        self.e_kul.insert(0, u.get("kullanici", "kamera"))
        etiket("ŞİFRE (en az 8 karakter)")
        self.e_sif = alan(show="•", placeholder_text="(kayıtlı — değiştirmek için yazın)" if u.get("sifre") else "")
        etiket("YEREL PORT")
        self.e_port = alan()
        self.e_port.insert(0, str(u.get("port", 8787)))

        etiket("BAĞLANTI YÖNTEMİ", 16)
        self.seg = ctk.CTkSegmentedButton(gv, values=[m[0] for m in UZAK_MODLAR], command=self._mod_degisti,
                                          selected_color=CF_TURUNCU, selected_hover_color="#D96F14",
                                          unselected_color=R["kart"], font=app.F(13))
        self.seg.pack(fill="x", padx=12)
        self.seg.set([m[0] for m in UZAK_MODLAR if m[1] == u.get("mod")][0] if u.get("mod") in
                     [m[1] for m in UZAK_MODLAR] else UZAK_MODLAR[1][0])
        self.l_aciklama = ctk.CTkLabel(gv, text="", font=app.F(12), text_color=R["soluk"], wraplength=490,
                                       justify="left", anchor="w")
        self.l_aciklama.pack(fill="x", padx=12, pady=(8, 0))

        self.token_fr = ctk.CTkFrame(gv, fg_color="transparent")
        self.etiket(self.token_fr, "TÜNEL TOKEN'I (veya Cloudflare'in verdiği komutun tamamı)").pack(fill="x", pady=(10, 2))
        self.e_token = self.giris(self.token_fr, show="•",
                                  placeholder_text="(kayıtlı — değiştirmek için yapıştırın)" if u.get("token") else "eyJ…")
        self.e_token.pack(fill="x")
        self.etiket(self.token_fr, "GENEL ADRES (isteğe bağlı, ör. kamera.alanadim.com)").pack(fill="x", pady=(10, 2))
        self.e_adres = self.giris(self.token_fr)
        self.e_adres.pack(fill="x")
        self.e_adres.insert(0, u.get("adres", ""))

        etiket("CLOUDFLARED PROGRAMI", 16)
        cf = ctk.CTkFrame(gv, fg_color=R["kart"], corner_radius=12)
        cf.pack(fill="x", padx=12)
        self.l_cf = ctk.CTkLabel(cf, text="Denetleniyor…", font=app.F(12), text_color=R["soluk"], anchor="w",
                                 wraplength=300, justify="left")
        self.l_cf.pack(side="left", padx=12, pady=10)
        self.b_sec = self.dugme(cf, "Dosya seç", self._dosya_sec, genislik=90)
        self.b_sec.pack(side="right", padx=(0, 10), pady=8)
        self.b_indir = self.dugme(cf, "İndir", self._indir, genislik=70)
        self.b_indir.pack(side="right", padx=6, pady=8)

        def kutu(metin, deger, ust):
            k = ctk.CTkCheckBox(gv, text=metin, font=app.F(13), text_color=R["metin2"],
                                fg_color=CF_TURUNCU, hover_color="#D96F14")
            k.pack(anchor="w", padx=12, pady=(ust, 0))
            if deger:
                k.select()
            return k

        etiket("WEB SAYFASINDA İZİN VERİLENLER", 16)
        self.v_kontrol = kutu("Kamera kontrolü (PTZ) ve elle kayıt başlat/durdur", u.get("kontrol", True), 2)
        self.v_izle = kutu("Kayıtları listele, oynat ve indir", u.get("kayit_izle", True), 8)
        ctk.CTkLabel(gv, text="Kapalı bırakılan özellikler web sayfasında gizlenir ve sunucuda da reddedilir. "
                              "Değişiklik, tüneli Durdur/Başlat yapınca geçerli olur.", font=app.F(11),
                     text_color=R["soluk"], wraplength=490, justify="left", anchor="w").pack(fill="x", padx=12,
                                                                                              pady=(6, 0))
        self.v_otomatik = kutu("Uygulama açılınca otomatik başlat", u.get("otomatik"), 16)

        etiket("DURUM", 16)
        dr = ctk.CTkFrame(gv, fg_color=R["kart"], corner_radius=12, border_width=1, border_color=R["kenar"])
        dr.pack(fill="x", padx=12)
        self.l_web = ctk.CTkLabel(dr, text="", font=app.F(12), anchor="w", wraplength=480, justify="left")
        self.l_web.pack(fill="x", padx=14, pady=(10, 2))
        self.l_tunel = ctk.CTkLabel(dr, text="", font=app.F(12), anchor="w", wraplength=480, justify="left")
        self.l_tunel.pack(fill="x", padx=14, pady=2)
        self.l_url = ctk.CTkLabel(dr, text="—", font=app.F(14, True), text_color=R["mavi"], anchor="w",
                                  wraplength=480, justify="left")
        self.l_url.pack(fill="x", padx=14, pady=(6, 4))
        bt = ctk.CTkFrame(dr, fg_color="transparent")
        bt.pack(fill="x", padx=14, pady=(0, 12))
        self.dugme(bt, "Adresi kopyala", self._kopyala, genislik=130).pack(side="left")
        self.dugme(bt, "Tarayıcıda aç", self._ac, genislik=130).pack(side="left", padx=8)
        self.l_sonuc = ctk.CTkLabel(gv, text="", font=app.F(12), text_color=R["soluk"], anchor="w",
                                    wraplength=490, justify="left")
        self.l_sonuc.pack(fill="x", padx=12, pady=(10, 4))

        self.b_baslat = self.dugme(alt, "Başlat", self._baslat_durdur, vurgulu=True, genislik=110)
        self.b_baslat.pack(side="right")
        self.dugme(alt, "Kaydet", self._kaydet, genislik=90).pack(side="right", padx=8)
        self.dugme(alt, "Kapat", self.destroy, genislik=80).pack(side="left")

        self._mod_degisti(self.seg.get())
        self._cf_durum()
        self.durum_goster()
        self.after(800, self._tik)

    # ------------------------------------------------------------------ yardımcılar
    def _mod_anahtari(self):
        secim = self.seg.get()
        for ad, anahtar in UZAK_MODLAR:
            if ad == secim:
                return anahtar
        return "hizli"

    def _mod_degisti(self, _=None):
        mod = self._mod_anahtari()
        self.l_aciklama.configure(text=self.ACIKLAMA[mod].replace("%s", self.e_port.get().strip() or "8787"))
        if mod == "adli":
            self.token_fr.pack(fill="x", padx=12, after=self.l_aciklama)
        else:
            self.token_fr.pack_forget()

    def _hata(self, mesaj):
        self.l_sonuc.configure(text=mesaj, text_color="#FF6B7A")
        return False

    def _cf_durum(self):
        yol = cft.bul(self.app.uzak.get("cloudflared_yol", ""), ayar_klasoru())
        if not yol:
            self.l_cf.configure(text="✗ cloudflared bulunamadı. “İndir” ile otomatik kurabilirsiniz.",
                                text_color=R["sari"])
            return
        self.l_cf.configure(text="✓ cloudflared bulundu", text_color=R["yesil"])

        def is_():
            s = cft.surum(yol) or "sürüm okunamadı"
            self.app.ui(lambda: self._cf_yaz(s))

        threading.Thread(target=is_, daemon=True).start()

    def _cf_yaz(self, surum):
        if self.winfo_exists():
            self.l_cf.configure(text="✓ cloudflared hazır · %s" % surum, text_color=R["yesil"])

    def _dosya_sec(self):
        yol = filedialog.askopenfilename(parent=self, title="cloudflared programını seçin")
        if yol:
            self.app.uzak["cloudflared_yol"] = yol
            self.app.kaydet()
            self._cf_durum()

    def _indir(self):
        self.b_indir.configure(state="disabled")
        self.l_cf.configure(text="İndiriliyor… %0", text_color=R["sari"])

        def is_():
            try:
                cft.indir(cft.varsayilan_konum(ayar_klasoru()),
                          lambda o: self.app.ui(lambda: self._ilerleme(o)))
                self.app.ui(self._indirildi)
            except Exception as e:
                hata = str(e)
                self.app.ui(lambda: self._indirme_hatasi(hata))

        threading.Thread(target=is_, daemon=True).start()

    def _ilerleme(self, oran):
        if self.winfo_exists():
            self.l_cf.configure(text="İndiriliyor… %%%d" % int(oran * 100), text_color=R["sari"])

    def _indirildi(self):
        if self.winfo_exists():
            self.b_indir.configure(state="normal")
            self.app.gunluk_ekle("-", "BİLGİ", "cloudflared indirildi")
            self._cf_durum()

    def _indirme_hatasi(self, hata):
        if self.winfo_exists():
            self.b_indir.configure(state="normal")
            self.l_cf.configure(text="✗ İndirilemedi: %s" % hata[:140], text_color="#FF6B7A")

    def _uygula(self):
        a = self.app
        u = a.uzak
        kul = self.e_kul.get().strip()
        if not kul:
            return self._hata("Kullanıcı adı boş olamaz.")
        sifre = self.e_sif.get() or u.get("sifre", "")
        if len(sifre) < 8:
            return self._hata("Şifre en az 8 karakter olmalı.")
        try:
            port = int(self.e_port.get().strip())
        except ValueError:
            return self._hata("Port bir sayı olmalı.")
        if not 1024 <= port <= 65535:
            return self._hata("Port 1024–65535 arasında olmalı.")
        mod = self._mod_anahtari()
        token = u.get("token", "")
        adres = ""
        if mod == "adli":
            ham = self.e_token.get().strip()
            if ham:
                t = cft.token_ayikla(ham)
                if not cft.token_gecerli_gorunuyor(t):
                    return self._hata("Token geçersiz görünüyor. Cloudflare'in kurulum komutundaki ‘eyJ…’ ile "
                                      "başlayan değeri (ya da komutun tamamını) yapıştırın.")
                token = t
            elif not token:
                return self._hata("Tünel token'ını yapıştırın.")
            adres = self.e_adres.get().strip().replace("https://", "").replace("http://", "").strip("/ ")
        u.update(kullanici=kul, sifre=sifre, port=port, mod=mod, token=token, adres=adres,
                 otomatik=bool(self.v_otomatik.get()), kontrol=bool(self.v_kontrol.get()),
                 kayit_izle=bool(self.v_izle.get()))
        a.kaydet()
        self.e_sif.delete(0, "end")
        self.e_token.delete(0, "end")
        return True

    def _kaydet(self):
        if self._uygula():
            calisiyor = self.app.uzak_calisiyor()
            self.l_sonuc.configure(
                text="Ayarlar kaydedildi." + (" Değişikliklerin geçerli olması için Durdur, sonra Başlat'a basın."
                                              if calisiyor else ""), text_color=R["yesil"])

    def _baslat_durdur(self):
        a = self.app
        if a.uzak_calisiyor():
            self.b_baslat.configure(state="disabled", text="Durduruluyor…")

            def is_():
                a.uzak_durdur()
                a.ui(self.durum_goster)

            threading.Thread(target=is_, daemon=True).start()
            return
        if not self._uygula():
            return
        ok, mesaj = a.uzak_baslat()
        if ok:
            self.l_sonuc.configure(text="Başlatıldı.", text_color=R["yesil"])
        else:
            self._hata(mesaj)
        self.durum_goster()

    def _adres(self):
        a = self.app
        adres = a.uzak_adresi()
        if not adres and a.web is not None and a.web.calisiyor():
            adres = "http://127.0.0.1:%d" % a.web.port
        return adres

    def _kopyala(self):
        adres = self._adres()
        if adres:
            self.clipboard_clear()
            self.clipboard_append(adres)
            self.l_sonuc.configure(text="Adres panoya kopyalandı.", text_color=R["yesil"])

    def _ac(self):
        adres = self._adres()
        if adres:
            webbrowser.open(adres)

    def _tik(self):
        try:
            if not self.winfo_exists():
                return
            self.durum_goster()
            self.after(800, self._tik)
        except Exception:
            pass

    def durum_goster(self):
        a = self.app
        web = a.web is not None and a.web.calisiyor()
        if web:
            self.l_web.configure(text="● Web görüntüleyici açık · http://127.0.0.1:%d" % a.web.port,
                                 text_color=R["yesil"])
        else:
            self.l_web.configure(text="● Web görüntüleyici kapalı", text_color=R["soluk"])
        t = a.tunel
        if t.durum == "bagli":
            self.l_tunel.configure(text="● Cloudflare tüneli bağlı", text_color=CF_TURUNCU)
        elif t.durum == "baslatiliyor":
            self.l_tunel.configure(text="● Cloudflare tüneli bağlanıyor…", text_color=R["sari"])
        elif t.durum == "hata":
            self.l_tunel.configure(text="● Tünel hatası (yeniden deneniyor): %s" % (t.son_hata or "bilinmiyor"),
                                   text_color="#FF6B7A")
        else:
            self.l_tunel.configure(text="● Cloudflare tüneli kapalı", text_color=R["soluk"])
        adres = self._adres()
        self.l_url.configure(text=adres or "—")
        if a._uzak_durduruluyor:
            self.b_baslat.configure(state="disabled", text="Durduruluyor…")
        else:
            self.b_baslat.configure(state="normal", text="Durdur" if a.uzak_calisiyor() else "Başlat")


# ------------------------------------------------------------------ ana uygulama
class Uygulama(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.title(UYGULAMA_ADI)
        self.geometry("1500x900")
        self.minsize(1220, 800)
        self.configure(fg_color=R["bg"])
        try:
            self.olcek = float(self._get_window_scaling())
        except Exception:
            self.olcek = 1.0
        self._fontlar = {}
        self.ui_q = queue.Queue()
        self.log_q = queue.Queue()
        self.ptz_ex = ThreadPoolExecutor(max_workers=1)
        self._kapaniyor = False
        self._tam_ekran = False
        self.zoom = 1.0
        self.preset_harita = {}

        cfg = ayarlari_yukle()
        self.ayarlar = KayitAyarlari(**(cfg.get("kayit") or {}))
        self.hiz = float(cfg.get("hiz", 0.5))
        self.uzak = dict(VARSAYILAN_UZAK, **(cfg.get("uzak") or {}))
        self.bildirim_ayar = dict(bd.VARSAYILAN, **(cfg.get("bildirim") if isinstance(cfg.get("bildirim"), dict) else {}))
        self.bildirimci = bd.Bildirimci(lambda: self.bildirim_ayar, self.gunluk_ekle, self._acilir_goster,
                                        lambda: self.uzak_adresi() or None)
        self.ses_cikis = sesm.SesCikisi()
        self.ses_cikis.seviye = max(0.0, min(1.0, float((cfg.get("ses") or {}).get("seviye", 0.8))))
        self.ses_kid = None            # sesi dinlenen kamera
        self._ses_abone = None
        self.web = None
        self.tunel = cft.TunelYoneticisi(lambda sv, m: self.gunluk_ekle("-", sv, m))
        self.uzak_dlg = None
        self._uzak_kilit = threading.RLock()       # başlat/durdur işlemleri art arda ve çakışmadan çalışsın
        self._uzak_durduruluyor = False
        self.kamera_cfgleri = list(cfg.get("kameralar") or [])
        self.isciler = {}
        self.kartlar = {}
        self.secili = None
        # ana sayfa ızgarası
        ek = cfg.get("ekran") if isinstance(cfg.get("ekran"), dict) else {}
        self.adet = ed.duzen_sinirla(ek.get("adet", len(self.kamera_cfgleri) or 1), 1)
        self.atama = ed.atama_hazirla(ek.get("atama"))
        self.goster_liste = bool(ek.get("liste", True))
        self.goster_panel = bool(ek.get("panel", True))
        self.goster_gunluk = bool(ek.get("gunluk", False))
        self.odak = None               # tek karoya büyütülmüş karo numarası
        self.secili_slot = 0
        self._gor = {}                 # karo -> {"id", "foto", "anahtar"}
        self._butonlar = []            # çizimde oluşan tıklanabilir bölgeler
        self._dz_anahtar = None
        self._menu_adlari = {}

        self._arayuz_kur()
        for c in self.kamera_cfgleri:
            self._kamera_baslat(c)
        self.atama = ed.atama_duzenle(self.atama, list(self.kartlar), self.adet)
        if self.kamera_cfgleri:
            ilk = next((k for k in self.atama[:self.adet] if k), self.kamera_cfgleri[0]["id"])
            self.sec(ilk)
        else:
            self.after(600, self.kamera_ekle_ac)
        self._duzen_dugmeleri_guncelle()
        self._panelleri_uygula()

        self.protocol("WM_DELETE_WINDOW", self.kapat)
        self.bind("<Escape>", self._escape)
        self.bind("<F11>", lambda e: self.tam_ekran())
        self.gunluk_ekle("-", "BİLGİ", "Uygulama başlatıldı")
        self.after(60, self._ui_isle)
        self.after(40, self._video_guncelle)
        self.after(1000, self._kart_guncelle)
        self.after(500, self.disk_guncelle)
        self.after(1500, self._uzak_dongu)
        if self.uzak.get("otomatik") and self.uzak.get("sifre"):
            self.after(2500, self._uzak_otomatik)

    # ----------------------------------------------------------- küçük yardımcılar
    def sc(self, x):
        return int(x * self.olcek)

    def F(self, boyut, kalin=False, aile="Segoe UI"):
        anahtar = (boyut, kalin, aile)
        if anahtar not in self._fontlar:
            self._fontlar[anahtar] = ctk.CTkFont(family=aile, size=boyut, weight="bold" if kalin else "normal")
        return self._fontlar[anahtar]

    def ui(self, fn):
        """Başka iş parçacıklarından arayüze güvenle iş gönderir."""
        self.ui_q.put(fn)

    def secili_isci(self):
        return self.isciler.get(self.secili)

    def gunluk_ekle(self, kamera, seviye, mesaj):
        self.log_q.put((dt.datetime.now(), kamera, seviye, mesaj))

    def kaydet(self):
        ayarlari_kaydet({"kameralar": [self.kartlar[i].cfg for i in self.kartlar],
                         "kayit": self.ayarlar.sozluk(), "hiz": round(self.hiz, 2), "uzak": self.uzak,
                         "bildirim": self.bildirim_ayar, "ses": {"seviye": round(self.ses_cikis.seviye, 2)},
                         "ekran": {"adet": self.adet, "atama": list(self.atama), "liste": self.goster_liste,
                                   "panel": self.goster_panel, "gunluk": self.goster_gunluk}})

    # --------------------------------------------------------------------- arayüz
    def _arayuz_kur(self):
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        # yan çubuk
        self.yan = ctk.CTkFrame(self, width=76, fg_color=R["yan"], corner_radius=0)
        self.yan.grid(row=0, column=0, sticky="ns")
        self.yan.pack_propagate(False)
        logo = ctk.CTkFrame(self.yan, width=44, height=44, corner_radius=13, fg_color=R["vurgu"])
        logo.pack(pady=(16, 26))
        ctk.CTkLabel(logo, text="◉", font=self.F(22, True), text_color="white").place(relx=0.5, rely=0.5, anchor="center")
        self.bulut_btn = None
        for simge, komut, aktif in (("🎥", None, True), ("🔍", self.tara_ac, False),
                                    ("🎞", self.kayitlar_ac, False), ("☁", self.uzak_ac, False),
                                    ("⚙", self.ayar_ac, False), ("🔔", self.bildirim_ac, False),
                                    ("📁", self.klasoru_ac, False)):
            b = ctk.CTkButton(self.yan, text=simge, width=48, height=48, corner_radius=14,
                              fg_color=R["hover"] if aktif else "transparent", hover_color=R["hover"],
                              text_color=R["mavi"] if aktif else R["soluk"], font=self.F(20, aile="Segoe UI Emoji"),
                              command=komut)
            b.pack(pady=5)
            if simge == "☁":
                self.bulut_btn = b

        ana = ctk.CTkFrame(self, fg_color="transparent")
        ana.grid(row=0, column=1, sticky="nsew", padx=(18, 18), pady=(14, 10))
        ana.grid_columnconfigure(0, weight=1)
        ana.grid_rowconfigure(1, weight=1)

        # üst başlık
        self.baslik = ctk.CTkFrame(ana, fg_color="transparent")
        self.baslik.grid(row=0, column=0, sticky="ew", pady=(0, 14))
        sol = ctk.CTkFrame(self.baslik, fg_color="transparent")
        sol.pack(side="left")
        ctk.CTkLabel(sol, text=UYGULAMA_ADI, font=self.F(24, True), text_color=R["metin"], anchor="w").pack(anchor="w")
        self.alt_baslik = ctk.CTkLabel(sol, text="", font=self.F(12), text_color=R["soluk"], anchor="w")
        self.alt_baslik.pack(anchor="w")
        sag = ctk.CTkFrame(self.baslik, fg_color="transparent")
        sag.pack(side="right")
        for metin, komut, vurgulu in (("Kameraları Tara", self.tara_ac, False),
                                      ("+  Kamera Ekle", self.kamera_ekle_ac, True),
                                      ("Kayıtları İzle", self.kayitlar_ac, False),
                                      ("Kayıt Ayarları", self.ayar_ac, False),
                                      ("☁  Uzaktan Erişim", self.uzak_ac, False)):
            if vurgulu:
                b = ctk.CTkButton(sag, text=metin, command=komut, height=40, corner_radius=12,
                                  fg_color=R["vurgu"], hover_color=R["vurgu_h"], text_color="white",
                                  font=self.F(13, True))
            else:
                b = ctk.CTkButton(sag, text=metin, command=komut, height=40, corner_radius=12,
                                  fg_color=R["kart"], hover_color=R["hover"], border_width=1,
                                  border_color=R["kenar"], text_color=R["metin2"], font=self.F(13))
            b.pack(side="left", padx=(8, 0))

        govde = ctk.CTkFrame(ana, fg_color="transparent")
        govde.grid(row=1, column=0, sticky="nsew")
        govde.grid_columnconfigure(1, weight=1)
        govde.grid_rowconfigure(0, weight=1)

        # kamera listesi
        self.liste_cerceve = ctk.CTkFrame(govde, width=264, fg_color="transparent")
        self.liste_cerceve.grid(row=0, column=0, sticky="ns", padx=(0, 14))
        self.liste_cerceve.pack_propagate(False)
        self.liste_baslik = ctk.CTkLabel(self.liste_cerceve, text="KAMERALAR (0)", font=self.F(12, True),
                                         text_color=R["soluk"], anchor="w")
        self.liste_baslik.pack(fill="x", padx=4, pady=(0, 8))
        self.liste = ctk.CTkScrollableFrame(self.liste_cerceve, fg_color="transparent", width=230)
        self.liste.pack(fill="both", expand=True)
        ctk.CTkButton(self.liste_cerceve, text="+  Yeni kamera ekle", height=44, corner_radius=16,
                      fg_color="transparent", hover_color=R["hover"], border_width=1, border_color=R["kenar2"],
                      text_color=R["soluk"], font=self.F(13), command=self.kamera_ekle_ac).pack(fill="x", pady=(8, 0))

        # orta: araç çubuğu + kamera ızgarası + günlük
        orta = ctk.CTkFrame(govde, fg_color="transparent")
        orta.grid(row=0, column=1, sticky="nsew")
        orta.grid_columnconfigure(0, weight=1)
        orta.grid_rowconfigure(1, weight=1)

        self.arac = ctk.CTkFrame(orta, fg_color="transparent")
        self.arac.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        ctk.CTkLabel(self.arac, text="GÖRÜNÜM", font=self.F(11, True), text_color=R["soluk"]).pack(side="left", padx=(4, 10))
        self.duzen_dugmeleri = {}
        for n in range(1, ed.MAX_KARO + 1):
            d = DuzenDugmesi(self.arac, self, n)
            d.pack(side="left", padx=(0, 6))
            self.duzen_dugmeleri[n] = d
        self.tam_btn = ctk.CTkButton(self.arac, text="⛶  Tam Ekran", width=118, height=34, corner_radius=10,
                                     fg_color=R["kart"], hover_color=R["hover"], border_width=1,
                                     border_color=R["kenar"], text_color=R["metin2"], font=self.F(12),
                                     command=self.tam_ekran)
        self.tam_btn.pack(side="right")
        self.panel_btn = ctk.CTkButton(self.arac, text="Kontrol Paneli", width=118, height=34, corner_radius=10,
                                       fg_color=R["kart"], hover_color=R["hover"], border_width=1,
                                       border_color=R["kenar"], text_color=R["metin2"], font=self.F(12),
                                       command=self.panel_degistir)
        self.panel_btn.pack(side="right", padx=(0, 8))
        self.liste_btn = ctk.CTkButton(self.arac, text="Kamera Listesi", width=118, height=34, corner_radius=10,
                                       fg_color=R["kart"], hover_color=R["hover"], border_width=1,
                                       border_color=R["kenar"], text_color=R["metin2"], font=self.F(12),
                                       command=self.liste_degistir)
        self.liste_btn.pack(side="right", padx=(0, 8))

        video_cerceve = ctk.CTkFrame(orta, fg_color=R["bg"], corner_radius=0)
        video_cerceve.grid(row=1, column=0, sticky="nsew")
        self.video = tk.Canvas(video_cerceve, bg=R["bg"], highlightthickness=0)
        self.video.pack(fill="both", expand=True)
        self.video.bind("<Button-1>", self._tikla)
        self.video.bind("<Double-Button-1>", self._cift_tikla)

        self.log_cerceve = ctk.CTkFrame(orta, height=210, fg_color=R["panel"], corner_radius=18,
                                        border_width=1, border_color=R["kenar"])
        self.log_cerceve.grid(row=2, column=0, sticky="ew", pady=(12, 0))
        self.log_cerceve.pack_propagate(False)
        ctk.CTkLabel(self.log_cerceve, text="Günlük", font=self.F(15, True), text_color=R["metin"],
                     anchor="w").pack(fill="x", padx=18, pady=(12, 2))
        self.log_text = ctk.CTkTextbox(self.log_cerceve, fg_color=R["panel"], text_color=R["metin2"],
                                       font=self.F(12, aile="Consolas"), wrap="none", border_width=0)
        self.log_text.pack(fill="both", expand=True, padx=12, pady=(0, 10))
        self.log_text.tag_config("zaman", foreground=R["soluk"])
        self.log_text.tag_config("mesaj", foreground=R["metin2"])
        for sv, renk in SEVIYE_RENK.items():
            self.log_text.tag_config("sv_" + sv, foreground=renk)
        self.log_text.configure(state="disabled")

        # sağ: PTZ + durum + hızlı işlemler
        self.ptz_cerceve = ctk.CTkFrame(govde, width=372, fg_color="transparent")
        self.ptz_cerceve.grid(row=0, column=2, sticky="ns", padx=(14, 0))
        self.ptz_cerceve.pack_propagate(False)
        kaydir = ctk.CTkScrollableFrame(self.ptz_cerceve, fg_color="transparent", width=340)
        kaydir.pack(fill="both", expand=True)
        self._ptz_kur(kaydir)
        self.mod_etiketi_guncelle()

        # alt durum çubuğu
        self.durum_cubugu = ctk.CTkFrame(ana, height=34, fg_color="transparent")
        self.durum_cubugu.grid(row=2, column=0, sticky="ew", pady=(10, 0))
        self.sistem_lbl = ctk.CTkLabel(self.durum_cubugu, text="● Kamera Yok", font=self.F(12, True),
                                       text_color=R["sari"])
        self.sistem_lbl.pack(side="left", padx=(4, 18))
        self.guncelleme_lbl = ctk.CTkLabel(self.durum_cubugu, text="", font=self.F(12), text_color=R["soluk"])
        self.guncelleme_lbl.pack(side="left")
        self.gunluk_btn = ctk.CTkButton(self.durum_cubugu, text="▤  Günlük", width=100, height=28, corner_radius=8,
                                        fg_color="transparent", hover_color=R["hover"], text_color=R["metin2"],
                                        font=self.F(12), command=self.gunluk_degistir)
        self.gunluk_btn.pack(side="right")
        self.saat_lbl = ctk.CTkLabel(self.durum_cubugu, text="", font=self.F(12), text_color=R["metin2"])
        self.saat_lbl.pack(side="right", padx=(0, 14))
        self.durum_karti_guncelle()

    def _kart(self, ust, baslik, simge):
        k = ctk.CTkFrame(ust, fg_color=R["panel"], corner_radius=18, border_width=1, border_color=R["kenar"])
        k.pack(fill="x", pady=(0, 12))
        ctk.CTkLabel(k, text="%s  %s" % (simge, baslik), font=self.F(16, True), text_color=R["metin"],
                     anchor="w").pack(fill="x", padx=20, pady=(16, 2))
        return k

    def _ptz_kur(self, ust):
        p = self._kart(ust, "PTZ Kontrol", "✥")
        self.ptz_alt = ctk.CTkLabel(p, text="Kamera seçin", font=self.F(12), text_color=R["soluk"],
                                    anchor="w", wraplength=280, justify="left")
        self.ptz_alt.pack(fill="x", padx=20)
        ctk.CTkLabel(p, text="KAMERA SEÇİN", font=self.F(11, True), text_color=R["soluk"],
                     anchor="w").pack(fill="x", padx=20, pady=(10, 4))
        self.kamera_menu = ctk.CTkOptionMenu(p, values=["(kamera yok)"], height=36, corner_radius=10,
                                             fg_color=R["kart"], button_color=R["kenar2"],
                                             button_hover_color=R["hover"], dropdown_fg_color=R["kart"],
                                             font=self.F(13), dynamic_resizing=False,
                                             command=self._kamera_menuden)
        self.kamera_menu.pack(fill="x", padx=20)
        self.kamera_menu.set("(kamera yok)")

        self.joy = Joystik(p, self.sc(190), self._ptz_hareket, self._ptz_dur, self._ptz_ana)
        self.joy.pack(pady=(12, 6))

        ctk.CTkLabel(p, text="DİJİTAL ZOOM", font=self.F(11, True), text_color=R["soluk"],
                     anchor="w").pack(fill="x", padx=20, pady=(4, 4))
        zs = ctk.CTkFrame(p, fg_color="transparent")
        zs.pack(fill="x", padx=20)
        zs.grid_columnconfigure((0, 2), weight=1)
        stil = dict(height=38, corner_radius=12, fg_color=R["kart"], hover_color=R["hover"], border_width=1,
                    border_color=R["kenar"], text_color=R["metin2"], font=self.F(13))
        ctk.CTkButton(zs, text="＋  Yakın", command=lambda: self.zoom_degistir(0.5), **stil).grid(row=0, column=0, sticky="ew")
        self.zoom_lbl = ctk.CTkLabel(zs, text="1.0×", font=self.F(13, True), text_color=R["mavi"], width=56)
        self.zoom_lbl.grid(row=0, column=1, padx=6)
        ctk.CTkButton(zs, text="－  Uzak", command=lambda: self.zoom_degistir(-0.5), **stil).grid(row=0, column=2, sticky="ew")

        hs = ctk.CTkFrame(p, fg_color="transparent")
        hs.pack(fill="x", padx=20, pady=(12, 0))
        ctk.CTkLabel(hs, text="HIZ", font=self.F(11, True), text_color=R["soluk"]).pack(side="left")
        self.hiz_lbl = ctk.CTkLabel(hs, text="%.1f" % self.hiz, font=self.F(12, True), text_color=R["mavi"])
        self.hiz_lbl.pack(side="right")
        self.hiz_slider = ctk.CTkSlider(p, from_=0.1, to=1.0, number_of_steps=9, progress_color=R["vurgu"],
                                        button_color="white", button_hover_color="#DDE6FF", fg_color=R["kenar"],
                                        command=self._hiz_degisti)
        self.hiz_slider.pack(fill="x", padx=20, pady=(6, 0))
        self.hiz_slider.set(self.hiz)

        ctk.CTkLabel(p, text="KONUM HAFIZASI", font=self.F(11, True), text_color=R["soluk"],
                     anchor="w").pack(fill="x", padx=20, pady=(14, 4))
        self.preset_menu = ctk.CTkOptionMenu(p, values=["(preset yok)"], height=36, corner_radius=10,
                                             fg_color=R["kart"], button_color=R["kenar2"],
                                             button_hover_color=R["hover"], dropdown_fg_color=R["kart"],
                                             font=self.F(13), dynamic_resizing=False)
        self.preset_menu.pack(fill="x", padx=20)
        self.preset_menu.set("(preset yok)")
        ps = ctk.CTkFrame(p, fg_color="transparent")
        ps.pack(fill="x", padx=20, pady=(10, 18))
        ps.grid_columnconfigure((0, 1, 2), weight=1)
        kucuk = dict(height=36, corner_radius=12, fg_color=R["kart"], hover_color=R["hover"], border_width=1,
                     border_color=R["kenar"], text_color=R["metin2"], font=self.F(12))
        ctk.CTkButton(ps, text="Yenile", command=self.presetleri_yenile, **kucuk).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        ctk.CTkButton(ps, text="Git", command=self.preset_git, height=36, corner_radius=12, fg_color=R["vurgu"],
                      hover_color=R["vurgu_h"], text_color="white", font=self.F(12, True)).grid(row=0, column=1, sticky="ew", padx=4)
        ctk.CTkButton(ps, text="Kaydet", command=self.preset_kaydet, **kucuk).grid(row=0, column=2, sticky="ew", padx=(4, 0))

        # kamera durumu
        d = self._kart(ust, "Kamera Durumu", "◔")
        satirlar = ctk.CTkFrame(d, fg_color="transparent")
        satirlar.pack(fill="x", padx=20, pady=(8, 0))
        satirlar.grid_columnconfigure(1, weight=1)
        for i, ad in enumerate(("Aktif Kamera", "Kayıt Durumu", "Mod")):
            ctk.CTkLabel(satirlar, text=ad, font=self.F(12), text_color=R["soluk"], anchor="w").grid(
                row=i, column=0, sticky="w", pady=3)
        self.aktif_lbl = ctk.CTkLabel(satirlar, text="0 / 0", font=self.F(12, True), text_color=R["metin2"], anchor="e")
        self.aktif_lbl.grid(row=0, column=1, sticky="e")
        self.kayit_lbl = ctk.CTkLabel(satirlar, text="—", font=self.F(12, True), text_color=R["soluk"], anchor="e")
        self.kayit_lbl.grid(row=1, column=1, sticky="e")
        self.mod_lbl = ctk.CTkLabel(satirlar, text="", font=self.F(12, True), text_color=R["metin2"], anchor="e")
        self.mod_lbl.grid(row=2, column=1, sticky="e")
        dsat = ctk.CTkFrame(d, fg_color="transparent")
        dsat.pack(fill="x", padx=20, pady=(6, 2))
        ctk.CTkLabel(dsat, text="Depolama", font=self.F(12), text_color=R["soluk"]).pack(side="left")
        self.disk_lbl = ctk.CTkLabel(dsat, text="", font=self.F(12, True), text_color=R["metin2"])
        self.disk_lbl.pack(side="right")
        self.disk_bar = ctk.CTkProgressBar(d, height=8, progress_color=R["yesil"], fg_color=R["kenar"])
        self.disk_bar.pack(fill="x", padx=20, pady=(0, 18))
        self.disk_bar.set(0)

        # ses
        se = self._kart(ust, "Ses", "🔊")
        self.ses_dinlenen_lbl = ctk.CTkLabel(se, text="Dinlenen: —", font=self.F(12), text_color=R["soluk"], anchor="w")
        self.ses_dinlenen_lbl.pack(fill="x", padx=20, pady=(4, 0))
        self.ses_btn = ctk.CTkButton(se, text="🔊  Sesi Dinle", height=38, corner_radius=10, fg_color=R["kart"],
                                     hover_color=R["hover"], text_color=R["metin2"], font=self.F(12), anchor="w",
                                     command=lambda: self.ses_degistir())
        self.ses_btn.pack(fill="x", padx=20, pady=(8, 0))
        sv = ctk.CTkFrame(se, fg_color="transparent")
        sv.pack(fill="x", padx=20, pady=(10, 0))
        ctk.CTkLabel(sv, text="SES SEVİYESİ", font=self.F(11, True), text_color=R["soluk"]).pack(side="left")
        self.ses_lbl_seviye = ctk.CTkLabel(sv, text="%d%%" % round(self.ses_cikis.seviye * 100), font=self.F(12, True),
                                           text_color=R["mavi"])
        self.ses_lbl_seviye.pack(side="right")
        self.ses_slider = ctk.CTkSlider(se, from_=0, to=1, number_of_steps=20, progress_color=R["vurgu"],
                                        button_color="white", button_hover_color="#DDE6FF", fg_color=R["kenar"],
                                        command=self._ses_seviye)
        self.ses_slider.pack(fill="x", padx=20, pady=(6, 0))
        self.ses_slider.set(self.ses_cikis.seviye)
        self.ses_mesaj_lbl = ctk.CTkLabel(se, text="", font=self.F(11), text_color=R["soluk"], anchor="w",
                                          wraplength=290, justify="left")
        self.ses_mesaj_lbl.pack(fill="x", padx=20, pady=(6, 14))

        # hızlı işlemler
        h = self._kart(ust, "Hızlı İşlemler", "⚡")
        hs2 = dict(height=38, corner_radius=10, fg_color=R["kart"], hover_color=R["hover"], text_color=R["metin2"],
                   font=self.F(12), anchor="w")
        for metin, komut in (("📷  Ekran Görüntüsü Al", self.fotograf_cek),
                             ("⏺  Kayıt Başlat / Durdur", self.manuel_kayit_degistir),
                             ("🎞  Kayıtları İzle", self.kayitlar_ac),
                             ("⚙  Kayıt Ayarları", self.ayar_ac)):
            ctk.CTkButton(h, text=metin, command=komut, **hs2).pack(fill="x", padx=20, pady=(6, 0))
        ctk.CTkFrame(h, height=14, fg_color="transparent").pack()

    # ---------------------------------------------------------- döngüler
    def _ui_isle(self):
        if self._kapaniyor:
            return
        for _ in range(100):
            try:
                fn = self.ui_q.get_nowait()
            except queue.Empty:
                break
            try:
                fn()
            except Exception:
                traceback.print_exc()
        satirlar = []
        for _ in range(200):
            try:
                satirlar.append(self.log_q.get_nowait())
            except queue.Empty:
                break
        if satirlar:
            self._gunluk_yaz(satirlar)
        self.after(80, self._ui_isle)

    def _gunluk_yaz(self, satirlar):
        t = self.log_text
        t.configure(state="normal")
        dosya_satirlari = []
        for zaman, kamera, seviye, mesaj in satirlar:
            on = "" if kamera == "-" else "[%s] " % kamera
            t.insert("end", zaman.strftime("%H:%M:%S") + "  ", "zaman")
            t.insert("end", "%-6s " % seviye, "sv_" + seviye if seviye in SEVIYE_RENK else "mesaj")
            t.insert("end", on + mesaj + "\n", "mesaj")
            dosya_satirlari.append("%s  %-6s %s%s\n" % (zaman.strftime("%Y-%m-%d %H:%M:%S"), seviye, on, mesaj))
        try:
            if int(t.index("end-1c").split(".")[0]) > 600:
                t.delete("1.0", "151.0")
        except Exception:
            pass
        t.see("end")
        t.configure(state="disabled")
        try:
            with open(ayar_klasoru() / "gunluk.txt", "a", encoding="utf-8") as f:
                f.writelines(dosya_satirlari)
        except Exception:
            pass

    def _kart_guncelle(self):
        if self._kapaniyor:
            return
        try:
            for kid, kart in self.kartlar.items():
                isci = self.isciler.get(kid)
                if isci:
                    kart.guncelle(isci)
            self.durum_karti_guncelle()
            self._ses_kontrol()
        except Exception:
            traceback.print_exc()
        self.after(1000, self._kart_guncelle)

    def _ses_kontrol(self):
        """Dinlenen kameranın ses akışı yoksa (mikrofon kapalı) dinlemeyi bırakır ve bildirir."""
        ab = self._ses_abone
        if ab is not None and ab[0].ses_yok:
            self.ses_durdur()
            self._ses_mesaj("Bu kamerada ses akışı yok (Tapo uygulamasından mikrofonu açın).", True)

    def durum_karti_guncelle(self):
        toplam = len(self.isciler)
        cevrimici = sum(1 for i in self.isciler.values() if i.durum == "cevrimici")
        kayitta = sum(1 for i in self.isciler.values() if i.kayit_var)
        self.aktif_lbl.configure(text="%d / %d" % (cevrimici, toplam))
        if kayitta:
            self.kayit_lbl.configure(text="● Kayıt Yapılıyor (%d)" % kayitta, text_color=R["yesil"])
        elif self.ayarlar.mod == "kapali":
            self.kayit_lbl.configure(text="Kapalı", text_color=R["soluk"])
        else:
            self.kayit_lbl.configure(text="● Beklemede", text_color=R["sari"])
        if not toplam:
            self.sistem_lbl.configure(text="● Kamera Yok", text_color=R["sari"])
        elif cevrimici:
            self.sistem_lbl.configure(text="● Sistem Aktif", text_color=R["yesil"])
        else:
            self.sistem_lbl.configure(text="● Bağlantı Yok", text_color=R["kirmizi"])
        simdi = dt.datetime.now()
        self.guncelleme_lbl.configure(text="Son güncelleme: " + simdi.strftime("%d.%m.%Y %H:%M:%S"))
        self.saat_lbl.configure(text=simdi.strftime("%H:%M  %d.%m.%Y"))

    def _video_guncelle(self):
        if self._kapaniyor:
            return
        try:
            self._video_ciz()
        except Exception:
            traceback.print_exc()
        self.after(40, self._video_guncelle)

    def _chip(self, x, y, metin, bg, fg, noktali=None, boy=28, punto=9):
        c = self.video
        ox = x + 10
        if noktali:
            c.create_oval(ox, y + boy // 2 - 4, ox + 8, y + boy // 2 + 4, fill=noktali, outline="", tags="ov")
            ox += 13
        t = c.create_text(ox, y + boy // 2, text=metin, fill=fg, anchor="w", font=("Segoe UI", punto, "bold"), tags="ov")
        x2 = c.bbox(t)[2]
        r = yuvarlak_dikdortgen(c, x, y, x2 + 10, y + boy, boy // 2, fill=bg, outline="", tags="ov")
        c.tag_lower(r, t)
        return x2 + 16

    def _karo_dikdortgenleri(self, cw, ch):
        """Görünen karoların piksel dikdörtgenleri: [(karo_no, x0, y0, x1, y1)]."""
        if self.odak is not None:
            return [(self.odak, 0, 0, cw, ch)]
        tanim = ed.duzen_tanimi(self.adet, cw / float(ch))
        bosluk = 10
        satir, sutun = tanim["satir"], tanim["sutun"]

        def kenarlar(agirlik, toplam):
            net = toplam - bosluk * (len(agirlik) - 1)
            t, e, x = float(sum(agirlik)), [], 0.0
            for w in agirlik:
                e.append((x, x + net * w / t))
                x += net * w / t + bosluk
            return e

        ys, xs = kenarlar(satir, ch), kenarlar(sutun, cw)
        sonuc = []
        for k, (r, c, rs, cs) in enumerate(tanim["karolar"]):
            sonuc.append((k, int(xs[c][0]), int(ys[r][0]), int(xs[c + cs - 1][1]), int(ys[r + rs - 1][1])))
        return sonuc

    def _video_ciz(self):
        c = self.video
        cw, ch = c.winfo_width(), c.winfo_height()
        if cw < 120 or ch < 80:
            return
        c.delete("ov")
        self._butonlar = []
        dikdortgenler = self._karo_dikdortgenleri(cw, ch)
        anahtar = (cw, ch, self.adet, self.odak)
        if anahtar != self._dz_anahtar:
            self._dz_anahtar = anahtar
            c.delete("bg")
            for _, x0, y0, x1, y1 in dikdortgenler:
                yuvarlak_dikdortgen(c, x0, y0, x1, y1, 16, fill=R["video"], outline="", tags="bg")
            self._goruntuleri_temizle()
        for s in list(self._gor):
            if s not in [d[0] for d in dikdortgenler]:
                self._goruntu_sil(s)
        for karo, x0, y0, x1, y1 in dikdortgenler:
            self._karo_ciz(karo, x0, y0, x1, y1)
        c.tag_lower("img")
        c.tag_lower("bg")
        c.tag_raise("ov")

    def _karo_ciz(self, karo, x0, y0, x1, y1):
        c = self.video
        tw, th = x1 - x0, y1 - y0
        cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
        kid = self.atama[karo]
        isci = self.isciler.get(kid) if kid else None
        if isci is None:
            self._goruntu_sil(karo)
            yuvarlak_dikdortgen(c, x0 + 1, y0 + 1, x1 - 1, y1 - 1, 16, fill="", outline=R["kenar2"], width=2,
                                dash=(5, 5), tags="ov")
            c.create_text(cx, cy - 12, text="＋", fill=R["soluk"], font=("Segoe UI", 26), tags="ov")
            c.create_text(cx, cy + 22, text="Kamera ata" if self.kartlar else "Kamera ekle", fill=R["soluk"],
                          font=("Segoe UI", 11), tags="ov")
            self._butonlar.append((x0, y0, x1, y1, karo, "ata"))
            return
        secili = kid == self.secili
        kucuk = tw < 340 or th < 200
        zoom = self.zoom if secili else 1.0

        # görüntü
        kare = isci.son_kare
        if kare is not None:
            aw, ah = max(tw - 4, 16), max(th - 4, 16)
            anahtar = (kid, isci.kare_no, aw, ah, zoom)
            g = self._gor.get(karo)
            if g is None or g["anahtar"] != anahtar:
                foto = ImageTk.PhotoImage(Image.fromarray(kare_boyutlandir(kare, aw, ah, zoom)))
                if g is None:
                    g = {"id": c.create_image(cx, cy, image=foto, tags="img")}
                    self._gor[karo] = g
                else:
                    c.itemconfigure(g["id"], image=foto)
                    c.coords(g["id"], cx, cy)
                g["foto"], g["anahtar"] = foto, anahtar
        else:
            self._goruntu_sil(karo)

        # çerçeve
        yuvarlak_dikdortgen(c, x0 + 1, y0 + 1, x1 - 1, y1 - 1, 16, fill="", width=2 if secili else 1,
                            outline=R["vurgu"] if secili else R["kenar"], tags="ov")
        self._butonlar.append((x0, y0, x1, y1, karo, "sec"))

        # üst bant: ad + durum
        hh = self.sc(30 if kucuk else 36)
        yuvarlak_dikdortgen(c, x0 + 6, y0 + 6, x1 - 6, y0 + 6 + hh, 12, fill="#0A0E16", outline="", tags="ov")
        canli = isci.durum == "cevrimici"
        sag = []
        if canli:
            sag.append(("CANLI", R["yesil"]))
        elif isci.durum == "baglaniyor":
            sag.append(("BAĞLANIYOR", R["sari"]))
        else:
            sag.append(("ÇEVRİMDIŞI", R["kirmizi"]))
        if isci.kayit_var:
            sag.append(("KAYIT", R["kirmizi"]))
        sag_genislik = sum(len(m) * 7 + 24 for m, _ in sag) + (0 if kucuk or not isci.cozunurluk[0] else 86)
        ad = isci.ad
        sig = max(4, int((tw - sag_genislik - 40) / 7.5))
        if len(ad) > sig:
            ad = ad[:max(1, sig - 1)] + "…"
        c.create_text(x0 + 18, y0 + 6 + hh // 2, text=ad, fill="white", anchor="w",
                      font=("Segoe UI", 10 if kucuk else 11, "bold"), tags="ov")
        bx = x1 - 14
        if not kucuk and isci.cozunurluk[0]:
            c.create_text(bx, y0 + 6 + hh // 2, text="%d×%d" % isci.cozunurluk, fill=R["metin2"], anchor="e",
                          font=("Segoe UI", 9), tags="ov")
            bx -= 80
        for metin, renk in reversed(sag):
            c.create_oval(bx - len(metin) * 7 - 12, y0 + 6 + hh // 2 - 4, bx - len(metin) * 7 - 4, y0 + 6 + hh // 2 + 4,
                          fill=renk, outline="", tags="ov")
            c.create_text(bx, y0 + 6 + hh // 2, text=metin, fill=renk, anchor="e", font=("Segoe UI", 8, "bold"), tags="ov")
            bx -= len(metin) * 7 + 24

        # rozetler (algılama / zoom)
        ry = y0 + hh + 14
        rx = x0 + 14
        if isci.olay_var():
            rx = self._chip(rx, ry, "Kişi algılandı" if self.ayarlar.mod == "kisi" else "Hareket algılandı",
                            "#0A0E16", "#CFEFE2", noktali=R["yesil"], boy=26)
        if zoom > 1.0:
            rx = self._chip(rx, ry, "Zoom %.1f×" % zoom, "#0A0E16", R["mavi"], boy=26)

        # durum mesajı
        if not canli:
            mesaj = "Bağlanılıyor…" if isci.durum == "baglaniyor" else "Bağlantı yok — yeniden bağlanılıyor"
            t = c.create_text(cx, cy, text=mesaj, fill=R["metin2"], font=("Segoe UI", 11 if kucuk else 13, "bold"),
                              width=max(80, tw - 40), tags="ov")
            bb = c.bbox(t)
            r = yuvarlak_dikdortgen(c, bb[0] - 16, bb[1] - 10, bb[2] + 16, bb[3] + 10, 16, fill="#0A0E16",
                                    outline="", tags="ov")
            c.tag_lower(r, t)

        # alt bant: zaman + düğmeler
        if th >= 150:
            bh = self.sc(34)
            by1 = y1 - 8
            by0 = by1 - bh
            yuvarlak_dikdortgen(c, x0 + 8, by0, x1 - 8, by1, 12, fill="#0A0E16", outline="", tags="ov")
            ym = (by0 + by1) // 2
            zaman = dt.datetime.now().strftime("%H:%M:%S" if tw < 360 else "%d.%m.%Y %H:%M:%S")
            c.create_text(x0 + 20, ym, text=zaman, fill="#E6EAF2", anchor="w", font=("Segoe UI", 10), tags="ov")
            r = self.sc(12)
            bx = x1 - 20 - r
            dugmeler = [("menu", "⚙"), ("odak", "⤡" if self.odak is not None else "⛶")]
            if tw >= 260:
                dugmeler += [("foto", "📷"), ("kayit", "⏺"), ("ses", "🔊" if self.ses_kid == kid else "🔈")]
            for eylem, simge in reversed(dugmeler):
                aktif = eylem == "kayit" and isci.manuel_kayit
                dinliyor = eylem == "ses" and self.ses_kid == kid
                c.create_oval(bx - r, ym - r, bx + r, ym + r,
                              fill=R["kirmizi"] if aktif else ("#1F7A55" if dinliyor else "#1B2333"),
                              outline="", tags="ov")
                c.create_text(bx, ym, text=simge, fill="white", font=("Segoe UI Emoji", 10), tags="ov")
                self._butonlar.append((bx - r, ym - r, bx + r, ym + r, karo, eylem))
                bx -= 2 * r + 8
        else:
            self._butonlar.append((x1 - 40, y0 + 6, x1 - 6, y0 + 6 + hh, karo, "menu"))

    def _goruntu_sil(self, karo):
        g = self._gor.pop(karo, None)
        if g:
            self.video.delete(g["id"])

    def _goruntuleri_temizle(self):
        for s in list(self._gor):
            self._goruntu_sil(s)

    # --------------------------------------------------------------- ızgara etkileşimi
    def _bolge(self, e):
        for x0, y0, x1, y1, karo, eylem in reversed(self._butonlar):
            if x0 <= e.x <= x1 and y0 <= e.y <= y1:
                return karo, eylem
        return None, None

    def _tikla(self, e):
        karo, eylem = self._bolge(e)
        if karo is not None:
            self.karo_eylemi(karo, eylem, e)

    def _cift_tikla(self, e):
        karo, eylem = self._bolge(e)
        if eylem == "sec" and self.atama[karo]:
            self.odak_degistir(karo)

    def karo_eylemi(self, karo, eylem, e=None):
        kid = self.atama[karo]
        if eylem in ("ata", "menu"):
            self._atama_menusu(karo, e)
        elif kid is None:
            return
        elif eylem == "sec":
            self.sec(kid, karo)
        elif eylem == "odak":
            self.odak_degistir(karo)
        elif eylem == "foto":
            self.fotograf_cek(kid)
        elif eylem == "kayit":
            self.manuel_kayit_degistir(kid)
        elif eylem == "ses":
            self.ses_degistir(kid)

    def _atama_menusu(self, karo, e):
        menu = tk.Menu(self, tearoff=0, bg=R["kart"], fg=R["metin"], activebackground=R["vurgu"],
                       activeforeground="white", bd=0)
        if not self.kartlar:
            menu.add_command(label="Kamera ekle…", command=self.kamera_ekle_ac)
        for kid, kart in self.kartlar.items():
            gor = kid in self.atama[:self.adet]
            menu.add_command(label="%s%s" % ("✓ " if self.atama[karo] == kid else ("● " if gor else "    "), kart.cfg["ad"]),
                             command=lambda k=kid: self.karoya_ata(karo, k))
        if self.atama[karo]:
            menu.add_separator()
            menu.add_command(label="Düzenle…", command=lambda: self.kamera_duzenle(self.atama[karo]))
            menu.add_command(label="Karoyu boşalt", command=lambda: self.karoya_ata(karo, None))
        try:
            menu.tk_popup(e.x_root if e else self.winfo_rootx() + 200, e.y_root if e else self.winfo_rooty() + 200)
        finally:
            try:
                menu.grab_release()
            except Exception:
                pass

    def karoya_ata(self, karo, kid):
        n = ed.MAX_KARO if self.odak is not None else self.adet
        self.atama = ed.atama_ata(self.atama, karo, kid, max(n, self.adet))
        self.secili_slot = karo
        self._goruntuleri_temizle()
        if kid:
            self.sec(kid, karo)
        elif self.secili and self.secili not in self.atama[:self.adet]:
            self._ilk_gorunen_sec()
        self.kaydet()

    def _ilk_gorunen_sec(self):
        for k in self.atama[:self.adet]:
            if k and k in self.isciler:
                self.sec(k)
                return

    def odak_degistir(self, karo=None):
        if self.odak is not None:
            self.odak = None
        elif karo is not None and self.atama[karo]:
            self.odak = karo
        self._dz_anahtar = None

    def duzen_sec(self, n):
        n = ed.duzen_sinirla(n)
        self.adet = n
        self.odak = None
        self.atama = ed.atama_duzenle(self.atama, list(self.kartlar), n)
        self._goruntuleri_temizle()
        self._dz_anahtar = None
        if self.secili in self.atama[:n]:
            self.secili_slot = self.atama.index(self.secili)
        elif self.kartlar:
            self._ilk_gorunen_sec()
        self._duzen_dugmeleri_guncelle()
        self.kaydet()

    def _duzen_dugmeleri_guncelle(self):
        for n, d in self.duzen_dugmeleri.items():
            d.aktif_yap(n == self.adet)

    def _escape(self, e=None):
        if self.odak is not None:
            self.odak_degistir()
        elif self._tam_ekran:
            self.tam_ekran()

    # ------------------------------------------------------------- paneller
    def _panelleri_uygula(self):
        tam = self._tam_ekran
        for w, evet in ((self.yan, not tam), (self.baslik, not tam), (self.durum_cubugu, not tam),
                        (self.liste_cerceve, self.goster_liste and not tam),
                        (self.ptz_cerceve, self.goster_panel and not tam),
                        (self.log_cerceve, self.goster_gunluk and not tam)):
            if evet:
                w.grid()
            else:
                w.grid_remove()
        self.liste_btn.configure(fg_color=R["hover"] if self.goster_liste else R["kart"])
        self.panel_btn.configure(fg_color=R["hover"] if self.goster_panel else R["kart"])
        self.gunluk_btn.configure(text_color=R["mavi"] if self.goster_gunluk else R["metin2"])
        self.tam_btn.configure(text="⛶  Pencereye Dön" if tam else "⛶  Tam Ekran")

    def liste_degistir(self):
        self.goster_liste = not self.goster_liste
        self._panelleri_uygula()
        self.kaydet()

    def panel_degistir(self):
        self.goster_panel = not self.goster_panel
        self._panelleri_uygula()
        self.kaydet()

    def gunluk_degistir(self):
        self.goster_gunluk = not self.goster_gunluk
        self._panelleri_uygula()
        self.kaydet()

    # ------------------------------------------------------- kamera seçim menüsü
    def _menu_guncelle(self):
        self._menu_adlari = {}
        for kid, kart in self.kartlar.items():
            ad = kart.cfg["ad"]
            adi, n = ad, 2
            while adi in self._menu_adlari:
                adi = "%s (%d)" % (ad, n)
                n += 1
            self._menu_adlari[adi] = kid
        adlar = list(self._menu_adlari) or ["(kamera yok)"]
        self.kamera_menu.configure(values=adlar)
        secili = [a for a, k in self._menu_adlari.items() if k == self.secili]
        self.kamera_menu.set(secili[0] if secili else adlar[0] if self._menu_adlari and not self.secili else "(kamera yok)")

    def _kamera_menuden(self, ad):
        kid = self._menu_adlari.get(ad)
        if kid:
            self.sec(kid)

    # ---------------------------------------------------------- kamera yönetimi
    def _kamera_baslat(self, cfg):
        isci = self._isci_olustur(cfg)
        self.isciler[cfg["id"]] = isci
        kart = KameraKarti(self.liste, self, cfg)
        kart.pack(fill="x", pady=(0, 10))
        self.kartlar[cfg["id"]] = kart
        isci.start()
        self._liste_baslik_guncelle()
        self._menu_guncelle()

    # ------------------------------------------------------------------- ses
    def ses_degistir(self, kid=None):
        """Seçili (ya da verilen) kameranın sesini dinlemeyi açar/kapatır. Aynı anda tek kamera dinlenir."""
        kid = kid or self.secili
        if kid is None:
            return
        if kid == self.ses_kid:
            self.ses_durdur()
            return
        self.ses_durdur()
        isci = self.isciler.get(kid)
        if isci is None:
            return
        if not self.ses_cikis.uygun:
            self._ses_mesaj(self.ses_cikis.hata or "Ses çıkışı kullanılamıyor (sounddevice kurulu değil).", True)
            return
        kaynak = isci.ses_kaynagi()
        if kaynak is None:
            self._ses_mesaj("Ses için ffmpeg gerekli: pip install imageio-ffmpeg (ya da ffmpeg.exe’yi program klasörüne koyun).", True)
            return
        if kaynak.ses_yok:
            self._ses_mesaj("Bu kamerada ses akışı yok (Tapo uygulamasından mikrofonu açın).", True)
            return
        if not self.ses_cikis.ac():
            self._ses_mesaj(self.ses_cikis.hata, True)
            return
        self._ses_abone = (kaynak, kaynak.abone_ol(self.ses_cikis.yaz))
        self.ses_kid = kid
        self._ses_mesaj("", False)
        self.ses_etiket_guncelle()

    def ses_durdur(self):
        ab, self._ses_abone = self._ses_abone, None
        if ab is not None:
            try:
                ab[0].abonelik_birak(ab[1])
            except Exception:
                pass
        self.ses_cikis.kapat()
        self.ses_kid = None
        self.ses_etiket_guncelle()

    def _ses_seviye(self, v):
        self.ses_cikis.seviye = round(float(v), 2)
        self.ses_lbl_seviye.configure(text="%d%%" % round(float(v) * 100))
        self.kaydet()

    def _ses_mesaj(self, metin, hata):
        self.ses_mesaj_lbl.configure(text=metin, text_color=R["kirmizi"] if hata else R["soluk"])
        if metin and hata:
            self.gunluk_ekle("-", "HATA", metin)

    def ses_etiket_guncelle(self):
        isci = self.isciler.get(self.ses_kid) if self.ses_kid else None
        self.ses_dinlenen_lbl.configure(text=("Dinlenen: %s" % isci.ad) if isci else "Dinlenen: —",
                                        text_color=R["yesil"] if isci else R["soluk"])
        self.ses_btn.configure(text="🔇  Sesi Kapat" if isci and self.ses_kid == self.secili else "🔊  Sesi Dinle")

    def _isci_olustur(self, cfg):
        isci = KameraIsci(cfg, self.ayarlar, self.gunluk_ekle)
        isci.olay_geri = self.bildirimci.olay
        return isci

    def _acilir_goster(self, baslik, mesaj, kamera_id=None):
        """Başka iş parçacıklarından çağrılabilir; uygulama içi açılır bildirimi gösterir."""
        def goster():
            if not self._kapaniyor:
                AcilirBildirim(self, baslik, mesaj, kamera_id)
        self.ui(goster)

    def bildirim_ac(self):
        BildirimDialog(self)

    def _liste_baslik_guncelle(self):
        self.liste_baslik.configure(text="KAMERALAR (%d)" % len(self.kartlar))
        self.alt_baslik.configure(text="ONVIF Canlı İzleme · Hareket/Kişi Algılama · Kayıt · PTZ")

    def sec(self, kid, karo=None):
        """Kamerayı seçer (PTZ ve hızlı işlemler bu kameraya gider). Görünen bir karoda değilse seçili karoya yerleştirilir."""
        if kid not in self.isciler:
            return
        if self.odak is not None and self.atama[self.odak] != kid:
            karo = self.odak
        if karo is None:
            gorunen = [i for i in range(self.adet) if self.atama[i] == kid]
            if gorunen:
                karo = gorunen[0]
            else:
                karo = self.secili_slot if 0 <= self.secili_slot < self.adet else 0
        if self.atama[karo] != kid:
            self.atama = ed.atama_ata(self.atama, karo, kid, max(self.adet, karo + 1))
            self._goruntuleri_temizle()
            self.kaydet()
        self.secili_slot = karo
        degisti = kid != self.secili
        self.secili = kid
        for i, k in self.kartlar.items():
            k.secili_yap(i == kid)
        self._menu_guncelle()
        self.ses_etiket_guncelle()
        if degisti:
            self.zoom = 1.0
            self.zoom_lbl.configure(text="1.0×")
            self.ptz_alt.configure(text="%s · bağlanılıyor…" % self.isciler[kid].ad, text_color=R["soluk"])
            self.preset_menu.configure(values=["(preset yok)"])
            self.preset_menu.set("(preset yok)")
            self.preset_harita = {}
            self.presetleri_yenile()

    def kamera_ekle_ac(self, hazir=None):
        KameraDialog(self, None, hazir)

    def kamera_duzenle(self, kid):
        kart = self.kartlar.get(kid)
        if kart:
            KameraDialog(self, dict(kart.cfg))

    def kamera_kaydet(self, cfg, yeni):
        if yeni:
            self._kamera_baslat(cfg)
            self.atama = ed.atama_duzenle(self.atama, list(self.kartlar), self.adet)
            self.sec(cfg["id"])
        else:
            if self.ses_kid == cfg["id"]:
                self.ses_durdur()
            eski = self.isciler.get(cfg["id"])
            if eski:
                eski.kapat(2.0)
            kart = self.kartlar[cfg["id"]]
            kart.cfg = cfg
            kart.ad_guncelle()
            isci = self._isci_olustur(cfg)
            self.isciler[cfg["id"]] = isci
            isci.start()
            self._menu_guncelle()
            if self.secili == cfg["id"]:
                self.presetleri_yenile()
        self.kaydet()

    def kamera_sil(self, kid):
        kart = self.kartlar.get(kid)
        if not kart:
            return
        if not messagebox.askyesno(UYGULAMA_ADI, "“%s” kamerası listeden kaldırılsın mı?" % kart.cfg["ad"]):
            return
        if self.ses_kid == kid:
            self.ses_durdur()
        isci = self.isciler.pop(kid, None)
        if isci:
            isci.kapat(2.0)
        self.kartlar.pop(kid).destroy()
        self.atama = ed.atama_duzenle([None if x == kid else x for x in self.atama], list(self.kartlar), self.adet)
        self._goruntuleri_temizle()
        if self.odak is not None and not self.atama[self.odak]:
            self.odak = None
        self._dz_anahtar = None
        if self.secili == kid:
            self.secili = None
            if self.kartlar:
                self._ilk_gorunen_sec()
                if self.secili is None:
                    self.sec(next(iter(self.kartlar)))
            else:
                self.ptz_alt.configure(text="Kamera seçin", text_color=R["soluk"])
        self._liste_baslik_guncelle()
        self._menu_guncelle()
        self.kaydet()

    # --------------------------------------------------------------- diyalog açıcılar
    def tara_ac(self):
        TaraDialog(self)

    def ayar_ac(self):
        AyarDialog(self)

    def kayitlar_ac(self):
        KayitlarDialog(self)

    def klasoru_ac(self):
        k = Path(self.ayarlar.kayit_klasoru)
        alt, _ = ascii_klasor(k)
        for aday in (k, alt):
            try:
                aday.mkdir(parents=True, exist_ok=True)
                yolu_ac(aday)
                return
            except OSError:
                continue

    # ------------------------------------------------------------ video kontrolleri
    def _hedef_isci(self, kid=None):
        return self.isciler.get(kid) if kid else self.secili_isci()

    def manuel_kayit_degistir(self, kid=None):
        isci = self._hedef_isci(kid)
        if isci:
            isci.manuel_kayit = not isci.manuel_kayit
            self.gunluk_ekle(isci.ad, "BİLGİ", "Elle kayıt %s" % ("istendi" if isci.manuel_kayit else "bırakıldı"))

    def fotograf_cek(self, kid=None):
        isci = self._hedef_isci(kid)
        if not isci:
            return
        try:
            yol = isci.fotograf_cek(self.ayarlar.kayit_klasoru)
        except Exception as e:
            self.gunluk_ekle(isci.ad, "HATA", "Fotoğraf kaydedilemedi: %s" % e)
            return
        if yol:
            self.gunluk_ekle(isci.ad, "BİLGİ", "Fotoğraf kaydedildi: %s" % yol.name)
        else:
            self.gunluk_ekle(isci.ad, "HATA", "Henüz görüntü yok")

    def tam_ekran(self):
        self._tam_ekran = not self._tam_ekran
        self.attributes("-fullscreen", self._tam_ekran)
        self._panelleri_uygula()

    def zoom_degistir(self, d):
        self.zoom = max(1.0, min(4.0, self.zoom + d))
        self.zoom_lbl.configure(text="%.1f×" % self.zoom)

    def _hiz_degisti(self, v):
        self.hiz = round(float(v), 1)
        self.hiz_lbl.configure(text="%.1f" % self.hiz)
        self.kaydet()

    def mod_etiketi_guncelle(self):
        ad = [m[0] for m in MODLAR if m[1] == self.ayarlar.mod]
        self.mod_lbl.configure(text="Mod: %s" % (ad[0] if ad else "-"))

    def disk_goster(self):
        try:
            bos, toplam = disk_bilgi(self.ayarlar.kayit_klasoru)
            self.disk_lbl.configure(text="%s boş" % boyut_metni(bos))
            self.disk_bar.set(max(0.0, min(1.0, 1 - bos / float(toplam))))
        except Exception:
            self.disk_lbl.configure(text="—")

    def disk_guncelle(self):
        if self._kapaniyor:
            return
        self.disk_goster()
        self.after(15000, self.disk_guncelle)

    # --------------------------------------------------------------------- PTZ
    def _ptz_durum(self, metin, iyi):
        self.ptz_alt.configure(text=metin, text_color=R["yesil"] if iyi else "#FF6B7A")

    def _ptz_calis(self, islem, hareket=False):
        isci = self.secili_isci()
        if isci is None:
            return
        if hareket:
            isci.ptz_hareketi_bildir()

        def is_():
            try:
                islem(isci.ptz_istemci())
                self.ui(lambda: self._ptz_durum("%s · hazır" % isci.ad, True))
            except Exception as e:
                hata = str(e)
                self.ui(lambda: self._ptz_durum(hata[:110], False))
                self.gunluk_ekle(isci.ad, "HATA", "PTZ: %s" % hata[:140])

        self.ptz_ex.submit(is_)

    def _ptz_hareket(self, vx, vy):
        h = self.hiz
        self._ptz_calis(lambda c: c.hareket(vx * h, vy * h), hareket=True)

    def _ptz_dur(self):
        self._ptz_calis(lambda c: c.dur())

    def _ptz_ana(self):
        self._ptz_calis(lambda c: c.ana_konuma_git(), hareket=True)

    def presetleri_yenile(self):
        isci = self.secili_isci()
        if isci is None:
            return

        def is_():
            try:
                liste = isci.ptz_istemci().presetleri_al()
                self.ui(lambda: self._preset_goster(isci.cfg["id"], liste))
                self.ui(lambda: self._ptz_durum("%s · hazır" % isci.ad, True))
            except Exception as e:
                hata = str(e)
                self.ui(lambda: self._ptz_durum(hata[:110], False))

        self.ptz_ex.submit(is_)

    def _preset_goster(self, kid, liste):
        if kid != self.secili:
            return
        self.preset_harita = {}
        for ad, token in liste:
            adi = ad
            n = 2
            while adi in self.preset_harita:
                adi = "%s (%d)" % (ad, n)
                n += 1
            self.preset_harita[adi] = token
        adlar = list(self.preset_harita) or ["(preset yok)"]
        self.preset_menu.configure(values=adlar)
        self.preset_menu.set(adlar[0])

    def preset_git(self):
        token = self.preset_harita.get(self.preset_menu.get())
        if token is None:
            self._ptz_durum("Önce bir konum seçin veya kaydedin.", False)
            return
        self._ptz_calis(lambda c: c.presete_git(token), hareket=True)

    def preset_kaydet(self):
        isci = self.secili_isci()
        if isci is None:
            return
        pencere = ctk.CTkInputDialog(text="Bu konum için bir ad girin:", title="Konumu Kaydet")
        ad = pencere.get_input()
        if not ad or not ad.strip():
            return
        ad = ad.strip()

        def is_():
            try:
                isci.ptz_istemci().preset_kaydet(ad)
                self.gunluk_ekle(isci.ad, "BİLGİ", "Konum kaydedildi: %s" % ad)
                self.ui(self.presetleri_yenile)
            except Exception as e:
                hata = str(e)
                self.ui(lambda: self._ptz_durum(hata[:110], False))

        self.ptz_ex.submit(is_)

    # ------------------------------------------------------------ uzaktan erişim
    def uzak_ac(self):
        d = self.uzak_dlg
        try:
            if d is not None and d.winfo_exists():
                d.focus_force()
                return
        except tk.TclError:
            pass
        self.uzak_dlg = UzakDialog(self)

    def kayit_klasorleri(self):
        """Web sayfasının kayıtları aradığı klasörler (yol özel karakter içeriyorsa yedek klasör dahil)."""
        k = self.ayarlar.kayit_klasoru
        alt, _ = ascii_klasor(k)
        return [k] if str(alt) == str(Path(k)) else [k, str(alt)]

    def uzak_calisiyor(self):
        return (self._uzak_durduruluyor or (self.web is not None and self.web.calisiyor())
                or self.tunel.calisiyor())

    def uzak_adresi(self):
        """Dışarıdan erişilecek adres (tünel yoksa boş)."""
        u = self.uzak
        if self.tunel.durum in ("bagli", "baslatiliyor"):
            if u.get("mod") == "hizli":
                return self.tunel.adres or ""
            if u.get("mod") == "adli" and u.get("adres"):
                return "https://" + u["adres"]
        return ""

    def uzak_baslat(self):
        """Web görüntüleyiciyi ve (seçiliyse) Cloudflare tünelini başlatır. (ok, hata_mesajı) döndürür."""
        with self._uzak_kilit:
            return self._uzak_baslat_ic()

    def _uzak_baslat_ic(self):
        u = self.uzak
        self.uzak_durdur()
        try:
            self.web = WebSunucu(lambda: self.isciler, u.get("kullanici", ""), u.get("sifre", ""),
                                 int(u.get("port", 8787)), lambda sv, m: self.gunluk_ekle("-", sv, m),
                                 kayit_klasorleri_fn=self.kayit_klasorleri,
                                 kontrol=bool(u.get("kontrol", True)), kayit_izle=bool(u.get("kayit_izle", True)))
            self.web.baslat()
        except ValueError as e:
            self.web = None
            return False, str(e)
        except OSError as e:
            self.web = None
            return False, "Web görüntüleyici başlatılamadı (%s numaralı port kullanımda olabilir): %s" % (
                u.get("port"), e)
        if u.get("mod") in ("hizli", "adli"):
            yol = cft.bul(u.get("cloudflared_yol", ""), ayar_klasoru())
            if not yol:
                self.uzak_durdur()
                return False, "cloudflared bulunamadı. ‘İndir’ düğmesiyle kurun veya dosyayı seçin."
            try:
                self.tunel.baslat(yol, u["mod"], u.get("token", ""), int(self.web.port))  # gerçekte bağlanılan port
            except (ValueError, RuntimeError) as e:
                self.uzak_durdur()
                return False, str(e)
        self._uzak_durum()
        return True, ""

    def uzak_durdur(self):
        with self._uzak_kilit:
            self._uzak_durduruluyor = True      # kapanma bitene kadar "çalışıyor" sayılır (port henüz serbest değil)
            try:
                try:
                    self.tunel.durdur()
                except Exception as e:
                    self.gunluk_ekle("-", "HATA", "Tünel durdurulamadı: %s" % e)
                w = self.web
                if w is not None:
                    try:
                        w.durdur()
                    except Exception as e:
                        self.gunluk_ekle("-", "HATA", "Web görüntüleyici durdurulamadı: %s" % e)
                    self.web = None
            finally:
                self._uzak_durduruluyor = False
        self.ui(self._uzak_durum)   # arka plan iş parçacığından da çağrılabildiği için arayüze kuyruktan

    def _uzak_durum(self):
        b = self.bulut_btn
        if b is None:
            return
        if self.tunel.durum == "bagli":
            renk = CF_TURUNCU
        elif self.uzak_calisiyor():
            renk = R["mavi"]
        else:
            renk = R["soluk"]
        b.configure(text_color=renk)

    def _uzak_dongu(self):
        if self._kapaniyor:
            return
        self._uzak_durum()
        self.after(1500, self._uzak_dongu)

    def _uzak_otomatik(self):
        ok, mesaj = self.uzak_baslat()
        if not ok:
            self.gunluk_ekle("-", "HATA", "Uzaktan erişim otomatik başlatılamadı: %s" % mesaj)

    # --------------------------------------------------------------------- çıkış
    def kapat(self):
        self._kapaniyor = True
        self.kaydet()
        self.ses_durdur()
        self.uzak_durdur()
        for isci in list(self.isciler.values()):
            isci.durdur()
        for isci in list(self.isciler.values()):
            isci.kapat(2.0)
        try:
            self.ptz_ex.shutdown(wait=False)
        except Exception:
            pass
        self.destroy()


def main():
    app = Uygulama()
    app.mainloop()


if __name__ == "__main__":
    main()
