# -*- coding: utf-8 -*-
"""
Ses desteği (kamera mikrofonu): canlı dinleme, kayıtlara ses ekleme, kayıt oynatırken ses.

Ses, ffmpeg ile çözülür (imageio-ffmpeg paketiyle gelen ya da PATH/uygulama klasöründeki ffmpeg):
  RTSP -> ffmpeg -> 16 kHz mono 16 bit PCM -> [canlı çıkış] ve/veya [WAV kaydedici -> mp4'e birleştirme]
Çalma için `sounddevice` (PortAudio) kullanılır. Hiçbiri yoksa görüntü özellikleri aynen çalışır; yalnızca ses kapalı kalır.
"""
import collections
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import wave
from pathlib import Path

_WIN = sys.platform.startswith("win")
_CREATE_NO_WINDOW = 0x08000000
ORNEK_HIZI = 16000
KANAL = 1
BLOK = 3200                       # 100 ms (16000 Hz * 2 bayt * 0.1 sn)
_SIFRE_RE = re.compile(r"(rtsps?://)[^/@\s]*@", re.I)


def maskele(metin):
    return _SIFRE_RE.sub(r"\1***@", metin or "")


def ffmpeg_bul(ayar_klasoru=None):
    """ffmpeg çalıştırılabilir dosyasının yolunu döndürür (yoksa None)."""
    try:
        import imageio_ffmpeg
        yol = imageio_ffmpeg.get_ffmpeg_exe()
        if yol and Path(yol).is_file():
            return str(yol)
    except Exception:
        pass
    ad = "ffmpeg.exe" if _WIN else "ffmpeg"
    adaylar = []
    if ayar_klasoru:
        adaylar.append(Path(ayar_klasoru) / ad)
    adaylar.append(Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve().parent / ad)
    adaylar.append(Path(getattr(sys, "_MEIPASS", ".")) / ad)
    p = shutil.which("ffmpeg")
    if p:
        adaylar.append(Path(p))
    for a in adaylar:
        try:
            if a.is_file():
                return str(a)
        except OSError:
            continue
    return None


_FF = {"yol": None, "arandi": False}


def ffmpeg_onbellekli():
    if not _FF["arandi"]:
        _FF["yol"], _FF["arandi"] = ffmpeg_bul(), True
    return _FF["yol"]


def _kw():
    return {"creationflags": _CREATE_NO_WINDOW} if _WIN else {}


def _girdi_secenekleri(url, ek=None):
    s = list(ek or [])
    if str(url).lower().startswith("rtsp"):
        s += ["-rtsp_transport", "tcp"]
    return s


def pcm_komutu(ffmpeg, url, baslangic_sn=0.0, hiz=1.0, ek_girdi=None):
    """url'den (RTSP ya da dosya) 16 kHz mono s16le PCM'i stdout'a yazan komut."""
    k = [ffmpeg, "-nostdin", "-hide_banner", "-loglevel", "error"]
    k += _girdi_secenekleri(url, ek_girdi)
    if baslangic_sn and baslangic_sn > 0:
        k += ["-ss", "%.3f" % baslangic_sn]
    k += ["-i", str(url), "-vn", "-ac", str(KANAL), "-ar", str(ORNEK_HIZI)]
    af = tempo_filtresi(hiz)
    if af:
        k += ["-af", af]
    return k + ["-f", "s16le", "-"]


def tempo_filtresi(t):
    """atempo yalnızca 0.5–2.0 arası kabul eder; dışındakiler zincirlenir."""
    if not t or abs(t - 1.0) < 0.005:
        return ""
    t = max(0.25, min(8.0, float(t)))
    parcalar = []
    while t > 2.0:
        parcalar.append("atempo=2.0")
        t /= 2.0
    while t < 0.5:
        parcalar.append("atempo=0.5")
        t /= 0.5
    parcalar.append("atempo=%.4f" % t)
    return ",".join(parcalar)


def ses_var(ffmpeg, yol, zaman_asimi=15):
    """Dosyada ses akışı var mı? (True/False; bilinemezse None)"""
    if not ffmpeg:
        return None
    try:
        c = subprocess.run([ffmpeg, "-nostdin", "-hide_banner", "-i", str(yol)], capture_output=True,
                           timeout=zaman_asimi, **_kw())
        metin = (c.stderr or b"").decode("utf-8", "replace")
    except (OSError, subprocess.SubprocessError):
        return None
    if "Input #0" not in metin:
        return None
    return bool(re.search(r"Stream #\d+:\d+.*Audio:", metin))


# --------------------------------------------------------------------------- çalma
class SesCikisi:
    """PCM'i ses kartına çalar. sounddevice yoksa/çalışmıyorsa `uygun` False olur."""

    def __init__(self, sd=None):
        self._sd = sd
        self._akim = None
        self._tampon = bytearray()
        self._kilit = threading.Lock()
        self.seviye = 0.8               # 0..1
        self.hata = ""
        self._dolgu = False             # ilk dolum bekleniyor
        self.altta_kalma = 0            # ölçüm: boş kalan blok sayısı

    @property
    def uygun(self):
        return self._sd_al() is not None

    def _sd_al(self):
        if self._sd is None:
            try:
                import sounddevice as sd
                self._sd = sd
            except Exception as e:       # paket yok ya da PortAudio bulunamadı
                self.hata = "Ses çıkışı kullanılamıyor: %s" % e
                self._sd = False
        return self._sd or None

    def ac(self):
        sd = self._sd_al()
        if sd is None:
            return False
        if self._akim is not None:
            return True
        try:
            self.temizle()
            self._akim = sd.RawOutputStream(samplerate=ORNEK_HIZI, channels=KANAL, dtype="int16",
                                            blocksize=1600, callback=self._geri)
            self._akim.start()
            self.hata = ""
            return True
        except Exception as e:
            self._akim = None
            self.hata = "Ses çıkışı açılamadı: %s" % e
            return False

    def kapat(self):
        a, self._akim = self._akim, None
        if a is not None:
            try:
                a.stop()
                a.close()
            except Exception:
                pass
        self.temizle()

    def temizle(self):
        with self._kilit:
            self._tampon.clear()
            self._dolgu = True

    def yaz(self, veri, *_):
        """PCM bayt dizisi ekler (en fazla ~1.5 sn gecikme tutulur)."""
        with self._kilit:
            self._tampon += veri
            if len(self._tampon) > ORNEK_HIZI * 2 * 1.5:
                del self._tampon[:len(self._tampon) - int(ORNEK_HIZI * 2 * 0.5)]

    def _geri(self, cikis, kare_sayisi, *_):
        n = kare_sayisi * 2 * KANAL
        with self._kilit:
            if self._dolgu and len(self._tampon) < ORNEK_HIZI * 2 * 0.2:    # ~200 ms birikene kadar sessiz
                parca = b""
            else:
                self._dolgu = False
                parca = bytes(self._tampon[:n])
                del self._tampon[:n]
        if len(parca) < n:
            if parca == b"":
                self.altta_kalma += 1
            parca += b"\x00" * (n - len(parca))
        g = max(0.0, min(1.0, self.seviye))
        if g < 0.999:
            try:
                import numpy as np
                a = np.frombuffer(parca, dtype=np.int16).astype(np.float32) * (g * g)   # algısal eğri
                parca = a.astype(np.int16).tobytes()
            except Exception:
                pass
        cikis[:] = parca


# ------------------------------------------------------------------ canlı kaynak
class SesKaynagi:
    """Bir kameranın RTSP sesini tek ffmpeg süreciyle çözer; birden çok abone (dinleme, kayıt) aynı akışı paylaşır."""

    def __init__(self, url_fn, ffmpeg, gunluk=None, ek_girdi=None, bos_bekleme=5.0):
        self._bos_bekleme = bos_bekleme      # son abone ayrılınca süreç bu kadar sn açık kalır (parça geçişleri için)
        self._zamanlayici = None
        self._url_fn = url_fn
        self._ffmpeg = ffmpeg
        self._gunluk = gunluk or (lambda s, m: None)
        self._ek = ek_girdi
        self._aboneler = {}
        self._sayac = 0
        self._kilit = threading.Lock()
        self._thr = None
        self._dur = threading.Event()
        self._proc = None
        self.ses_yok = False            # kamerada ses akışı yok (mikrofon kapalı)
        self.calisiyor = False

    def abone_ol(self, fn):
        with self._kilit:
            if self._zamanlayici is not None:
                self._zamanlayici.cancel()
                self._zamanlayici = None
            self._sayac += 1
            kimlik = self._sayac
            self._aboneler[kimlik] = fn
            if self._thr is None or not self._thr.is_alive():
                self._dur = threading.Event()
                self.ses_yok = False
                self._thr = threading.Thread(target=self._calis, args=(self._dur,), daemon=True)
                self._thr.start()
        return kimlik

    def abonelik_birak(self, kimlik):
        with self._kilit:
            self._aboneler.pop(kimlik, None)
            bos = not self._aboneler
            if bos and self._bos_bekleme > 0:
                if self._zamanlayici is not None:
                    self._zamanlayici.cancel()
                self._zamanlayici = threading.Timer(self._bos_bekleme, self._bos_kapat)
                self._zamanlayici.daemon = True
                self._zamanlayici.start()
                return
        if bos:
            self.kapat()

    def _bos_kapat(self):
        with self._kilit:
            if self._aboneler:
                return
            self._zamanlayici = None
        self.kapat()

    def kapat(self, bekle=2.0):
        with self._kilit:
            z, self._zamanlayici = self._zamanlayici, None
        if z is not None:
            z.cancel()
        self._dur.set()
        p = self._proc
        if p is not None:
            try:
                p.terminate()
            except OSError:
                pass
        t = self._thr
        if t is not None and t.is_alive() and t is not threading.current_thread():
            t.join(bekle)
            if t.is_alive() and p is not None:
                try:
                    p.kill()
                except OSError:
                    pass
        self.calisiyor = False

    def _yay(self, veri):
        with self._kilit:
            aboneler = list(self._aboneler.values())
        simdi = time.time()
        for fn in aboneler:
            try:
                fn(veri, simdi)
            except Exception:
                pass

    def _calis(self, dur):
        hata_sayisi = 0
        while not dur.is_set():
            url = self._url_fn()
            if not url:
                dur.wait(1.0)
                continue
            try:
                proc = subprocess.Popen(pcm_komutu(self._ffmpeg, url, ek_girdi=self._ek), stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE, stdin=subprocess.DEVNULL, **_kw())
            except OSError as e:
                self._gunluk("HATA", "Ses başlatılamadı: %s" % e)
                return
            self._proc = proc
            if dur.is_set():
                proc.terminate()
            hata_metni = []
            threading.Thread(target=lambda: hata_metni.append(proc.stderr.read(4000)), daemon=True).start()
            alinan = 0
            self.calisiyor = True
            try:
                while not dur.is_set():
                    parca = proc.stdout.read(BLOK)
                    if not parca:
                        break
                    alinan += len(parca)
                    self._yay(parca)
            except Exception:
                pass
            finally:
                self.calisiyor = False
                try:
                    proc.terminate()
                except OSError:
                    pass
                try:
                    proc.wait(timeout=3)
                except Exception:
                    pass
            if dur.is_set():
                return
            time.sleep(0.1)
            metin = b"".join(hata_metni).decode("utf-8", "replace") if hata_metni else ""
            if alinan == 0 and ("does not contain any stream" in metin or "Output file #0" in metin
                                or "Stream map" in metin):
                self.ses_yok = True
                self._gunluk("BİLGİ", "Kamerada ses akışı yok (mikrofon kapalı olabilir)")
                return
            hata_sayisi += 1
            if alinan == 0 and hata_sayisi >= 3:
                self._gunluk("HATA", "Ses akışı açılamadı: %s" % (maskele(metin).strip()[:160] or "bilinmeyen hata"))
                hata_sayisi = 0
                dur.wait(15)
            else:
                dur.wait(2.0)


# ------------------------------------------------------------- kayda ses ekleme
class SesKaydedici:
    """Aboneliğiyle gelen PCM'i WAV dosyasına yazar; ilk/son veri zamanını tutar."""

    def __init__(self, kaynak, yol):
        self.yol = Path(yol)
        self.kaynak = kaynak
        self.t_ilk = None
        self.t_son = None
        self.bayt = 0
        self._w = wave.open(str(self.yol), "wb")
        self._w.setnchannels(KANAL)
        self._w.setsampwidth(2)
        self._w.setframerate(ORNEK_HIZI)
        self._kilit = threading.Lock()
        self._kimlik = kaynak.abone_ol(self._yaz)

    def _yaz(self, veri, zaman):
        with self._kilit:
            if self._w is None:
                return
            if self.t_ilk is None:
                self.t_ilk = zaman - len(veri) / (ORNEK_HIZI * 2.0)    # blok sonunda geldi; başlangıcı geriye al
            self.t_son = zaman
            self.bayt += len(veri)
            self._w.writeframesraw(veri)

    def sure(self):
        return self.bayt / (ORNEK_HIZI * 2.0 * KANAL)

    def durdur(self):
        self.kaynak.abonelik_birak(self._kimlik)
        with self._kilit:
            w, self._w = self._w, None
        if w is not None:
            try:
                w.close()
            except Exception:
                pass
        return self


def birlestir(ffmpeg, video, wav, ofset_sn, tempo=1.0, zaman_asimi=600):
    """Video (mp4v) + WAV -> aynı dosyanın içine AAC sesli yeni mp4. Başarılıysa True; video dosyası yerinde güncellenir."""
    video, wav = Path(video), Path(wav)
    gecici = video.with_name(video.stem + ".ses.tmp")        # *.mp4 listelerinde görünmesin
    k = [ffmpeg, "-y", "-nostdin", "-hide_banner", "-loglevel", "error", "-i", str(video)]
    if ofset_sn and ofset_sn > 0.01:
        k += ["-itsoffset", "%.3f" % ofset_sn]
    k += ["-i", str(wav), "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "64k"]
    af = tempo_filtresi(tempo)
    if af:
        k += ["-af", af]
    k += ["-shortest", "-movflags", "+faststart", "-f", "mp4", str(gecici)]
    try:
        c = subprocess.run(k, capture_output=True, timeout=zaman_asimi, **_kw())
        if c.returncode != 0 or not gecici.is_file() or gecici.stat().st_size < 1000:
            return False
        os.replace(str(gecici), str(video))
        return True
    except (OSError, subprocess.SubprocessError):
        return False
    finally:
        try:
            if gecici.exists():
                gecici.unlink()
        except OSError:
            pass


# ------------------------------------------------------------- dosyadan oynatma
class DosyaSesi:
    """Kayıt oynatılırken sesi ffmpeg ile çözüp çıkışa verir. Aramada/hız değişiminde yeniden başlatılır."""

    def __init__(self, ffmpeg, yol, cikis):
        self.ffmpeg, self.yol, self.cikis = ffmpeg, str(yol), cikis
        self._proc = None
        self._dur = threading.Event()
        self._thr = None

    def baslat(self, sn, hiz=1.0):
        self.durdur()
        self._dur = threading.Event()
        self.cikis.temizle()
        self._thr = threading.Thread(target=self._calis, args=(self._dur, max(0.0, sn), hiz), daemon=True)
        self._thr.start()

    def durdur(self):
        self._dur.set()
        p = self._proc
        if p is not None:
            try:
                p.terminate()
            except OSError:
                pass
        t = self._thr
        if t is not None and t.is_alive() and t is not threading.current_thread():
            t.join(1.5)
        self._thr = None
        self._proc = None

    def _calis(self, dur, sn, hiz):
        try:
            proc = subprocess.Popen(pcm_komutu(self.ffmpeg, self.yol, sn, hiz), stdout=subprocess.PIPE,
                                    stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL, **_kw())
        except OSError:
            return
        self._proc = proc
        try:
            while not dur.is_set():
                parca = proc.stdout.read(BLOK)
                if not parca:
                    break
                # çıkışın tamponu dolu ise gerçek zamana göre bekle (ffmpeg çok hızlı çözer)
                while not dur.is_set() and len(self.cikis._tampon) > ORNEK_HIZI * 2 * 0.6:
                    dur.wait(0.03)
                self.cikis.yaz(parca)
        finally:
            try:
                proc.terminate()
            except OSError:
                pass
            try:
                proc.wait(timeout=2)
            except Exception:
                pass
