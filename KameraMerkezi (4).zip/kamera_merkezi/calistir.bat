@echo off
chcp 65001 >nul
set "PY=python"
if "%1"=="32" set "PY=py -3-32"
%PY% -c "import struct;print(struct.calcsize('P')*8)" > "%TEMP%\km_bit.txt" 2>nul
if errorlevel 1 (echo Python bulunamadi & pause & exit /b 1)
set /p BIT=<"%TEMP%\km_bit.txt"
set "REQ=requirements.txt"
if "%BIT%"=="32" set "REQ=requirements-32bit.txt"
%PY% -m pip install --prefer-binary -r %REQ%
%PY% kamera_merkezi.py
